# R01 — Pipeline C2 K-sweep (LOSO-CV) — OOM-hardened
### Overlap (STEP_SIZE=1) + run-wise normalization + multi-seed anti-collapse + explicit steps/epoch + chunked execution + auto-resume

This notebook is a drop-in replacement for the old K-sweep **and** addresses the recent **OOM-kill** by:
1) **Disabling XLA at import** (prevents accumulating compiled XLA modules that can balloon RAM over long sweeps).
2) Using **explicit `steps_per_epoch` / `validation_steps`** (removes “Unknown” dataset cardinality; reduces retracing surprises).
3) Supporting **chunked execution** (run a limited number of (fold,K) pairs per session, save, exit cleanly; then restart kernel and resume automatically).

Outputs (under `OUT_ROOT`):
- `cv_results.tsv` : one row per (fold, K) for the **selected** seed
- `cv_candidates_long.tsv` : one row per (fold, K, seed) candidate (val FE + collapse metrics)
- `fold_meta.tsv` : per-fold metadata (PCA PVE, segment counts, etc.)
- `feasibility_vs_K.png`, `mean_testFE_vs_K.png`

**Important**
- If you edit any “XLA disable” settings in Cell 0, restart kernel and run from top.
- Chunking is the *most reliable* way to avoid long-session RAM creep on WSL.



```python
# =========================
# Cell 0 — USER INPUTS (edit here only)
# =========================
from pathlib import Path
import os

# -------------------------
# Dataset identity
# -------------------------
DATA_VARIANT = "intermediate"
FEATURE_MODE = "nolags"   # "lags" or "nolags"
MINLEN       = 15

# K sweep grid
K_GRID = list(range(2, 13))

# -------------------------
# Paths (WSL format)
# -------------------------
FINAL_ROOT = Path("/mnt/c/EEGFMRI/hmm/R01_rerun/02_derivatives/fusion_prep/align_trmask_lags/FINAL_v3_gnorm_allTR") / DATA_VARIANT

# If you prefer to hardcode the manifest, set MANIFEST_TSV explicitly.
# Otherwise, leave as None and it will auto-find it under FINAL_ROOT.
MANIFEST_TSV = None  # e.g., FINAL_ROOT / "hmm_segments_minlen15_nolags" / "segments_manifest.tsv"

# Output root
OUT_ROOT = Path("/mnt/c/EEGFMRI/hmm/R01_rerun/02_derivatives/fusion_prep/fusion_hmm_LOSO_Ksweep_C2") / f"{DATA_VARIANT}_{FEATURE_MODE}_minlen{MINLEN}"

# -------------------------
# Feature layout (Pipeline B builds X = [BOLD | EEG])
# -------------------------
N_PARCELS = 200
TR_SEC    = 2.1

if FEATURE_MODE.lower() == "lags":
    LAGS_TR = [-1, 0, 1]
elif FEATURE_MODE.lower() == "nolags":
    LAGS_TR = [0]
else:
    raise ValueError("FEATURE_MODE must be 'lags' or 'nolags'")

D_BOLD  = N_PARCELS
D_EEG   = N_PARCELS * len(LAGS_TR)
D_TOTAL = D_BOLD + D_EEG

# -------------------------
# Windowing (C2 paradigm)
# -------------------------
SEQ_LEN    = 10
STEP_SIZE  = 1       # overlap within each segment (NO stitching across segments)
BATCH_SIZE = 16

# When concatenating per-segment datasets, shuffle happens at the batch level.
SHUFFLE_BUFFER = 2048  # batches

REBATCH_DROP_REMAINDER = True   # avoids variable batch shapes at segment boundaries (prevents repeated XLA recompiles)

# -------------------------
# Fold-wise PCA (leakage-safe; fit on training-only)
# -------------------------
N_BOLD_PCS = 40
N_EEG_PCS  = 40

# -------------------------
# Training hyperparameters (starting point)
# -------------------------
LEARNING_RATE = 1e-3
N_EPOCHS_CV   = 60

CV_LEARN_MEANS   = True
CV_LEARN_COVS    = True
CV_LEARN_TRANS   = True
CV_DIAGONAL_COVS = False   # recommended FULL covariances for C2
COV_EPS          = 1e-6

# Initialization per seed
INIT_TAKE      = 0.30
INIT_EPOCHS    = 5
BIGK_THRESH    = 6
INIT_TAKE_BIGK = 0.20

# Multi-seed restarts (anti-collapse)
SEEDS = [11, 23, 37, 53, 71]

# Inner validation policy (within training subjects)
VAL_SUBJECT_POLICY = "max_segments"

# Run-wise normalization (key anti-collapse lever)
USE_RUNWISE_ZSCORE = True

# Collapse screening thresholds (on validation)
FO_MAX_THRESH     = 0.95
ENTROPY_NORM_MIN  = 0.05
FO_ACTIVE_THRESH  = 0.01
MIN_ACTIVE_STATES_BASE = 3  # capped at K

# -------------------------
# OOM hardening
# -------------------------
# Disable XLA at import (MUST be set before tensorflow is imported in Cell 1)
DISABLE_XLA_AT_IMPORT = True
if DISABLE_XLA_AT_IMPORT:
    os.environ["TF_XLA_FLAGS"] = "--tf_xla_auto_jit=-1"  # hard-off for auto-clustering
    os.environ["TF_XLA_ENABLE_XLA_DEVICES"] = "0"
    os.environ["XLA_FLAGS"] = ""  # clear any inherited XLA flags

# Keep eager OFF for long sweeps (eager tends to be slower and can increase RAM overhead)
FORCE_EAGER = False

# Reduce tf.data aggressiveness (safer under WSL + long loops)
DISABLE_PREFETCH  = True
DISABLE_CALLBACKS = True

# GPU memory cap (your laptop GPU)
GPU_MEMORY_LIMIT_MB = 4096  # set None to use memory_growth

# -------------------------
# Chunked execution + auto-resume (recommended)
# -------------------------
RESUME_IF_RESULTS_EXIST = True

# Process at most this many NEW (fold,K) pairs, then save and stop cleanly.
# After it stops: restart kernel and run Cell 4 again to continue.
MAX_NEW_PAIRS_PER_RUN = 15   # e.g., 10–25

# Optional subset controls (leave as None for full sweep)
DEBUG_MAX_FOLDS = None     # e.g., 1
DEBUG_K_GRID    = None     # e.g., [2,3,4]
DEBUG_SEEDS     = None     # e.g., [11]

print("FINAL_ROOT:", FINAL_ROOT)
print("MANIFEST_TSV:", MANIFEST_TSV)
print("OUT_ROOT:", OUT_ROOT)
print(f"D_TOTAL={D_TOTAL} (BOLD={D_BOLD}, EEG={D_EEG})")
print("K_GRID:", K_GRID)
print("SEQ_LEN:", SEQ_LEN, "STEP_SIZE:", STEP_SIZE, "BATCH_SIZE:", BATCH_SIZE)
print("SEEDS:", SEEDS)
print("MAX_NEW_PAIRS_PER_RUN:", MAX_NEW_PAIRS_PER_RUN)

```

    FINAL_ROOT: /mnt/c/EEGFMRI/hmm/R01_rerun/02_derivatives/fusion_prep/align_trmask_lags/FINAL_v3_gnorm_allTR/intermediate
    MANIFEST_TSV: None
    OUT_ROOT: /mnt/c/EEGFMRI/hmm/R01_rerun/02_derivatives/fusion_prep/fusion_hmm_LOSO_Ksweep_C2/intermediate_nolags_minlen15
    D_TOTAL=400 (BOLD=200, EEG=200)
    K_GRID: [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    SEQ_LEN: 10 STEP_SIZE: 1 BATCH_SIZE: 16
    SEEDS: [11, 23, 37, 53, 71]
    MAX_NEW_PAIRS_PER_RUN: 15



```python
# =========================
# Cell 1 — Imports + manifest resolution + load segment paths
# =========================
import os, gc
from pathlib import Path

import numpy as np
import pandas as pd

# IMPORTANT: if you changed DISABLE_XLA_AT_IMPORT in Cell 0, restart kernel before running this cell.

import tensorflow as tf
from osl_dynamics.data import Data
from osl_dynamics.models.hmm import Config, Model

OUT_ROOT.mkdir(parents=True, exist_ok=True)
CV_TSV       = OUT_ROOT / "cv_results.tsv"
CAND_TSV     = OUT_ROOT / "cv_candidates_long.tsv"
FOLD_META_TSV= OUT_ROOT / "fold_meta.tsv"

def auto_find_manifest(final_root: Path, feature_mode: str, minlen: int) -> Path:
    mode = feature_mode.lower()
    candidates = [
        final_root / f"hmm_segments_minlen{minlen}_{mode}" / "segments_manifest.tsv",
        final_root / f"hmm_segments_minlen{minlen}" / "segments_manifest.tsv",
    ]
    for m in candidates:
        if m.exists():
            return m
    hits = list(final_root.rglob("segments_manifest.tsv"))
    if hits:
        def score(p: Path):
            s = str(p)
            sc = 0
            if f"minlen{minlen}" in s: sc += 10
            if mode in s: sc += 5
            return sc
        hits = sorted(hits, key=score, reverse=True)
        return hits[0]
    raise FileNotFoundError(f"Could not find segments_manifest.tsv under {final_root}")

if MANIFEST_TSV is None:
    MANIFEST_TSV = auto_find_manifest(FINAL_ROOT, FEATURE_MODE, MINLEN)

print("MANIFEST_TSV:", MANIFEST_TSV)
manifest = pd.read_csv(MANIFEST_TSV, sep="\t")
print("Rows:", len(manifest))
print("Columns:", list(manifest.columns))
display(manifest.head())

if "run" not in manifest.columns or "seg_path" not in manifest.columns:
    raise ValueError("Expected manifest columns: 'run', 'seg_path'. Please confirm header.")

def parse_subject(run: str) -> str:
    parts = str(run).split("_")
    for p in parts:
        if p.startswith("sub-"):
            return p
    return parts[0]

manifest["subject"] = manifest["run"].apply(parse_subject)
sort_cols = ["subject", "run"]
if "seg_id" in manifest.columns:
    sort_cols.append("seg_id")
manifest = manifest.sort_values(sort_cols).reset_index(drop=True)

SEG_ROOT = MANIFEST_TSV.parent
def resolve_seg_path(p: str) -> Path:
    pp = Path(p)
    return pp if pp.is_absolute() else (SEG_ROOT / pp)

seg_paths = [resolve_seg_path(p) for p in manifest["seg_path"].tolist()]
missing = [p for p in seg_paths if not p.exists()]
if missing:
    print("Missing seg files (first 10):", missing[:10])
    raise FileNotFoundError("Some segment files do not exist.")

# We keep raw segments in memory for speed (usually modest); TF/XLA was your real RAM driver.
all_X = [np.load(p).astype(np.float32) for p in seg_paths]
manifest["X_index"] = np.arange(len(manifest), dtype=int)

x0 = all_X[0]
print("Example segment shape:", x0.shape)
assert x0.shape[1] == D_TOTAL, f"Expected D={D_TOTAL}, got {x0.shape[1]}"
print(f"Loaded {len(all_X)} segments | total TR = {int(np.sum([x.shape[0] for x in all_X]))}")

```

    2026-02-24 18:42:02.368603: I tensorflow/core/util/port.cc:153] oneDNN custom operations are on. You may see slightly different numerical results due to floating-point round-off errors from different computation orders. To turn them off, set the environment variable `TF_ENABLE_ONEDNN_OPTS=0`.
    2026-02-24 18:42:03.176870: E external/local_xla/xla/stream_executor/cuda/cuda_fft.cc:467] Unable to register cuFFT factory: Attempting to register factory for plugin cuFFT when one has already been registered
    WARNING: All log messages before absl::InitializeLog() is called are written to STDERR
    E0000 00:00:1771929723.484687  408332 cuda_dnn.cc:8579] Unable to register cuDNN factory: Attempting to register factory for plugin cuDNN when one has already been registered
    E0000 00:00:1771929723.606794  408332 cuda_blas.cc:1407] Unable to register cuBLAS factory: Attempting to register factory for plugin cuBLAS when one has already been registered
    W0000 00:00:1771929724.046317  408332 computation_placer.cc:177] computation placer already registered. Please check linkage and avoid linking the same target more than once.
    W0000 00:00:1771929724.046393  408332 computation_placer.cc:177] computation placer already registered. Please check linkage and avoid linking the same target more than once.
    W0000 00:00:1771929724.046397  408332 computation_placer.cc:177] computation placer already registered. Please check linkage and avoid linking the same target more than once.
    W0000 00:00:1771929724.046399  408332 computation_placer.cc:177] computation placer already registered. Please check linkage and avoid linking the same target more than once.
    2026-02-24 18:42:04.087286: I tensorflow/core/platform/cpu_feature_guard.cc:210] This TensorFlow binary is optimized to use available CPU instructions in performance-critical operations.
    To enable the following instructions: AVX2 AVX_VNNI FMA, in other operations, rebuild TensorFlow with the appropriate compiler flags.
    /home/gincru/miniforge3/envs/osl_gpu/lib/python3.12/site-packages/osl_dynamics/__init__.py:2: UserWarning: pkg_resources is deprecated as an API. See https://setuptools.pypa.io/en/latest/pkg_resources.html. The pkg_resources package is slated for removal as early as 2025-11-30. Refrain from using this package or pin to Setuptools<81.
      from pkg_resources import DistributionNotFound, get_distribution


    MANIFEST_TSV: /mnt/c/EEGFMRI/hmm/R01_rerun/02_derivatives/fusion_prep/align_trmask_lags/FINAL_v3_gnorm_allTR/intermediate/hmm_segments_minlen15_nolags/segments_manifest.tsv
    Rows: 71
    Columns: ['run', 'feature_mode', 'lags_tr', 'seg_id', 'start_TR', 'end_TR', 'len_TR', 'start_sec', 'end_sec', 'dur_sec', 'n_features', 'seg_path']



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>run</th>
      <th>feature_mode</th>
      <th>lags_tr</th>
      <th>seg_id</th>
      <th>start_TR</th>
      <th>end_TR</th>
      <th>len_TR</th>
      <th>start_sec</th>
      <th>end_sec</th>
      <th>dur_sec</th>
      <th>n_features</th>
      <th>seg_path</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>sub-01_ses-01</td>
      <td>nolags</td>
      <td>0</td>
      <td>sub-01_ses-01__seg0000</td>
      <td>1</td>
      <td>21</td>
      <td>20</td>
      <td>2.1</td>
      <td>44.1</td>
      <td>42.0</td>
      <td>400</td>
      <td>/mnt/c/EEGFMRI/hmm/R01_rerun/02_derivatives/fu...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>sub-01_ses-01</td>
      <td>nolags</td>
      <td>0</td>
      <td>sub-01_ses-01__seg0001</td>
      <td>22</td>
      <td>42</td>
      <td>20</td>
      <td>46.2</td>
      <td>88.2</td>
      <td>42.0</td>
      <td>400</td>
      <td>/mnt/c/EEGFMRI/hmm/R01_rerun/02_derivatives/fu...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>sub-01_ses-01</td>
      <td>nolags</td>
      <td>0</td>
      <td>sub-01_ses-01__seg0002</td>
      <td>43</td>
      <td>83</td>
      <td>40</td>
      <td>90.3</td>
      <td>174.3</td>
      <td>84.0</td>
      <td>400</td>
      <td>/mnt/c/EEGFMRI/hmm/R01_rerun/02_derivatives/fu...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>sub-01_ses-01</td>
      <td>nolags</td>
      <td>0</td>
      <td>sub-01_ses-01__seg0003</td>
      <td>84</td>
      <td>159</td>
      <td>75</td>
      <td>176.4</td>
      <td>333.9</td>
      <td>157.5</td>
      <td>400</td>
      <td>/mnt/c/EEGFMRI/hmm/R01_rerun/02_derivatives/fu...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>sub-01_ses-01</td>
      <td>nolags</td>
      <td>0</td>
      <td>sub-01_ses-01__seg0004</td>
      <td>160</td>
      <td>259</td>
      <td>99</td>
      <td>336.0</td>
      <td>543.9</td>
      <td>207.9</td>
      <td>400</td>
      <td>/mnt/c/EEGFMRI/hmm/R01_rerun/02_derivatives/fu...</td>
    </tr>
  </tbody>
</table>
</div>


    Example segment shape: (20, 400)
    Loaded 71 segments | total TR = 3550



```python
# =========================
# Cell 2 — TensorFlow GPU config (cap 4GB) + disable JIT
# =========================
# Optional: reduce thread parallelism (often stabilizes long runs under WSL)
try:
    tf.config.threading.set_intra_op_parallelism_threads(1)
    tf.config.threading.set_inter_op_parallelism_threads(1)
except Exception:
    pass

gpus = tf.config.list_physical_devices("GPU")
print("GPUs visible to TF:", gpus)

if gpus:
    try:
        if GPU_MEMORY_LIMIT_MB is not None:
            tf.config.set_logical_device_configuration(
                gpus[0],
                [tf.config.LogicalDeviceConfiguration(memory_limit=int(GPU_MEMORY_LIMIT_MB))]
            )
            print(f"[INFO] Capped GPU memory to {int(GPU_MEMORY_LIMIT_MB)} MB.")
        else:
            for gpu in gpus:
                tf.config.experimental.set_memory_growth(gpu, True)
            print("[INFO] Enabled memory_growth (no explicit cap).")
    except Exception as e:
        print("[WARN] GPU config:", e)
else:
    print("[INFO] Running CPU-only.")

# Disable TF JIT (not sufficient alone, but still useful)
try:
    tf.config.optimizer.set_jit(False)
    print("[INFO] tf.config.optimizer.set_jit(False)")
except Exception as e:
    print("[WARN] set_jit:", e)

if FORCE_EAGER:
    tf.config.run_functions_eagerly(True)
    print("[INFO] FORCE_EAGER=True")
else:
    print("[INFO] FORCE_EAGER=False (recommended for memory efficiency)")

# quick sanity
a = tf.random.normal((64, 64))
_ = tf.matmul(a, a)
print("TF OK")

```

    GPUs visible to TF: [PhysicalDevice(name='/physical_device:GPU:0', device_type='GPU')]
    [INFO] Capped GPU memory to 4096 MB.
    [INFO] tf.config.optimizer.set_jit(False)
    [INFO] FORCE_EAGER=False (recommended for memory efficiency)


    I0000 00:00:1771929738.103357  408332 gpu_device.cc:2019] Created device /job:localhost/replica:0/task:0/device:GPU:0 with 4096 MB memory:  -> device: 0, name: NVIDIA GeForce RTX 4060 Laptop GPU, pci bus id: 0000:01:00.0, compute capability: 8.9


    TF OK



```python
# =========================
# Cell 3 — Helpers (run-wise zscore, leakage-safe PCA, merged dataset, explicit steps/epoch, collapse metrics)
# =========================
import math

def gc_now():
    gc.collect()

def count_windows_for_segments(X_list):
    # number of sliding windows per segment (no cross-segment windows)
    n = 0
    for x in X_list:
        T = int(x.shape[0])
        if T >= SEQ_LEN:
            n += 1 + (T - SEQ_LEN) // STEP_SIZE
    return int(n)

def steps_from_windows(n_windows: int):
    """Compute steps_per_epoch given number of windows.

    If we rebatch with drop_remainder=True, steps is floor(n_windows / BATCH_SIZE).
    Otherwise it's ceil(...).
    """
    if n_windows <= 0:
        return 0
    if REBATCH_DROP_REMAINDER:
        return int(n_windows // int(BATCH_SIZE))
    return int(math.ceil(n_windows / float(BATCH_SIZE)))


def runwise_zscore_segments(X_list, run_ids, sl: slice):
    run_ids = np.asarray(run_ids, dtype=object)
    uniq = pd.unique(run_ids)
    mu, sd = {}, {}
    for r in uniq:
        idx = np.where(run_ids == r)[0]
        X = np.concatenate([X_list[i][:, sl] for i in idx], axis=0)
        m = X.mean(axis=0)
        s = X.std(axis=0, ddof=0)
        s[s < 1e-12] = 1.0
        mu[r] = m
        sd[r] = s
    out = []
    for X, r in zip(X_list, run_ids):
        Z = X.copy()
        Z[:, sl] = (Z[:, sl] - mu[r]) / sd[r]
        out.append(Z.astype(np.float32))
    return out

def fit_standardizer(X):
    mu = X.mean(axis=0)
    sd = X.std(axis=0, ddof=0)
    sd = np.where(sd < 1e-12, 1.0, sd)
    return mu.astype(np.float32), sd.astype(np.float32)

def apply_standardizer(X, mu, sd):
    return ((X - mu) / sd).astype(np.float32)

def fit_pca(X, n_fixed):
    mu = X.mean(axis=0, keepdims=True)
    Xc = X - mu
    U, S, Vt = np.linalg.svd(Xc, full_matrices=False)
    n_comp = int(min(n_fixed, Vt.shape[0]))
    V = Vt[:n_comp].T.astype(np.float32)
    var = (S**2) / max(Xc.shape[0] - 1, 1)
    pve = float(np.sum(var[:n_comp]) / np.sum(var)) if np.sum(var) > 0 else np.nan
    return mu.ravel().astype(np.float32), V, pve

def apply_pca(X, mu, V):
    return ((X - mu) @ V).astype(np.float32)

def make_fold_preproc(X_tr_raw_list):
    Xtr = np.concatenate(X_tr_raw_list, axis=0)
    Xb, Xe = Xtr[:, :D_BOLD], Xtr[:, D_BOLD:]

    mu_b, sd_b = fit_standardizer(Xb)
    mu_e, sd_e = fit_standardizer(Xe)

    Xb_z = apply_standardizer(Xb, mu_b, sd_b)
    Xe_z = apply_standardizer(Xe, mu_e, sd_e)

    mu_pb, Vb, pve_b = fit_pca(Xb_z, N_BOLD_PCS)
    mu_pe, Ve, pve_e = fit_pca(Xe_z, N_EEG_PCS)

    params = dict(mu_b=mu_b, sd_b=sd_b, mu_e=mu_e, sd_e=sd_e,
                  mu_pb=mu_pb, Vb=Vb, mu_pe=mu_pe, Ve=Ve)
    meta = dict(pve_bold=pve_b, pve_eeg=pve_e,
                n_bold_pcs=int(Vb.shape[1]), n_eeg_pcs=int(Ve.shape[1]),
                D_pca=int(Vb.shape[1] + Ve.shape[1]))
    return params, meta

def apply_fold_preproc(X, params):
    Xb = apply_standardizer(X[:, :D_BOLD], params["mu_b"], params["sd_b"])
    Xe = apply_standardizer(X[:, D_BOLD:], params["mu_e"], params["sd_e"])
    Xb_p = apply_pca(Xb, params["mu_pb"], params["Vb"])
    Xe_p = apply_pca(Xe, params["mu_pe"], params["Ve"])
    return np.concatenate([Xb_p, Xe_p], axis=1).astype(np.float32)

def choose_val_subject(train_df):
    if VAL_SUBJECT_POLICY == "max_segments":
        return train_df.groupby("subject").size().sort_values(ascending=False).index[0]
    return sorted(train_df["subject"].unique().tolist())[0]

def make_config(K, D):
    cfg = Config(
        n_states=K,
        n_channels=D,
        sequence_length=SEQ_LEN,
        learn_means=CV_LEARN_MEANS,
        learn_covariances=CV_LEARN_COVS,
        learn_trans_prob=CV_LEARN_TRANS,
        batch_size=BATCH_SIZE,
        learning_rate=LEARNING_RATE,
        n_epochs=N_EPOCHS_CV,
        covariances_epsilon=COV_EPS,
    )
    try:
        cfg.covariance_matrix_type = "diag" if CV_DIAGONAL_COVS else "full"
    except Exception:
        pass
    # IMPORTANT: one init per seed (we do multi-seed restarts)
    try:
        cfg.n_init = 1
    except Exception:
        pass
    return cfg

def callbacks():
    if DISABLE_CALLBACKS:
        return []
    cbs = []
    # You can re-enable these later if stable.
    return cbs

def as_tf_dataset(data: Data, shuffle: bool):
    # In osl-dynamics 2.1.5, concatenate=False may return a list of datasets (one per segment).
    ds_obj = data.dataset(
        sequence_length=SEQ_LEN,
        step_size=STEP_SIZE,
        batch_size=BATCH_SIZE,
        shuffle=False,
        concatenate=False,
    )

    if isinstance(ds_obj, (list, tuple)):
        ds_list = list(ds_obj)
        if len(ds_list) == 0:
            raise ValueError("Data.dataset returned empty list (no windows). Check SEQ_LEN/STEP_SIZE vs segment lengths.")
        ds = ds_list[0]
        for d in ds_list[1:]:
            ds = ds.concatenate(d)
    else:
        ds = ds_obj

    # Key stability fix:
    # Per-segment datasets may end with smaller final batches -> variable batch shapes at boundaries
    # -> TF retracing/XLA recompiles -> big compile time + RAM growth.
    if REBATCH_DROP_REMAINDER:
        try:
            ds = ds.unbatch().batch(int(BATCH_SIZE), drop_remainder=True)
        except Exception:
            pass

    if shuffle:
        try:
            ds = ds.shuffle(buffer_size=int(SHUFFLE_BUFFER), reshuffle_each_iteration=True)
        except Exception:
            pass

    if not DISABLE_PREFETCH:
        try:
            ds = ds.prefetch(tf.data.AUTOTUNE)
        except Exception:
            pass
    return ds

def free_energy(model, data: Data):
    ds = as_tf_dataset(data, shuffle=False)
    fe = model.free_energy(ds)
    if isinstance(fe, (list, tuple, np.ndarray)):
        fe = float(np.asarray(fe).ravel()[0])
    return float(fe)

def normalize_alpha_list(alpha_like):
    if isinstance(alpha_like, (list, tuple)):
        out = []
        for a in alpha_like:
            a = np.asarray(a)
            if a.ndim == 2:
                out.append(a)
            elif a.ndim == 3:
                out.extend([a[i] for i in range(a.shape[0])])
            else:
                raise ValueError(f"Unexpected alpha element ndim={a.ndim}, shape={a.shape}")
        return out
    a = np.asarray(alpha_like)
    if a.ndim == 2:
        return [a]
    if a.ndim == 3:
        return [a[i] for i in range(a.shape[0])]
    raise ValueError(f"Unexpected alpha ndim={a.ndim}, shape={a.shape}")

def get_alpha_list(model, data: Data):
    if hasattr(model, "get_alpha"):
        out = model.get_alpha(data, concatenate=False, verbose=0)
        return normalize_alpha_list(out)
    if hasattr(model, "get_gamma"):
        out = model.get_gamma(data, concatenate=False, verbose=0)
        return normalize_alpha_list(out)
    raise AttributeError("Model does not expose get_alpha/get_gamma.")

def summarize_alpha(alpha_list, K, eps=1e-12):
    alpha_list = normalize_alpha_list(alpha_list)
    tot_T = 0
    fo_num = np.zeros(K, dtype=np.float64)
    ent_sum_norm = 0.0
    for a in alpha_list:
        a = np.asarray(a, dtype=np.float64)
        if a.ndim != 2 or a.shape[1] != K:
            raise ValueError(f"Expected alpha shape (T,{K}); got {a.shape}")
        tot_T += a.shape[0]
        fo_num += a.sum(axis=0)
        a_clip = np.clip(a, eps, 1.0)
        Ht = -(a_clip * np.log(a_clip)).sum(axis=1)
        ent_sum_norm += (Ht / np.log(K)).sum()
    fo = (fo_num / max(tot_T, 1))
    fo_max = float(np.max(fo)) if fo.size else np.nan
    ent_norm = float(ent_sum_norm / max(tot_T, 1))
    n_active = int(np.sum(fo > FO_ACTIVE_THRESH)) if fo.size else 0
    return fo.astype(np.float32), fo_max, ent_norm, n_active

def fo_entropy_and_neff(fo, K, eps=1e-12):
    """
    Global occupancy diversity metrics computed from FO (fractional occupancy).

    fo_entropy_norm: FO-entropy normalized to [0,1] by log(K).
        - 0 means all mass on one state
        - 1 means perfectly uniform over states
    neff: "effective number of states" = exp(H(FO)) in [1, K]
    """
    fo = np.asarray(fo, dtype=np.float64)
    if fo.ndim != 1 or fo.size != K:
        raise ValueError(f"Expected fo shape ({K},), got {fo.shape}")
    fo = np.clip(fo, eps, 1.0)
    fo = fo / fo.sum()

    H_nat = float(-(fo * np.log(fo)).sum())         # natural entropy
    fo_entropy_norm = float(H_nat / np.log(K))      # normalized
    neff = float(np.exp(H_nat))                     # effective #states
    return fo_entropy_norm, neff


def is_collapsed(fo_max, n_active, K):
    """
    Anti-collapse screen (feasibility):
    - do NOT use timepoint gamma entropy; it's mainly a "confidence" measure.
    - collapse means "globally degenerate" usage of states.
    """
    min_active = min(int(MIN_ACTIVE_STATES_BASE), int(K))

    if not np.isfinite(fo_max):
        return True
    if fo_max > FO_MAX_THRESH:
        return True
    if int(n_active) < int(min_active):
        return True
    return False


def choose_best_candidate(cands):
    """
    Select best seed among candidates.
    Preference order:
      1) non-collapsed candidates first (if any exist)
      2) lowest val free energy
      3) lower fo_max (less dominance)
      4) higher n_active
      5) higher FO-entropy (more globally diverse occupancy)
    """
    non = [c for c in cands if not c["collapsed"]]
    pool = non if len(non) else cands

    def key(c):
        fe = c.get("fe_val", np.nan)
        fe = fe if np.isfinite(fe) else np.inf

        fm = c.get("fo_max", np.nan)
        fm = fm if np.isfinite(fm) else np.inf

        na = int(c.get("n_active", 0))

        fhe = c.get("fo_entropy", np.nan)
        fhe = fhe if np.isfinite(fhe) else -np.inf

        return (fe, fm, -na, -fhe)

    return sorted(pool, key=key)[0]
    
def clear_session():
    # Keep minimal teardown; full clear_session can be unstable on some setups.
    try:
        tf.keras.backend.clear_session()
    except Exception:
        pass
    gc_now()

```


```python
# =========================
# Cell 4 — LOSO-CV K-sweep (multi-seed anti-collapse) with explicit steps/epoch + chunked execution + resume
# =========================
def split_loso(df: pd.DataFrame):
    subs = sorted(df["subject"].unique().tolist())
    for fi, test_sub in enumerate(subs):
        train_idx = df.index[df["subject"] != test_sub].to_numpy()
        test_idx  = df.index[df["subject"] == test_sub].to_numpy()
        yield fi, test_sub, train_idx, test_idx

# Apply optional subset controls
K_GRID_RUN = DEBUG_K_GRID if DEBUG_K_GRID is not None else K_GRID
SEEDS_RUN  = DEBUG_SEEDS if DEBUG_SEEDS is not None else SEEDS

done = set()
if RESUME_IF_RESULTS_EXIST and CV_TSV.exists():
    prev = pd.read_csv(CV_TSV, sep="\t")
    for _, r in prev.iterrows():
        done.add((int(r["fold"]), int(r["K"])))
    print(f"[RESUME] existing rows={len(prev)} | done pairs={len(done)}")
else:
    print("[START] no previous results (or resume off)")

# We'll append to in-memory lists but also save incrementally
cv_rows = []
cand_rows = []
if RESUME_IF_RESULTS_EXIST and CV_TSV.exists():
    cv_rows = pd.read_csv(CV_TSV, sep="\t").to_dict("records")
if RESUME_IF_RESULTS_EXIST and CAND_TSV.exists():
    cand_rows = pd.read_csv(CAND_TSV, sep="\t").to_dict("records")

fold_meta = []
new_pairs_done = 0

for fold_i, test_sub, train_idx, test_idx in split_loso(manifest):
    if DEBUG_MAX_FOLDS is not None and fold_i >= int(DEBUG_MAX_FOLDS):
        print(f"[DEBUG] stopping after fold {fold_i}")
        break

    print(f"===== Fold {fold_i+1}/{manifest['subject'].nunique()} | test subject = {test_sub} =====")

    train_df = manifest.loc[train_idx].copy()
    test_df  = manifest.loc[test_idx].copy()

    val_sub = choose_val_subject(train_df)
    val_df = train_df.loc[train_df["subject"] == val_sub].copy()
    trn_df = train_df.loc[train_df["subject"] != val_sub].copy()

    # Raw segments
    X_trn_raw = [all_X[i] for i in trn_df["X_index"].tolist()]
    X_val_raw = [all_X[i] for i in val_df["X_index"].tolist()]
    X_tst_raw = [all_X[i] for i in test_df["X_index"].tolist()]

    trn_runs = trn_df["run"].tolist()
    val_runs = val_df["run"].tolist()
    tst_runs = test_df["run"].tolist()

    if USE_RUNWISE_ZSCORE:
        X_trn_raw = runwise_zscore_segments(X_trn_raw, trn_runs, slice(0, D_BOLD))
        X_trn_raw = runwise_zscore_segments(X_trn_raw, trn_runs, slice(D_BOLD, D_TOTAL))
        X_val_raw = runwise_zscore_segments(X_val_raw, val_runs, slice(0, D_BOLD))
        X_val_raw = runwise_zscore_segments(X_val_raw, val_runs, slice(D_BOLD, D_TOTAL))
        X_tst_raw = runwise_zscore_segments(X_tst_raw, tst_runs, slice(0, D_BOLD))
        X_tst_raw = runwise_zscore_segments(X_tst_raw, tst_runs, slice(D_BOLD, D_TOTAL))

    # Train-only PCA
    params, meta = make_fold_preproc(X_trn_raw)
    print(f"  PCA PVE(train): BOLD {100*meta['pve_bold']:.1f}% ({meta['n_bold_pcs']} PCs) | EEG {100*meta['pve_eeg']:.1f}% ({meta['n_eeg_pcs']} PCs)")
    print(f"  Fold D_pca={meta['D_pca']} | train segs={len(X_trn_raw)} | val segs={len(X_val_raw)} | test segs={len(X_tst_raw)}")

    X_trn = [apply_fold_preproc(X, params) for X in X_trn_raw]
    X_val = [apply_fold_preproc(X, params) for X in X_val_raw]
    X_tst = [apply_fold_preproc(X, params) for X in X_tst_raw]

    # Window counts -> explicit steps
    nwin_tr = count_windows_for_segments(X_trn)
    nwin_va = count_windows_for_segments(X_val)
    steps_tr = steps_from_windows(nwin_tr)
    steps_va = steps_from_windows(nwin_va)
    # FALLBACK: if drop_remainder rebatching makes steps==0 (very small split), disable rebatching for this fold.
    if steps_tr == 0 or steps_va == 0:
        if REBATCH_DROP_REMAINDER:
            print("[WARN] steps==0 under drop_remainder rebatching; disabling rebatch for this fold.")
            globals()["REBATCH_DROP_REMAINDER"] = False
            steps_tr = steps_from_windows(nwin_tr)
            steps_va = steps_from_windows(nwin_va)
    if steps_tr == 0 or steps_va == 0:
        raise RuntimeError(f"Zero steps in fold {fold_i}. Check SEQ_LEN/STEP_SIZE and segment lengths.")

    train_data = Data(X_trn)
    val_data   = Data(X_val)
    test_data  = Data(X_tst)

    fold_meta.append(dict(
        fold=fold_i, test_subject=test_sub, val_subject=val_sub,
        D_pca=meta["D_pca"], pve_bold=meta["pve_bold"], pve_eeg=meta["pve_eeg"],
        n_bold_pcs=meta["n_bold_pcs"], n_eeg_pcs=meta["n_eeg_pcs"],
        n_train_segments=len(X_trn), n_val_segments=len(X_val), n_test_segments=len(X_tst),
        nwin_train=int(nwin_tr), nwin_val=int(nwin_va),
        steps_per_epoch=int(steps_tr), validation_steps=int(steps_va),
        seq_len=int(SEQ_LEN), step_size=int(STEP_SIZE), batch_size=int(BATCH_SIZE),
        runwise_zscore=bool(USE_RUNWISE_ZSCORE)
    ))

    for K in K_GRID_RUN:
        if (fold_i, K) in done:
            continue

        cfg = make_config(K, meta["D_pca"])
        init_take = INIT_TAKE_BIGK if K >= BIGK_THRESH else INIT_TAKE

        print(f"  [K={K}] steps_per_epoch={steps_tr} | val_steps={steps_va} | seeds={SEEDS_RUN}")
        candidates = []

        # Candidate pass: evaluate each seed on val FE + collapse metrics
        for seed in SEEDS_RUN:
            print(f"    seed={seed} …", end=" ")
            clear_session()
            np.random.seed(int(seed))
            tf.random.set_seed(int(seed))

            train_ds = as_tf_dataset(train_data, shuffle=True)
            val_ds   = as_tf_dataset(val_data, shuffle=False)

            m = Model(cfg)
            try:
                # keep single init per seed (if supported)
                try:
                    m.random_subset_initialization(train_data, take=float(init_take), n_epochs=int(INIT_EPOCHS), n_init=1)
                except TypeError:
                    m.random_subset_initialization(train_data, take=float(init_take), n_epochs=int(INIT_EPOCHS))
            except Exception as e:
                print("INIT_FAIL")
                continue

            try:
                m.fit(
                    train_ds,
                    validation_data=val_ds,
                    steps_per_epoch=int(steps_tr),
                    validation_steps=int(steps_va),
                    callbacks=callbacks()
                )
            except TypeError:
                # some versions don't accept callbacks
                m.fit(
                    train_ds,
                    validation_data=val_ds,
                    steps_per_epoch=int(steps_tr),
                    validation_steps=int(steps_va),
                )
            except Exception as e:
                print("FIT_FAIL")
                continue

            try:
                fe_val = free_energy(m, val_data)
            except Exception:
                fe_val = np.nan

            try:
                alpha_val = get_alpha_list(m, val_data)

                # timepoint summary (kept for reporting)
                fo, fo_max, ent_norm, n_active = summarize_alpha(alpha_val, K)

                # global FO diversity (better for “collapse” meaning)
                fo_entropy, neff = fo_entropy_and_neff(fo, K)

                # collapse screen = global degeneracy only
                collapsed = is_collapsed(fo_max, n_active, K)
            except Exception:
                fo_max, ent_norm, n_active, collapsed = np.nan, np.nan, 0, True

            cand = dict(
                fold=fold_i, test_subject=test_sub, val_subject=val_sub,
                K=int(K), seed=int(seed), init_take=float(init_take),
                fe_val=float(fe_val) if np.isfinite(fe_val) else np.nan,
                fo_max=float(fo_max) if np.isfinite(fo_max) else np.nan,
                entropy_norm=float(ent_norm) if np.isfinite(ent_norm) else np.nan,  # kept for description
                n_active=int(n_active),
                fo_entropy=float(fo_entropy) if np.isfinite(fo_entropy) else np.nan,
                neff=float(neff) if np.isfinite(neff) else np.nan,
                collapsed=bool(collapsed),
            )
            candidates.append(cand)
            cand_rows.append(cand)
            print(f"FE_val={cand['fe_val']:.3f} | collapsed={cand['collapsed']}")

            # cleanup per seed
            try:
                del m, train_ds, val_ds, alpha_val
            except Exception:
                pass
            gc_now()

        if len(candidates) == 0:
            # record empty
            row = dict(fold=fold_i, test_subject=test_sub, val_subject=val_sub, K=int(K),
                       seed_selected=np.nan, collapsed=True,
                       fe_train=np.nan, fe_val=np.nan, fe_test=np.nan,
                       fo_max=np.nan, entropy_norm=np.nan, n_active=0,
                       n_seeds_tried=0, init_take=float(init_take),
                       D_pca=int(meta["D_pca"]),
                       feature_mode=FEATURE_MODE.lower(),
                       seq_len=int(SEQ_LEN), step_size=int(STEP_SIZE), batch_size=int(BATCH_SIZE),
                       runwise_zscore=bool(USE_RUNWISE_ZSCORE))
            cv_rows.append(row)
            done.add((fold_i, K))
        else:
            best = choose_best_candidate(candidates)
            print(f"    BEST seed={best['seed']} | collapsed={best['collapsed']} | FE_val={best['fe_val']:.3f} | FOmax={best['fo_max']:.3f} | Hnorm={best['entropy_norm']:.3f} | n_active={best['n_active']}")

            # Refit best seed once to compute train/test FE
            clear_session()
            np.random.seed(int(best["seed"]))
            tf.random.set_seed(int(best["seed"]))

            train_ds = as_tf_dataset(train_data, shuffle=True)
            val_ds   = as_tf_dataset(val_data, shuffle=False)

            m = Model(cfg)
            try:
                try:
                    m.random_subset_initialization(train_data, take=float(init_take), n_epochs=int(INIT_EPOCHS), n_init=1)
                except TypeError:
                    m.random_subset_initialization(train_data, take=float(init_take), n_epochs=int(INIT_EPOCHS))
                try:
                    m.fit(train_ds, validation_data=val_ds, steps_per_epoch=int(steps_tr), validation_steps=int(steps_va), callbacks=callbacks())
                except TypeError:
                    m.fit(train_ds, validation_data=val_ds, steps_per_epoch=int(steps_tr), validation_steps=int(steps_va))
                fe_tr = free_energy(m, train_data)
                fe_te = free_energy(m, test_data)
            except Exception as e:
                print("    [WARN] refit(best) failed:", repr(e))
                fe_tr = fe_te = np.nan

            row = dict(
                fold=fold_i, test_subject=test_sub, val_subject=val_sub, K=int(K),
                seed_selected=int(best["seed"]),
                collapsed=bool(best["collapsed"]),
                fe_train=float(fe_tr) if np.isfinite(fe_tr) else np.nan,
                fe_val=float(best["fe_val"]) if np.isfinite(best["fe_val"]) else np.nan,
                fe_test=float(fe_te) if np.isfinite(fe_te) else np.nan,
                fo_max=float(best["fo_max"]),
                entropy_norm=float(best["entropy_norm"]),
                fo_entropy=float(fo_entropy) if np.isfinite(fo_entropy) else np.nan,
                neff=float(neff) if np.isfinite(neff) else np.nan,
                n_active=int(best["n_active"]),
                n_seeds_tried=int(len(candidates)),
                init_take=float(init_take),
                D_pca=int(meta["D_pca"]),
                feature_mode=FEATURE_MODE.lower(),
                seq_len=int(SEQ_LEN), step_size=int(STEP_SIZE), batch_size=int(BATCH_SIZE),
                runwise_zscore=bool(USE_RUNWISE_ZSCORE),
            )
            cv_rows.append(row)
            done.add((fold_i, K))

            # cleanup
            try:
                del m, train_ds, val_ds
            except Exception:
                pass
            gc_now()

        # Incremental saves (resume-safe)
        pd.DataFrame(cv_rows).to_csv(CV_TSV, sep="\t", index=False)
        pd.DataFrame(cand_rows).to_csv(CAND_TSV, sep="\t", index=False)
        pd.DataFrame(fold_meta).to_csv(FOLD_META_TSV, sep="\t", index=False)

        new_pairs_done += 1
        if MAX_NEW_PAIRS_PER_RUN is not None and new_pairs_done >= int(MAX_NEW_PAIRS_PER_RUN):
            print(f"[CHUNK DONE] processed {new_pairs_done} new (fold,K) pairs. Saved and stopping to avoid OOM.")
            raise SystemExit("Chunk complete. Restart kernel and run Cell 4 again to resume.")

print("Finished full sweep.")

```

    [RESUME] existing rows=131 | done pairs=131
    ===== Fold 1/12 | test subject = sub-01 =====
      PCA PVE(train): BOLD 66.9% (40 PCs) | EEG 92.3% (40 PCs)
      Fold D_pca=80 | train segs=55 | val segs=10 | test segs=6



    Loading files:   0%|          | 0/55 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/10 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/6 [00:00<?, ?it/s]


    ===== Fold 2/12 | test subject = sub-02 =====
      PCA PVE(train): BOLD 67.3% (40 PCs) | EEG 92.1% (40 PCs)
      Fold D_pca=80 | train segs=59 | val segs=10 | test segs=2



    Loading files:   0%|          | 0/59 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/10 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/2 [00:00<?, ?it/s]


    ===== Fold 3/12 | test subject = sub-03 =====
      PCA PVE(train): BOLD 67.2% (40 PCs) | EEG 92.0% (40 PCs)
      Fold D_pca=80 | train segs=53 | val segs=10 | test segs=8



    Loading files:   0%|          | 0/53 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/10 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/8 [00:00<?, ?it/s]


    ===== Fold 4/12 | test subject = sub-08 =====
      PCA PVE(train): BOLD 67.7% (40 PCs) | EEG 92.0% (40 PCs)
      Fold D_pca=80 | train segs=51 | val segs=10 | test segs=10



    Loading files:   0%|          | 0/51 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/10 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/10 [00:00<?, ?it/s]


    ===== Fold 5/12 | test subject = sub-09 =====
      PCA PVE(train): BOLD 66.9% (40 PCs) | EEG 92.0% (40 PCs)
      Fold D_pca=80 | train segs=59 | val segs=10 | test segs=2



    Loading files:   0%|          | 0/59 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/10 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/2 [00:00<?, ?it/s]


    ===== Fold 6/12 | test subject = sub-13 =====
      PCA PVE(train): BOLD 67.2% (40 PCs) | EEG 92.4% (40 PCs)
      Fold D_pca=80 | train segs=52 | val segs=10 | test segs=9



    Loading files:   0%|          | 0/52 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/10 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/9 [00:00<?, ?it/s]


    ===== Fold 7/12 | test subject = sub-14 =====
      PCA PVE(train): BOLD 67.5% (40 PCs) | EEG 92.3% (40 PCs)
      Fold D_pca=80 | train segs=57 | val segs=10 | test segs=4



    Loading files:   0%|          | 0/57 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/10 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/4 [00:00<?, ?it/s]


    ===== Fold 8/12 | test subject = sub-16 =====
      PCA PVE(train): BOLD 67.8% (40 PCs) | EEG 91.7% (40 PCs)
      Fold D_pca=80 | train segs=56 | val segs=10 | test segs=5



    Loading files:   0%|          | 0/56 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/10 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/5 [00:00<?, ?it/s]


    ===== Fold 9/12 | test subject = sub-17 =====
      PCA PVE(train): BOLD 67.7% (40 PCs) | EEG 92.0% (40 PCs)
      Fold D_pca=80 | train segs=51 | val segs=10 | test segs=10



    Loading files:   0%|          | 0/51 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/10 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/10 [00:00<?, ?it/s]


    ===== Fold 10/12 | test subject = sub-18 =====
      PCA PVE(train): BOLD 67.6% (40 PCs) | EEG 92.3% (40 PCs)
      Fold D_pca=80 | train segs=55 | val segs=10 | test segs=6



    Loading files:   0%|          | 0/55 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/10 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/6 [00:00<?, ?it/s]


    ===== Fold 11/12 | test subject = sub-20 =====
      PCA PVE(train): BOLD 68.8% (40 PCs) | EEG 92.0% (40 PCs)
      Fold D_pca=80 | train segs=58 | val segs=10 | test segs=3



    Loading files:   0%|          | 0/58 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/10 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/3 [00:00<?, ?it/s]


    ===== Fold 12/12 | test subject = sub-21 =====
      PCA PVE(train): BOLD 67.5% (40 PCs) | EEG 92.1% (40 PCs)
      Fold D_pca=80 | train segs=55 | val segs=10 | test segs=6



    Loading files:   0%|          | 0/55 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/10 [00:00<?, ?it/s]



    Loading files:   0%|          | 0/6 [00:00<?, ?it/s]


      [K=12] steps_per_epoch=157 | val_steps=21 | seeds=[11, 23, 37, 53, 71]
        seed=11 … 

    WARNING: All log messages before absl::InitializeLog() is called are written to STDERR
    I0000 00:00:1771929745.977526  408332 cuda_solvers.cc:175] Creating GpuSolver handles for stream 0x62c25250c2f0
    2026-02-24 18:42:27 INFO osl-dynamics [inf_mod_base.py:1321:random_subset_initialization]: Random subset initialization
    2026-02-24 18:42:27 INFO osl-dynamics [inf_mod_base.py:1332:random_subset_initialization]: Using 4 out of 18 batches
    2026-02-24 18:42:27 INFO osl-dynamics [inf_mod_base.py:1337:random_subset_initialization]: Initialization 0


    Epoch 1/5


    I0000 00:00:1771929756.696570  408369 service.cc:152] XLA service 0x7348080e5700 initialized for platform CUDA (this does not guarantee that XLA will be used). Devices:
    I0000 00:00:1771929756.696610  408369 service.cc:160]   StreamExecutor device (0): NVIDIA GeForce RTX 4060 Laptop GPU, Compute Capability 8.9
    2026-02-24 18:42:37.268342: I tensorflow/compiler/mlir/tensorflow/utils/dump_mlir_util.cc:269] disabling MLIR crash reproducer, set env var `MLIR_CRASH_REPRODUCER_DIRECTORY` to enable.
    I0000 00:00:1771929758.809952  408369 cuda_dnn.cc:529] Loaded cuDNN version 90501
    I0000 00:00:1771929762.388339  408369 device_compiler.h:188] Compiled cluster using XLA!  This line is logged at most once for the lifetime of the process.


    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m15s[0m 67ms/step - ll_loss: 230.4942 - loss: 230.4942 - learning_rate: 0.0010 - rho: 0.2853
    Epoch 2/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m5s[0m 2s/step - ll_loss: 211.9278 - loss: 213.7491 - learning_rate: 9.0484e-04 - rho: 0.2403
    Epoch 3/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 47ms/step - ll_loss: 231.3797 - loss: 227.7335 - learning_rate: 8.1873e-04 - rho: 0.2094
    Epoch 4/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 40ms/step - ll_loss: 225.9559 - loss: 225.9559 - learning_rate: 7.4082e-04 - rho: 0.1866
    Epoch 5/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 30ms/step - ll_loss: 204.0105 - loss: 208.4055 - learning_rate: 6.7032e-04 - rho: 0.1691


    2026-02-24 18:42:48 INFO osl-dynamics [inf_mod_base.py:1365:random_subset_initialization]: Using initialization 0


    Epoch 1/60
    [1m137/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 18ms/step - ll_loss: 207.6208 - loss: 207.6208

    2026-02-24 18:43:04.275114: I tensorflow/core/framework/local_rendezvous.cc:407] Local rendezvous is aborting with status: OUT_OF_RANGE: End of sequence
    	 [[{{node IteratorGetNext}}]]
    2026-02-24 18:43:04.275211: I tensorflow/core/framework/local_rendezvous.cc:407] Local rendezvous is aborting with status: OUT_OF_RANGE: End of sequence
    	 [[{{node IteratorGetNext}}]]
    	 [[IteratorGetNext/_2]]
    2026-02-24 18:43:04.275252: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    /home/gincru/miniforge3/envs/osl_gpu/lib/python3.12/site-packages/keras/src/trainers/epoch_iterator.py:160: UserWarning: Your input ran out of data; interrupting training. Make sure that your dataset or generator can generate at least `steps_per_epoch * epochs` batches. You may need to use the `.repeat()` function when building your dataset.
      self._interrupted_warning()


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m19s[0m 39ms/step - ll_loss: 207.9816 - loss: 207.9816 - val_ll_loss: 196.4883 - val_loss: 196.4883 - learning_rate: 0.0010 - rho: 0.2853
    Epoch 2/60


    2026-02-24 18:43:07.800174: I tensorflow/core/framework/local_rendezvous.cc:407] Local rendezvous is aborting with status: OUT_OF_RANGE: End of sequence
    	 [[{{node IteratorGetNext}}]]
    	 [[IteratorGetNext/_2]]
    2026-02-24 18:43:07.800326: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 21ms/step - ll_loss: 199.9511 - loss: 199.9511

    2026-02-24 18:43:11.499556: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 20ms/step - ll_loss: 199.6439 - loss: 199.6439 - val_ll_loss: 186.8318 - val_loss: 186.8317 - learning_rate: 9.0484e-04 - rho: 0.2403
    Epoch 3/60


    2026-02-24 18:43:11.710588: I tensorflow/core/framework/local_rendezvous.cc:407] Local rendezvous is aborting with status: OUT_OF_RANGE: End of sequence
    	 [[{{node IteratorGetNext}}]]
    	 [[IteratorGetNext/_2]]
    2026-02-24 18:43:11.710731: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 15ms/step - ll_loss: 194.0950 - loss: 194.0950

    2026-02-24 18:43:14.590215: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 15ms/step - ll_loss: 193.3151 - loss: 193.3151 - val_ll_loss: 179.7502 - val_loss: 179.7501 - learning_rate: 8.1873e-04 - rho: 0.2094
    Epoch 4/60


    2026-02-24 18:43:14.791467: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 17ms/step - ll_loss: 180.5800 - loss: 180.5800

    2026-02-24 18:43:17.999252: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 17ms/step - ll_loss: 180.5985 - loss: 180.5985 - val_ll_loss: 174.4968 - val_loss: 174.4968 - learning_rate: 7.4082e-04 - rho: 0.1866
    Epoch 5/60


    2026-02-24 18:43:18.252688: I tensorflow/core/framework/local_rendezvous.cc:407] Local rendezvous is aborting with status: OUT_OF_RANGE: End of sequence
    	 [[{{node IteratorGetNext}}]]
    	 [[IteratorGetNext/_2]]
    2026-02-24 18:43:18.252984: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m137/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 15ms/step - ll_loss: 172.8561 - loss: 172.8561

    2026-02-24 18:43:21.176271: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 15ms/step - ll_loss: 173.1979 - loss: 173.1980 - val_ll_loss: 170.3440 - val_loss: 170.3440 - learning_rate: 6.7032e-04 - rho: 0.1691
    Epoch 6/60


    2026-02-24 18:43:21.388779: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 17ms/step - ll_loss: 174.8432 - loss: 174.8432

    2026-02-24 18:43:24.550327: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:43:24.747593: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 16ms/step - ll_loss: 174.4146 - loss: 174.4147 - val_ll_loss: 166.9667 - val_loss: 166.9667 - learning_rate: 6.0653e-04 - rho: 0.1551
    Epoch 7/60
    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 17ms/step - ll_loss: 166.1630 - loss: 166.1630

    2026-02-24 18:43:27.920565: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:43:28.119244: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 16ms/step - ll_loss: 166.3474 - loss: 166.3474 - val_ll_loss: 164.0729 - val_loss: 164.0729 - learning_rate: 5.4881e-04 - rho: 0.1436
    Epoch 8/60
    [1m137/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 17ms/step - ll_loss: 166.9430 - loss: 166.9430

    2026-02-24 18:43:31.401157: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:43:31.602519: I tensorflow/core/framework/local_rendezvous.cc:407] Local rendezvous is aborting with status: OUT_OF_RANGE: End of sequence
    	 [[{{node IteratorGetNext}}]]
    	 [[IteratorGetNext/_2]]


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 17ms/step - ll_loss: 166.6685 - loss: 166.6685 - val_ll_loss: 161.6257 - val_loss: 161.6257 - learning_rate: 4.9659e-04 - rho: 0.1340
    Epoch 9/60


    2026-02-24 18:43:31.602701: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 15ms/step - ll_loss: 163.5924 - loss: 163.5925

    2026-02-24 18:43:34.454687: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 15ms/step - ll_loss: 163.4273 - loss: 163.4274 - val_ll_loss: 159.5069 - val_loss: 159.5069 - learning_rate: 4.4933e-04 - rho: 0.1258
    Epoch 10/60


    2026-02-24 18:43:34.674773: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 16ms/step - ll_loss: 155.0886 - loss: 155.0886

    2026-02-24 18:43:37.710847: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:43:37.908381: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 15ms/step - ll_loss: 155.6103 - loss: 155.6102 - val_ll_loss: 157.8068 - val_loss: 157.8068 - learning_rate: 4.0657e-04 - rho: 0.1187
    Epoch 11/60
    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 19ms/step - ll_loss: 159.1171 - loss: 159.1171

    2026-02-24 18:43:41.300890: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 18ms/step - ll_loss: 159.0018 - loss: 159.0017 - val_ll_loss: 156.3631 - val_loss: 156.3631 - learning_rate: 3.6788e-04 - rho: 0.1125
    Epoch 12/60


    2026-02-24 18:43:41.521277: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 16ms/step - ll_loss: 156.7137 - loss: 156.7136

    2026-02-24 18:43:44.567569: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 16ms/step - ll_loss: 156.6866 - loss: 156.6865 - val_ll_loss: 155.1395 - val_loss: 155.1395 - learning_rate: 3.3287e-04 - rho: 0.1071
    Epoch 13/60


    2026-02-24 18:43:44.773861: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 16ms/step - ll_loss: 155.0612 - loss: 155.0611

    2026-02-24 18:43:47.887770: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 16ms/step - ll_loss: 155.0726 - loss: 155.0726 - val_ll_loss: 154.1913 - val_loss: 154.1912 - learning_rate: 3.0119e-04 - rho: 0.1022
    Epoch 14/60


    2026-02-24 18:43:48.137311: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 17ms/step - ll_loss: 152.8282 - loss: 152.8281

    2026-02-24 18:43:51.382502: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 17ms/step - ll_loss: 152.9645 - loss: 152.9644 - val_ll_loss: 153.3338 - val_loss: 153.3338 - learning_rate: 2.7253e-04 - rho: 0.0979
    Epoch 15/60


    2026-02-24 18:43:51.632106: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 17ms/step - ll_loss: 154.6609 - loss: 154.6608

    2026-02-24 18:43:54.884477: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 17ms/step - ll_loss: 154.4647 - loss: 154.4646 - val_ll_loss: 152.6270 - val_loss: 152.6270 - learning_rate: 2.4660e-04 - rho: 0.0939
    Epoch 16/60


    2026-02-24 18:43:55.133280: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 19ms/step - ll_loss: 156.4355 - loss: 156.4355

    2026-02-24 18:43:58.706154: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 18ms/step - ll_loss: 155.9226 - loss: 155.9226 - val_ll_loss: 152.0127 - val_loss: 152.0127 - learning_rate: 2.2313e-04 - rho: 0.0904
    Epoch 17/60


    2026-02-24 18:43:58.937233: I tensorflow/core/framework/local_rendezvous.cc:407] Local rendezvous is aborting with status: OUT_OF_RANGE: End of sequence
    	 [[{{node IteratorGetNext}}]]
    	 [[IteratorGetNext/_2]]
    2026-02-24 18:43:58.937337: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 18ms/step - ll_loss: 152.0114 - loss: 152.0114

    2026-02-24 18:44:02.280975: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 18ms/step - ll_loss: 151.9429 - loss: 151.9429 - val_ll_loss: 151.4275 - val_loss: 151.4275 - learning_rate: 2.0190e-04 - rho: 0.0871
    Epoch 18/60


    2026-02-24 18:44:02.516126: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 19ms/step - ll_loss: 149.5959 - loss: 149.5959

    2026-02-24 18:44:06.013276: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 18ms/step - ll_loss: 149.7303 - loss: 149.7303 - val_ll_loss: 150.9582 - val_loss: 150.9582 - learning_rate: 1.8268e-04 - rho: 0.0841
    Epoch 19/60


    2026-02-24 18:44:06.251648: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 17ms/step - ll_loss: 150.5894 - loss: 150.5894

    2026-02-24 18:44:09.495979: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 17ms/step - ll_loss: 150.5456 - loss: 150.5457 - val_ll_loss: 150.5582 - val_loss: 150.5582 - learning_rate: 1.6530e-04 - rho: 0.0814
    Epoch 20/60


    2026-02-24 18:44:09.747997: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 19ms/step - ll_loss: 149.1304 - loss: 149.1304

    2026-02-24 18:44:13.296578: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 18ms/step - ll_loss: 149.1952 - loss: 149.1952 - val_ll_loss: 150.1393 - val_loss: 150.1393 - learning_rate: 1.4957e-04 - rho: 0.0789
    Epoch 21/60


    2026-02-24 18:44:13.550668: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 19ms/step - ll_loss: 151.3609 - loss: 151.3610

    2026-02-24 18:44:17.187256: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 19ms/step - ll_loss: 151.1004 - loss: 151.1004 - val_ll_loss: 149.7874 - val_loss: 149.7874 - learning_rate: 1.3534e-04 - rho: 0.0765
    Epoch 22/60


    2026-02-24 18:44:17.433292: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 19ms/step - ll_loss: 151.3227 - loss: 151.3226

    2026-02-24 18:44:20.952524: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 18ms/step - ll_loss: 151.0323 - loss: 151.0322 - val_ll_loss: 149.5009 - val_loss: 149.5009 - learning_rate: 1.2246e-04 - rho: 0.0743
    Epoch 23/60


    2026-02-24 18:44:21.188286: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m137/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 17ms/step - ll_loss: 148.7258 - loss: 148.7258

    2026-02-24 18:44:24.415674: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 17ms/step - ll_loss: 148.6861 - loss: 148.6861 - val_ll_loss: 149.2144 - val_loss: 149.2143 - learning_rate: 1.1080e-04 - rho: 0.0723
    Epoch 24/60


    2026-02-24 18:44:24.654859: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 18ms/step - ll_loss: 146.5978 - loss: 146.5978

    2026-02-24 18:44:28.076324: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 18ms/step - ll_loss: 146.7593 - loss: 146.7593 - val_ll_loss: 148.9603 - val_loss: 148.9603 - learning_rate: 1.0026e-04 - rho: 0.0704
    Epoch 25/60


    2026-02-24 18:44:28.321307: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m137/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 17ms/step - ll_loss: 148.6127 - loss: 148.6127

    2026-02-24 18:44:31.453674: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 16ms/step - ll_loss: 148.5101 - loss: 148.5102 - val_ll_loss: 148.7380 - val_loss: 148.7380 - learning_rate: 9.0718e-05 - rho: 0.0686
    Epoch 26/60


    2026-02-24 18:44:31.659529: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 16ms/step - ll_loss: 151.0088 - loss: 151.0089

    2026-02-24 18:44:34.789503: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 16ms/step - ll_loss: 150.6090 - loss: 150.6091 - val_ll_loss: 148.5215 - val_loss: 148.5215 - learning_rate: 8.2085e-05 - rho: 0.0669
    Epoch 27/60


    2026-02-24 18:44:35.008469: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 18ms/step - ll_loss: 145.1966 - loss: 145.1966

    2026-02-24 18:44:38.415839: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 18ms/step - ll_loss: 145.4355 - loss: 145.4356 - val_ll_loss: 148.3539 - val_loss: 148.3539 - learning_rate: 7.4274e-05 - rho: 0.0653
    Epoch 28/60


    2026-02-24 18:44:38.688587: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 17ms/step - ll_loss: 147.3918 - loss: 147.3917

    2026-02-24 18:44:41.890035: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 17ms/step - ll_loss: 147.3525 - loss: 147.3525 - val_ll_loss: 148.1911 - val_loss: 148.1911 - learning_rate: 6.7206e-05 - rho: 0.0638
    Epoch 29/60


    2026-02-24 18:44:42.103121: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m137/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 17ms/step - ll_loss: 146.2423 - loss: 146.2422

    2026-02-24 18:44:45.296936: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 17ms/step - ll_loss: 146.3222 - loss: 146.3222 - val_ll_loss: 148.0381 - val_loss: 148.0381 - learning_rate: 6.0810e-05 - rho: 0.0624
    Epoch 30/60


    2026-02-24 18:44:45.515734: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 15ms/step - ll_loss: 148.1853 - loss: 148.1853

    2026-02-24 18:44:48.521438: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:44:48.718674: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 15ms/step - ll_loss: 148.0130 - loss: 148.0130 - val_ll_loss: 147.8987 - val_loss: 147.8987 - learning_rate: 5.5023e-05 - rho: 0.0610
    Epoch 31/60
    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 17ms/step - ll_loss: 144.5149 - loss: 144.5149

    2026-02-24 18:44:51.973861: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 17ms/step - ll_loss: 144.7583 - loss: 144.7583 - val_ll_loss: 147.7646 - val_loss: 147.7646 - learning_rate: 4.9787e-05 - rho: 0.0597
    Epoch 32/60


    2026-02-24 18:44:52.181115: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 16ms/step - ll_loss: 147.6935 - loss: 147.6935

    2026-02-24 18:44:55.222935: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 15ms/step - ll_loss: 147.5345 - loss: 147.5345 - val_ll_loss: 147.6638 - val_loss: 147.6638 - learning_rate: 4.5049e-05 - rho: 0.0585
    Epoch 33/60


    2026-02-24 18:44:55.443287: I tensorflow/core/framework/local_rendezvous.cc:407] Local rendezvous is aborting with status: OUT_OF_RANGE: End of sequence
    	 [[{{node IteratorGetNext}}]]
    	 [[IteratorGetNext/_2]]
    2026-02-24 18:44:55.443382: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 16ms/step - ll_loss: 147.7170 - loss: 147.7170

    2026-02-24 18:44:58.458041: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 16ms/step - ll_loss: 147.5575 - loss: 147.5574 - val_ll_loss: 147.5567 - val_loss: 147.5567 - learning_rate: 4.0762e-05 - rho: 0.0574
    Epoch 34/60


    2026-02-24 18:44:58.677674: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 16ms/step - ll_loss: 146.6353 - loss: 146.6353

    2026-02-24 18:45:01.814629: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 16ms/step - ll_loss: 146.5728 - loss: 146.5728 - val_ll_loss: 147.4758 - val_loss: 147.4758 - learning_rate: 3.6883e-05 - rho: 0.0563
    Epoch 35/60


    2026-02-24 18:45:02.036782: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 16ms/step - ll_loss: 146.0154 - loss: 146.0154

    2026-02-24 18:45:05.103222: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 15ms/step - ll_loss: 146.0153 - loss: 146.0152 - val_ll_loss: 147.3763 - val_loss: 147.3764 - learning_rate: 3.3373e-05 - rho: 0.0552
    Epoch 36/60


    2026-02-24 18:45:05.306192: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 15ms/step - ll_loss: 145.8209 - loss: 145.8209

    2026-02-24 18:45:08.298533: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:45:08.497249: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 15ms/step - ll_loss: 145.8317 - loss: 145.8317 - val_ll_loss: 147.3170 - val_loss: 147.3170 - learning_rate: 3.0197e-05 - rho: 0.0542
    Epoch 37/60
    [1m137/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 16ms/step - ll_loss: 146.1573 - loss: 146.1573

    2026-02-24 18:45:11.660285: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 16ms/step - ll_loss: 146.1173 - loss: 146.1172 - val_ll_loss: 147.2362 - val_loss: 147.2362 - learning_rate: 2.7324e-05 - rho: 0.0532
    Epoch 38/60


    2026-02-24 18:45:11.865888: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 16ms/step - ll_loss: 145.0125 - loss: 145.0125

    2026-02-24 18:45:15.021048: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:45:15.217041: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 15ms/step - ll_loss: 145.0919 - loss: 145.0919 - val_ll_loss: 147.1849 - val_loss: 147.1849 - learning_rate: 2.4724e-05 - rho: 0.0523
    Epoch 39/60
    [1m137/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 16ms/step - ll_loss: 148.3702 - loss: 148.3701

    2026-02-24 18:45:18.317512: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:45:18.515978: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 15ms/step - ll_loss: 148.0269 - loss: 148.0269 - val_ll_loss: 147.1287 - val_loss: 147.1287 - learning_rate: 2.2371e-05 - rho: 0.0514
    Epoch 40/60
    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 16ms/step - ll_loss: 146.4205 - loss: 146.4205

    2026-02-24 18:45:21.586004: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 15ms/step - ll_loss: 146.3271 - loss: 146.3271 - val_ll_loss: 147.0759 - val_loss: 147.0760 - learning_rate: 2.0242e-05 - rho: 0.0506
    Epoch 41/60


    2026-02-24 18:45:21.823746: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 18ms/step - ll_loss: 145.6257 - loss: 145.6257

    2026-02-24 18:45:25.356028: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 18ms/step - ll_loss: 145.6171 - loss: 145.6171 - val_ll_loss: 147.0255 - val_loss: 147.0255 - learning_rate: 1.8316e-05 - rho: 0.0498
    Epoch 42/60


    2026-02-24 18:45:25.587348: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 17ms/step - ll_loss: 145.1904 - loss: 145.1904

    2026-02-24 18:45:28.649758: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 16ms/step - ll_loss: 145.2247 - loss: 145.2247 - val_ll_loss: 146.9811 - val_loss: 146.9812 - learning_rate: 1.6573e-05 - rho: 0.0490
    Epoch 43/60


    2026-02-24 18:45:28.881886: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 20ms/step - ll_loss: 146.0963 - loss: 146.0962

    2026-02-24 18:45:32.589059: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 20ms/step - ll_loss: 146.0214 - loss: 146.0213 - val_ll_loss: 146.9460 - val_loss: 146.9460 - learning_rate: 1.4996e-05 - rho: 0.0482
    Epoch 44/60


    2026-02-24 18:45:32.873203: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m137/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 17ms/step - ll_loss: 146.2368 - loss: 146.2368

    2026-02-24 18:45:36.206418: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 17ms/step - ll_loss: 146.1241 - loss: 146.1241 - val_ll_loss: 146.9034 - val_loss: 146.9034 - learning_rate: 1.3569e-05 - rho: 0.0475
    Epoch 45/60


    2026-02-24 18:45:36.433504: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 17ms/step - ll_loss: 144.7116 - loss: 144.7116

    2026-02-24 18:45:39.716263: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 17ms/step - ll_loss: 144.7897 - loss: 144.7897 - val_ll_loss: 146.8691 - val_loss: 146.8690 - learning_rate: 1.2277e-05 - rho: 0.0468
    Epoch 46/60


    2026-02-24 18:45:39.958822: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 19ms/step - ll_loss: 148.7277 - loss: 148.7276

    2026-02-24 18:45:43.634409: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 18ms/step - ll_loss: 148.3590 - loss: 148.3589 - val_ll_loss: 146.8378 - val_loss: 146.8378 - learning_rate: 1.1109e-05 - rho: 0.0461
    Epoch 47/60


    2026-02-24 18:45:43.879531: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 18ms/step - ll_loss: 144.5360 - loss: 144.5359

    2026-02-24 18:45:47.486244: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 18ms/step - ll_loss: 144.6257 - loss: 144.6256 - val_ll_loss: 146.7868 - val_loss: 146.7868 - learning_rate: 1.0052e-05 - rho: 0.0455
    Epoch 48/60


    2026-02-24 18:45:47.763840: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m137/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 18ms/step - ll_loss: 146.3134 - loss: 146.3134

    2026-02-24 18:45:51.108244: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 18ms/step - ll_loss: 146.1797 - loss: 146.1797 - val_ll_loss: 146.7931 - val_loss: 146.7930 - learning_rate: 9.0953e-06 - rho: 0.0449
    Epoch 49/60


    2026-02-24 18:45:51.348620: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 19ms/step - ll_loss: 144.1129 - loss: 144.1128

    2026-02-24 18:45:54.837234: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 18ms/step - ll_loss: 144.2336 - loss: 144.2336 - val_ll_loss: 146.7811 - val_loss: 146.7811 - learning_rate: 8.2297e-06 - rho: 0.0442
    Epoch 50/60


    2026-02-24 18:45:55.084114: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 20ms/step - ll_loss: 143.8219 - loss: 143.8219

    2026-02-24 18:45:58.927717: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 20ms/step - ll_loss: 143.9718 - loss: 143.9718 - val_ll_loss: 146.7316 - val_loss: 146.7316 - learning_rate: 7.4466e-06 - rho: 0.0437
    Epoch 51/60


    2026-02-24 18:45:59.172947: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 18ms/step - ll_loss: 144.6049 - loss: 144.6050

    2026-02-24 18:46:02.548929: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 18ms/step - ll_loss: 144.6717 - loss: 144.6717 - val_ll_loss: 146.7031 - val_loss: 146.7031 - learning_rate: 6.7379e-06 - rho: 0.0431
    Epoch 52/60


    2026-02-24 18:46:02.781663: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 19ms/step - ll_loss: 144.4424 - loss: 144.4424

    2026-02-24 18:46:06.254632: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 19ms/step - ll_loss: 144.5299 - loss: 144.5299 - val_ll_loss: 146.7139 - val_loss: 146.7139 - learning_rate: 6.0967e-06 - rho: 0.0425
    Epoch 53/60


    2026-02-24 18:46:06.505385: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 21ms/step - ll_loss: 142.7463 - loss: 142.7462

    2026-02-24 18:46:10.319767: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 20ms/step - ll_loss: 143.0377 - loss: 143.0377 - val_ll_loss: 146.6772 - val_loss: 146.6772 - learning_rate: 5.5166e-06 - rho: 0.0420
    Epoch 54/60


    2026-02-24 18:46:10.565606: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 19ms/step - ll_loss: 144.2145 - loss: 144.2145

    2026-02-24 18:46:14.299357: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 19ms/step - ll_loss: 144.3135 - loss: 144.3135 - val_ll_loss: 146.6974 - val_loss: 146.6974 - learning_rate: 4.9916e-06 - rho: 0.0415
    Epoch 55/60


    2026-02-24 18:46:14.554138: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 21ms/step - ll_loss: 144.2175 - loss: 144.2174

    2026-02-24 18:46:18.405365: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 21ms/step - ll_loss: 144.3147 - loss: 144.3146 - val_ll_loss: 146.6772 - val_loss: 146.6772 - learning_rate: 4.5166e-06 - rho: 0.0410
    Epoch 56/60


    2026-02-24 18:46:18.666705: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 19ms/step - ll_loss: 144.2993 - loss: 144.2992

    2026-02-24 18:46:22.136214: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 18ms/step - ll_loss: 144.3965 - loss: 144.3965 - val_ll_loss: 146.6611 - val_loss: 146.6611 - learning_rate: 4.0868e-06 - rho: 0.0405
    Epoch 57/60


    2026-02-24 18:46:22.370120: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m137/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 19ms/step - ll_loss: 146.4622 - loss: 146.4623

    2026-02-24 18:46:25.843811: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 18ms/step - ll_loss: 146.2902 - loss: 146.2903 - val_ll_loss: 146.6540 - val_loss: 146.6539 - learning_rate: 3.6979e-06 - rho: 0.0400
    Epoch 58/60


    2026-02-24 18:46:26.072481: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 19ms/step - ll_loss: 145.5791 - loss: 145.5791

    2026-02-24 18:46:29.610242: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 19ms/step - ll_loss: 145.5215 - loss: 145.5215 - val_ll_loss: 146.6571 - val_loss: 146.6571 - learning_rate: 3.3460e-06 - rho: 0.0395
    Epoch 59/60


    2026-02-24 18:46:29.897192: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 17ms/step - ll_loss: 143.7192 - loss: 143.7191

    2026-02-24 18:46:33.107818: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 16ms/step - ll_loss: 143.8650 - loss: 143.8650 - val_ll_loss: 146.6308 - val_loss: 146.6308 - learning_rate: 3.0276e-06 - rho: 0.0391
    Epoch 60/60


    2026-02-24 18:46:33.338795: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m137/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 14ms/step - ll_loss: 144.6741 - loss: 144.6741

    2026-02-24 18:46:36.226949: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 14ms/step - ll_loss: 144.7226 - loss: 144.7226 - val_ll_loss: 146.6078 - val_loss: 146.6078 - learning_rate: 2.7394e-06 - rho: 0.0386


    2026-02-24 18:46:36.429527: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624



    Getting free energy: 0it [00:00, ?it/s]



    Getting alpha:   0%|          | 0/10 [00:00<?, ?it/s]


    FE_val=147.287 | collapsed=False
        seed=23 … 

    2026-02-24 18:46:54 INFO osl-dynamics [inf_mod_base.py:1321:random_subset_initialization]: Random subset initialization
    2026-02-24 18:46:55 INFO osl-dynamics [inf_mod_base.py:1332:random_subset_initialization]: Using 4 out of 18 batches
    2026-02-24 18:46:55 INFO osl-dynamics [inf_mod_base.py:1337:random_subset_initialization]: Initialization 0


    Epoch 1/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m13s[0m 1s/step - ll_loss: 221.4466 - loss: 229.7017 - learning_rate: 0.0010 - rho: 0.2853
    Epoch 2/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 36ms/step - ll_loss: 235.1483 - loss: 235.1483 - learning_rate: 9.0484e-04 - rho: 0.2403
    Epoch 3/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 29ms/step - ll_loss: 228.9389 - loss: 228.9389 - learning_rate: 8.1873e-04 - rho: 0.2094
    Epoch 4/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 23ms/step - ll_loss: 244.4066 - loss: 244.4066 - learning_rate: 7.4082e-04 - rho: 0.1866
    Epoch 5/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 22ms/step - ll_loss: 220.6764 - loss: 233.1075 - learning_rate: 6.7032e-04 - rho: 0.1691


    2026-02-24 18:47:09 INFO osl-dynamics [inf_mod_base.py:1365:random_subset_initialization]: Using initialization 0


    Epoch 1/60
    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 13ms/step - ll_loss: 209.5892 - loss: 209.5892

    2026-02-24 18:47:20.593901: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m15s[0m 35ms/step - ll_loss: 209.3989 - loss: 209.3989 - val_ll_loss: 195.2534 - val_loss: 195.2534 - learning_rate: 0.0010 - rho: 0.2853
    Epoch 2/60


    2026-02-24 18:47:24.119998: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 200.1162 - loss: 200.1161 - val_ll_loss: 187.2710 - val_loss: 187.2710 - learning_rate: 9.0484e-04 - rho: 0.2403
    Epoch 3/60


    2026-02-24 18:47:26.470079: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:47:26.630566: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 195.6574 - loss: 195.6573 - val_ll_loss: 181.4204 - val_loss: 181.4205 - learning_rate: 8.1873e-04 - rho: 0.2094
    Epoch 4/60


    2026-02-24 18:47:28.884861: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:47:29.025769: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 179.6023 - loss: 179.6023 - val_ll_loss: 176.8336 - val_loss: 176.8336 - learning_rate: 7.4082e-04 - rho: 0.1866
    Epoch 5/60


    2026-02-24 18:47:31.252247: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:47:31.424272: I tensorflow/core/framework/local_rendezvous.cc:407] Local rendezvous is aborting with status: OUT_OF_RANGE: End of sequence
    	 [[{{node IteratorGetNext}}]]
    2026-02-24 18:47:31.424344: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 177.0293 - loss: 177.0293 - val_ll_loss: 173.0867 - val_loss: 173.0866 - learning_rate: 6.7032e-04 - rho: 0.1691
    Epoch 6/60


    2026-02-24 18:47:33.730635: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:47:33.902442: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 172.8494 - loss: 172.8494 - val_ll_loss: 170.0067 - val_loss: 170.0067 - learning_rate: 6.0653e-04 - rho: 0.1551
    Epoch 7/60


    2026-02-24 18:47:36.052693: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:47:36.209797: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m137/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 11ms/step - ll_loss: 170.2127 - loss: 170.2126

    2026-02-24 18:47:38.238493: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:47:38.437105: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 170.1716 - loss: 170.1715 - val_ll_loss: 167.2393 - val_loss: 167.2393 - learning_rate: 5.4881e-04 - rho: 0.1436
    Epoch 8/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 167.5084 - loss: 167.5084 - val_ll_loss: 164.9379 - val_loss: 164.9378 - learning_rate: 4.9659e-04 - rho: 0.1340
    Epoch 9/60


    2026-02-24 18:47:40.697910: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:47:40.842805: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 168.0601 - loss: 168.0601 - val_ll_loss: 162.8543 - val_loss: 162.8543 - learning_rate: 4.4933e-04 - rho: 0.1258
    Epoch 10/60


    2026-02-24 18:47:42.959870: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:47:43.117344: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 161.5290 - loss: 161.5291 - val_ll_loss: 161.1451 - val_loss: 161.1451 - learning_rate: 4.0657e-04 - rho: 0.1187
    Epoch 11/60


    2026-02-24 18:47:45.245952: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:47:45.413953: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 165.6171 - loss: 165.6172 - val_ll_loss: 159.7490 - val_loss: 159.7490 - learning_rate: 3.6788e-04 - rho: 0.1125
    Epoch 12/60


    2026-02-24 18:47:47.693316: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:47:47.855534: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 158.4500 - loss: 158.4500 - val_ll_loss: 158.5052 - val_loss: 158.5053 - learning_rate: 3.3287e-04 - rho: 0.1071
    Epoch 13/60


    2026-02-24 18:47:50.282637: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:47:50.449643: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 160.4623 - loss: 160.4623 - val_ll_loss: 157.4413 - val_loss: 157.4413 - learning_rate: 3.0119e-04 - rho: 0.1022
    Epoch 14/60


    2026-02-24 18:47:52.805617: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:47:52.982194: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 156.5981 - loss: 156.5981 - val_ll_loss: 156.5276 - val_loss: 156.5276 - learning_rate: 2.7253e-04 - rho: 0.0979
    Epoch 15/60


    2026-02-24 18:47:55.257099: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:47:55.423926: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 156.9833 - loss: 156.9833 - val_ll_loss: 155.7401 - val_loss: 155.7401 - learning_rate: 2.4660e-04 - rho: 0.0939
    Epoch 16/60


    2026-02-24 18:47:57.575381: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:47:57.705260: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 154.4713 - loss: 154.4713 - val_ll_loss: 155.0132 - val_loss: 155.0133 - learning_rate: 2.2313e-04 - rho: 0.0904
    Epoch 17/60


    2026-02-24 18:47:59.832558: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:48:00.004602: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 11ms/step - ll_loss: 153.2042 - loss: 153.2042

    2026-02-24 18:48:02.159669: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 153.2840 - loss: 153.2841 - val_ll_loss: 154.4135 - val_loss: 154.4135 - learning_rate: 2.0190e-04 - rho: 0.0871
    Epoch 18/60


    2026-02-24 18:48:02.360870: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 153.9235 - loss: 153.9235 - val_ll_loss: 153.9403 - val_loss: 153.9403 - learning_rate: 1.8268e-04 - rho: 0.0841
    Epoch 19/60


    2026-02-24 18:48:04.494630: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:48:04.673254: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 9ms/step - ll_loss: 150.5993 - loss: 150.5993 - val_ll_loss: 153.4462 - val_loss: 153.4463 - learning_rate: 1.6530e-04 - rho: 0.0814
    Epoch 20/60


    2026-02-24 18:48:06.648895: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:48:06.780463: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 151.1943 - loss: 151.1943 - val_ll_loss: 153.0848 - val_loss: 153.0848 - learning_rate: 1.4957e-04 - rho: 0.0789
    Epoch 21/60


    2026-02-24 18:48:08.763939: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:48:08.893616: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 153.9324 - loss: 153.9325 - val_ll_loss: 152.6767 - val_loss: 152.6768 - learning_rate: 1.3534e-04 - rho: 0.0765
    Epoch 22/60


    2026-02-24 18:48:10.843406: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:48:11.007390: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 152.8314 - loss: 152.8315 - val_ll_loss: 152.3687 - val_loss: 152.3687 - learning_rate: 1.2246e-04 - rho: 0.0743
    Epoch 23/60


    2026-02-24 18:48:13.128649: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:48:13.305499: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 150.9219 - loss: 150.9219 - val_ll_loss: 152.0794 - val_loss: 152.0795 - learning_rate: 1.1080e-04 - rho: 0.0723
    Epoch 24/60


    2026-02-24 18:48:15.373552: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:48:15.560634: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 152.2812 - loss: 152.2812 - val_ll_loss: 151.8089 - val_loss: 151.8089 - learning_rate: 1.0026e-04 - rho: 0.0704
    Epoch 25/60


    2026-02-24 18:48:17.714815: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:48:17.872951: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 9ms/step - ll_loss: 152.0118 - loss: 152.0118 - val_ll_loss: 151.5419 - val_loss: 151.5419 - learning_rate: 9.0718e-05 - rho: 0.0686
    Epoch 26/60


    2026-02-24 18:48:19.765634: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:48:19.898937: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 149.9962 - loss: 149.9962 - val_ll_loss: 151.3292 - val_loss: 151.3292 - learning_rate: 8.2085e-05 - rho: 0.0669
    Epoch 27/60


    2026-02-24 18:48:22.101295: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:48:22.254887: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 148.3699 - loss: 148.3700 - val_ll_loss: 151.0976 - val_loss: 151.0976 - learning_rate: 7.4274e-05 - rho: 0.0653


    2026-02-24 18:48:24.585372: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:48:24.778511: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    Epoch 28/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 150.3449 - loss: 150.3449 - val_ll_loss: 150.9546 - val_loss: 150.9545 - learning_rate: 6.7206e-05 - rho: 0.0638
    Epoch 29/60


    2026-02-24 18:48:27.044192: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:48:27.200007: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 148.6749 - loss: 148.6748 - val_ll_loss: 150.7993 - val_loss: 150.7993 - learning_rate: 6.0810e-05 - rho: 0.0624
    Epoch 30/60


    2026-02-24 18:48:29.523119: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:48:29.709285: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 150.8914 - loss: 150.8914 - val_ll_loss: 150.6405 - val_loss: 150.6405 - learning_rate: 5.5023e-05 - rho: 0.0610
    Epoch 31/60


    2026-02-24 18:48:32.081407: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:48:32.267339: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 149.1630 - loss: 149.1631 - val_ll_loss: 150.5106 - val_loss: 150.5106 - learning_rate: 4.9787e-05 - rho: 0.0597
    Epoch 32/60


    2026-02-24 18:48:34.763046: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:48:34.934923: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m137/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 11ms/step - ll_loss: 148.2931 - loss: 148.2931

    2026-02-24 18:48:37.226468: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:48:37.418987: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 148.3319 - loss: 148.3319 - val_ll_loss: 150.3838 - val_loss: 150.3838 - learning_rate: 4.5049e-05 - rho: 0.0585
    Epoch 33/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 149.1935 - loss: 149.1935 - val_ll_loss: 150.2752 - val_loss: 150.2751 - learning_rate: 4.0762e-05 - rho: 0.0574
    Epoch 34/60


    2026-02-24 18:48:39.727710: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:48:39.904204: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 148.5485 - loss: 148.5484 - val_ll_loss: 150.1767 - val_loss: 150.1768 - learning_rate: 3.6883e-05 - rho: 0.0563
    Epoch 35/60


    2026-02-24 18:48:42.204033: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:48:42.383052: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 148.7632 - loss: 148.7632 - val_ll_loss: 150.0669 - val_loss: 150.0669 - learning_rate: 3.3373e-05 - rho: 0.0552
    Epoch 36/60


    2026-02-24 18:48:44.670112: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:48:44.843325: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 11ms/step - ll_loss: 150.9921 - loss: 150.9920 - val_ll_loss: 150.0011 - val_loss: 150.0011 - learning_rate: 3.0197e-05 - rho: 0.0542
    Epoch 37/60


    2026-02-24 18:48:47.338016: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:48:47.489039: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m137/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 12ms/step - ll_loss: 146.7060 - loss: 146.7060

    2026-02-24 18:48:49.897958: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 146.8746 - loss: 146.8746 - val_ll_loss: 149.9164 - val_loss: 149.9164 - learning_rate: 2.7324e-05 - rho: 0.0532
    Epoch 38/60


    2026-02-24 18:48:50.158544: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 13ms/step - ll_loss: 146.5106 - loss: 146.5106

    2026-02-24 18:48:52.595710: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 146.6851 - loss: 146.6851 - val_ll_loss: 149.8623 - val_loss: 149.8623 - learning_rate: 2.4724e-05 - rho: 0.0523
    Epoch 39/60


    2026-02-24 18:48:52.799376: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 148.2677 - loss: 148.2677 - val_ll_loss: 149.7983 - val_loss: 149.7983 - learning_rate: 2.2371e-05 - rho: 0.0514
    Epoch 40/60


    2026-02-24 18:48:55.097086: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:48:55.278001: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 146.1279 - loss: 146.1277 - val_ll_loss: 149.7495 - val_loss: 149.7495 - learning_rate: 2.0242e-05 - rho: 0.0506
    Epoch 41/60


    2026-02-24 18:48:57.829463: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:48:57.975970: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 147.6028 - loss: 147.6028 - val_ll_loss: 149.6870 - val_loss: 149.6871 - learning_rate: 1.8316e-05 - rho: 0.0498
    Epoch 42/60


    2026-02-24 18:49:00.599004: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:49:00.772371: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 13ms/step - ll_loss: 147.4594 - loss: 147.4594

    2026-02-24 18:49:03.150844: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 147.4839 - loss: 147.4840 - val_ll_loss: 149.6452 - val_loss: 149.6452 - learning_rate: 1.6573e-05 - rho: 0.0490
    Epoch 43/60


    2026-02-24 18:49:03.362144: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 147.1207 - loss: 147.1207 - val_ll_loss: 149.6103 - val_loss: 149.6103 - learning_rate: 1.4996e-05 - rho: 0.0482
    Epoch 44/60


    2026-02-24 18:49:05.830346: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:49:06.016321: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 145.8464 - loss: 145.8464 - val_ll_loss: 149.5912 - val_loss: 149.5912 - learning_rate: 1.3569e-05 - rho: 0.0475
    Epoch 45/60


    2026-02-24 18:49:08.604537: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:49:08.771535: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 13ms/step - ll_loss: 146.7806 - loss: 146.7806

    2026-02-24 18:49:11.259471: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:49:11.456676: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 146.8738 - loss: 146.8739 - val_ll_loss: 149.5339 - val_loss: 149.5339 - learning_rate: 1.2277e-05 - rho: 0.0468
    Epoch 46/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 148.9275 - loss: 148.9274 - val_ll_loss: 149.5077 - val_loss: 149.5077 - learning_rate: 1.1109e-05 - rho: 0.0461
    Epoch 47/60


    2026-02-24 18:49:14.010769: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:49:14.187948: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 12ms/step - ll_loss: 149.5009 - loss: 149.5009

    2026-02-24 18:49:16.519963: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 149.2799 - loss: 149.2799 - val_ll_loss: 149.4916 - val_loss: 149.4917 - learning_rate: 1.0052e-05 - rho: 0.0455
    Epoch 48/60


    2026-02-24 18:49:16.742882: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 14ms/step - ll_loss: 149.7815 - loss: 149.7815 - val_ll_loss: 149.4551 - val_loss: 149.4550 - learning_rate: 9.0953e-06 - rho: 0.0449
    Epoch 49/60


    2026-02-24 18:49:19.351108: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:49:19.504452: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 14ms/step - ll_loss: 144.7706 - loss: 144.7706 - val_ll_loss: 149.4418 - val_loss: 149.4418 - learning_rate: 8.2297e-06 - rho: 0.0442
    Epoch 50/60


    2026-02-24 18:49:22.108177: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:49:22.275523: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 150.6254 - loss: 150.6254 - val_ll_loss: 149.4160 - val_loss: 149.4160 - learning_rate: 7.4466e-06 - rho: 0.0437
    Epoch 51/60


    2026-02-24 18:49:24.737600: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:49:24.923460: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 145.4855 - loss: 145.4855 - val_ll_loss: 149.3862 - val_loss: 149.3862 - learning_rate: 6.7379e-06 - rho: 0.0431
    Epoch 52/60


    2026-02-24 18:49:27.310081: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:49:27.474829: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 12ms/step - ll_loss: 146.5013 - loss: 146.5013

    2026-02-24 18:49:29.740537: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:49:29.939250: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 146.5905 - loss: 146.5905 - val_ll_loss: 149.3708 - val_loss: 149.3708 - learning_rate: 6.0967e-06 - rho: 0.0425
    Epoch 53/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 146.8026 - loss: 146.8026 - val_ll_loss: 149.3695 - val_loss: 149.3696 - learning_rate: 5.5166e-06 - rho: 0.0420
    Epoch 54/60


    2026-02-24 18:49:32.216679: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:49:32.392455: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 148.7704 - loss: 148.7704 - val_ll_loss: 149.3432 - val_loss: 149.3432 - learning_rate: 4.9916e-06 - rho: 0.0415
    Epoch 55/60


    2026-02-24 18:49:34.927406: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:49:35.087034: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 146.2366 - loss: 146.2365 - val_ll_loss: 149.3431 - val_loss: 149.3430 - learning_rate: 4.5166e-06 - rho: 0.0410
    Epoch 56/60


    2026-02-24 18:49:37.456741: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:49:37.621526: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 147.4250 - loss: 147.4250 - val_ll_loss: 149.3244 - val_loss: 149.3244 - learning_rate: 4.0868e-06 - rho: 0.0405
    Epoch 57/60


    2026-02-24 18:49:39.854006: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:49:40.015464: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m136/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 11ms/step - ll_loss: 147.9140 - loss: 147.9141

    2026-02-24 18:49:42.245765: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 147.8273 - loss: 147.8273 - val_ll_loss: 149.3301 - val_loss: 149.3301 - learning_rate: 3.6979e-06 - rho: 0.0400
    Epoch 58/60


    2026-02-24 18:49:42.453198: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 12ms/step - ll_loss: 145.0668 - loss: 145.0668

    2026-02-24 18:49:44.678826: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:49:44.880786: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 145.3301 - loss: 145.3301 - val_ll_loss: 149.3262 - val_loss: 149.3261 - learning_rate: 3.3460e-06 - rho: 0.0395
    Epoch 59/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 146.9966 - loss: 146.9966 - val_ll_loss: 149.3058 - val_loss: 149.3058 - learning_rate: 3.0276e-06 - rho: 0.0391
    Epoch 60/60


    2026-02-24 18:49:47.166203: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:49:47.313874: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 144.5900 - loss: 144.5899 - val_ll_loss: 149.2937 - val_loss: 149.2937 - learning_rate: 2.7394e-06 - rho: 0.0386


    2026-02-24 18:49:49.554555: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:49:49.729589: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624



    Getting free energy: 0it [00:00, ?it/s]



    Getting alpha:   0%|          | 0/10 [00:00<?, ?it/s]


    FE_val=150.013 | collapsed=False
        seed=37 … 

    2026-02-24 18:50:10 INFO osl-dynamics [inf_mod_base.py:1321:random_subset_initialization]: Random subset initialization
    2026-02-24 18:50:10 INFO osl-dynamics [inf_mod_base.py:1332:random_subset_initialization]: Using 4 out of 18 batches
    2026-02-24 18:50:10 INFO osl-dynamics [inf_mod_base.py:1337:random_subset_initialization]: Initialization 0


    Epoch 1/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m10s[0m 50ms/step - ll_loss: 216.8127 - loss: 216.8127 - learning_rate: 0.0010 - rho: 0.2853
    Epoch 2/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 38ms/step - ll_loss: 227.1134 - loss: 227.1134 - learning_rate: 9.0484e-04 - rho: 0.2403
    Epoch 3/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 27ms/step - ll_loss: 231.5391 - loss: 231.5391 - learning_rate: 8.1873e-04 - rho: 0.2094
    Epoch 4/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 23ms/step - ll_loss: 227.1160 - loss: 227.1160 - learning_rate: 7.4082e-04 - rho: 0.1866
    Epoch 5/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 24ms/step - ll_loss: 206.6024 - loss: 206.6024 - learning_rate: 6.7032e-04 - rho: 0.1691


    2026-02-24 18:50:20 INFO osl-dynamics [inf_mod_base.py:1365:random_subset_initialization]: Using initialization 0


    Epoch 1/60
    [1m137/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 12ms/step - ll_loss: 212.1178 - loss: 212.1178

    2026-02-24 18:50:32.101530: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m15s[0m 33ms/step - ll_loss: 211.7412 - loss: 211.7412 - val_ll_loss: 195.9160 - val_loss: 195.9160 - learning_rate: 0.0010 - rho: 0.2853
    Epoch 2/60


    2026-02-24 18:50:35.590388: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 194.7680 - loss: 194.7681 - val_ll_loss: 186.2275 - val_loss: 186.2274 - learning_rate: 9.0484e-04 - rho: 0.2403
    Epoch 3/60


    2026-02-24 18:50:37.957043: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:50:38.117608: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 187.7913 - loss: 187.7913 - val_ll_loss: 178.8980 - val_loss: 178.8979 - learning_rate: 8.1873e-04 - rho: 0.2094
    Epoch 4/60


    2026-02-24 18:50:40.358372: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:50:40.516616: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 181.3589 - loss: 181.3589 - val_ll_loss: 173.8851 - val_loss: 173.8851 - learning_rate: 7.4082e-04 - rho: 0.1866
    Epoch 5/60


    2026-02-24 18:50:42.821148: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:50:42.988819: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 175.1201 - loss: 175.1200 - val_ll_loss: 170.0114 - val_loss: 170.0114 - learning_rate: 6.7032e-04 - rho: 0.1691
    Epoch 6/60


    2026-02-24 18:50:45.320947: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:50:45.479386: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 171.2902 - loss: 171.2901 - val_ll_loss: 167.0788 - val_loss: 167.0789 - learning_rate: 6.0653e-04 - rho: 0.1551
    Epoch 7/60


    2026-02-24 18:50:47.609974: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:50:47.759607: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m137/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 12ms/step - ll_loss: 170.3772 - loss: 170.3772

    2026-02-24 18:50:50.089949: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 169.9357 - loss: 169.9357 - val_ll_loss: 164.6632 - val_loss: 164.6631 - learning_rate: 5.4881e-04 - rho: 0.1436
    Epoch 8/60


    2026-02-24 18:50:50.333779: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 163.4477 - loss: 163.4478 - val_ll_loss: 162.6341 - val_loss: 162.6342 - learning_rate: 4.9659e-04 - rho: 0.1340
    Epoch 9/60


    2026-02-24 18:50:52.502999: I tensorflow/core/framework/local_rendezvous.cc:407] Local rendezvous is aborting with status: OUT_OF_RANGE: End of sequence
    	 [[{{node IteratorGetNext}}]]
    	 [[IteratorGetNext/_2]]
    2026-02-24 18:50:52.503105: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:50:52.676679: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 163.2820 - loss: 163.2820 - val_ll_loss: 161.0425 - val_loss: 161.0425 - learning_rate: 4.4933e-04 - rho: 0.1258
    Epoch 10/60


    2026-02-24 18:50:54.875670: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:50:55.058493: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 14ms/step - ll_loss: 159.1905 - loss: 159.1905 - val_ll_loss: 159.6566 - val_loss: 159.6567 - learning_rate: 4.0657e-04 - rho: 0.1187
    Epoch 11/60


    2026-02-24 18:50:57.647900: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:50:57.812316: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 162.5823 - loss: 162.5823 - val_ll_loss: 158.4366 - val_loss: 158.4366 - learning_rate: 3.6788e-04 - rho: 0.1125
    Epoch 12/60


    2026-02-24 18:51:00.170910: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:51:00.339057: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 13ms/step - ll_loss: 151.8109 - loss: 151.8109

    2026-02-24 18:51:02.837265: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m13s[0m 79ms/step - ll_loss: 152.4284 - loss: 152.4284 - val_ll_loss: 157.4233 - val_loss: 157.4234 - learning_rate: 3.3287e-04 - rho: 0.1071
    Epoch 13/60


    2026-02-24 18:51:13.390059: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 15ms/step - ll_loss: 152.8288 - loss: 152.8288 - val_ll_loss: 156.5567 - val_loss: 156.5568 - learning_rate: 3.0119e-04 - rho: 0.1022
    Epoch 14/60


    2026-02-24 18:51:15.996528: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:51:16.177233: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 153.9830 - loss: 153.9830 - val_ll_loss: 155.7971 - val_loss: 155.7971 - learning_rate: 2.7253e-04 - rho: 0.0979
    Epoch 15/60


    2026-02-24 18:51:18.739547: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:51:18.901779: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 155.8707 - loss: 155.8707 - val_ll_loss: 155.1056 - val_loss: 155.1056 - learning_rate: 2.4660e-04 - rho: 0.0939
    Epoch 16/60


    2026-02-24 18:51:21.235365: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:51:21.406375: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 152.4401 - loss: 152.4402 - val_ll_loss: 154.5325 - val_loss: 154.5325 - learning_rate: 2.2313e-04 - rho: 0.0904
    Epoch 17/60


    2026-02-24 18:51:23.660690: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:51:23.804185: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 12ms/step - ll_loss: 153.6025 - loss: 153.6025

    2026-02-24 18:51:26.189488: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 153.4765 - loss: 153.4765 - val_ll_loss: 154.0017 - val_loss: 154.0017 - learning_rate: 2.0190e-04 - rho: 0.0871
    Epoch 18/60


    2026-02-24 18:51:26.401173: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 151.8597 - loss: 151.8596 - val_ll_loss: 153.5443 - val_loss: 153.5443 - learning_rate: 1.8268e-04 - rho: 0.0841
    Epoch 19/60


    2026-02-24 18:51:28.475908: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:51:28.617964: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 148.7012 - loss: 148.7012 - val_ll_loss: 153.1133 - val_loss: 153.1134 - learning_rate: 1.6530e-04 - rho: 0.0814
    Epoch 20/60


    2026-02-24 18:51:30.732039: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:51:30.898429: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 151.3775 - loss: 151.3774 - val_ll_loss: 152.7414 - val_loss: 152.7414 - learning_rate: 1.4957e-04 - rho: 0.0789
    Epoch 21/60


    2026-02-24 18:51:33.181141: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:51:33.330530: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 148.1562 - loss: 148.1561 - val_ll_loss: 152.4192 - val_loss: 152.4193 - learning_rate: 1.3534e-04 - rho: 0.0765


    2026-02-24 18:51:35.728437: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:51:35.918322: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    Epoch 22/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 151.7640 - loss: 151.7639 - val_ll_loss: 152.1362 - val_loss: 152.1362 - learning_rate: 1.2246e-04 - rho: 0.0743
    Epoch 23/60


    2026-02-24 18:51:38.252870: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:51:38.396103: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 149.3795 - loss: 149.3795 - val_ll_loss: 151.8659 - val_loss: 151.8659 - learning_rate: 1.1080e-04 - rho: 0.0723
    Epoch 24/60


    2026-02-24 18:51:40.563914: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:51:40.725815: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 10ms/step - ll_loss: 153.6939 - loss: 153.6940 - val_ll_loss: 151.6267 - val_loss: 151.6267 - learning_rate: 1.0026e-04 - rho: 0.0704
    Epoch 25/60


    2026-02-24 18:51:43.154216: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:51:43.300276: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 149.4165 - loss: 149.4165 - val_ll_loss: 151.4110 - val_loss: 151.4110 - learning_rate: 9.0718e-05 - rho: 0.0686
    Epoch 26/60


    2026-02-24 18:51:45.547240: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:51:45.702565: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 147.6380 - loss: 147.6380 - val_ll_loss: 151.1993 - val_loss: 151.1993 - learning_rate: 8.2085e-05 - rho: 0.0669
    Epoch 27/60


    2026-02-24 18:51:48.000835: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:51:48.138348: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 149.3619 - loss: 149.3619 - val_ll_loss: 151.0485 - val_loss: 151.0484 - learning_rate: 7.4274e-05 - rho: 0.0653


    2026-02-24 18:51:50.278392: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:51:50.470820: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    Epoch 28/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 151.0760 - loss: 151.0760 - val_ll_loss: 150.8758 - val_loss: 150.8758 - learning_rate: 6.7206e-05 - rho: 0.0638
    Epoch 29/60


    2026-02-24 18:51:52.505843: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:51:52.684446: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 150.2258 - loss: 150.2258 - val_ll_loss: 150.7302 - val_loss: 150.7302 - learning_rate: 6.0810e-05 - rho: 0.0624
    Epoch 30/60


    2026-02-24 18:51:54.737888: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:51:54.898708: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 146.6789 - loss: 146.6788 - val_ll_loss: 150.5883 - val_loss: 150.5883 - learning_rate: 5.5023e-05 - rho: 0.0610
    Epoch 31/60


    2026-02-24 18:51:57.027221: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:51:57.166623: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 149.7016 - loss: 149.7016 - val_ll_loss: 150.4763 - val_loss: 150.4763 - learning_rate: 4.9787e-05 - rho: 0.0597
    Epoch 32/60


    2026-02-24 18:51:59.512491: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:51:59.663663: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 147.3080 - loss: 147.3080 - val_ll_loss: 150.3646 - val_loss: 150.3646 - learning_rate: 4.5049e-05 - rho: 0.0585
    Epoch 33/60


    2026-02-24 18:52:01.699204: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:52:01.854713: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 147.8173 - loss: 147.8173 - val_ll_loss: 150.2709 - val_loss: 150.2709 - learning_rate: 4.0762e-05 - rho: 0.0574
    Epoch 34/60


    2026-02-24 18:52:03.968779: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:52:04.124138: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 11ms/step - ll_loss: 147.9216 - loss: 147.9216 - val_ll_loss: 150.1928 - val_loss: 150.1928 - learning_rate: 3.6883e-05 - rho: 0.0563
    Epoch 35/60


    2026-02-24 18:52:06.619073: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:52:06.795646: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 147.5161 - loss: 147.5161 - val_ll_loss: 150.1008 - val_loss: 150.1008 - learning_rate: 3.3373e-05 - rho: 0.0552
    Epoch 36/60


    2026-02-24 18:52:09.347479: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:52:09.516834: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 145.4756 - loss: 145.4757 - val_ll_loss: 150.0384 - val_loss: 150.0384 - learning_rate: 3.0197e-05 - rho: 0.0542
    Epoch 37/60


    2026-02-24 18:52:11.802904: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:52:11.979567: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 11ms/step - ll_loss: 145.1255 - loss: 145.1255

    2026-02-24 18:52:14.186086: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 145.3358 - loss: 145.3358 - val_ll_loss: 149.9723 - val_loss: 149.9723 - learning_rate: 2.7324e-05 - rho: 0.0532
    Epoch 38/60


    2026-02-24 18:52:14.390657: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 148.0283 - loss: 148.0282 - val_ll_loss: 149.9199 - val_loss: 149.9198 - learning_rate: 2.4724e-05 - rho: 0.0523
    Epoch 39/60


    2026-02-24 18:52:16.327718: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:52:16.494061: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 148.3199 - loss: 148.3199 - val_ll_loss: 149.8651 - val_loss: 149.8650 - learning_rate: 2.2371e-05 - rho: 0.0514
    Epoch 40/60


    2026-02-24 18:52:18.993615: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:52:19.180234: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 13ms/step - ll_loss: 148.4047 - loss: 148.4046

    2026-02-24 18:52:21.660529: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:52:21.855238: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 148.2128 - loss: 148.2127 - val_ll_loss: 149.8217 - val_loss: 149.8217 - learning_rate: 2.0242e-05 - rho: 0.0506
    Epoch 41/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 147.3650 - loss: 147.3650 - val_ll_loss: 149.7664 - val_loss: 149.7664 - learning_rate: 1.8316e-05 - rho: 0.0498
    Epoch 42/60


    2026-02-24 18:52:24.297669: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:52:24.467275: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 146.3515 - loss: 146.3515 - val_ll_loss: 149.7298 - val_loss: 149.7298 - learning_rate: 1.6573e-05 - rho: 0.0490
    Epoch 43/60


    2026-02-24 18:52:26.613278: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:52:26.777937: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 146.2292 - loss: 146.2293 - val_ll_loss: 149.7026 - val_loss: 149.7026 - learning_rate: 1.4996e-05 - rho: 0.0482
    Epoch 44/60


    2026-02-24 18:52:28.944285: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:52:29.104571: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 12ms/step - ll_loss: 145.4297 - loss: 145.4297

    2026-02-24 18:52:31.550559: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 145.5689 - loss: 145.5690 - val_ll_loss: 149.6707 - val_loss: 149.6708 - learning_rate: 1.3569e-05 - rho: 0.0475
    Epoch 45/60


    2026-02-24 18:52:31.778239: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 147.3335 - loss: 147.3335 - val_ll_loss: 149.6311 - val_loss: 149.6311 - learning_rate: 1.2277e-05 - rho: 0.0468


    2026-02-24 18:52:34.132085: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:52:34.316786: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    Epoch 46/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 148.2865 - loss: 148.2864 - val_ll_loss: 149.6027 - val_loss: 149.6027 - learning_rate: 1.1109e-05 - rho: 0.0461
    Epoch 47/60


    2026-02-24 18:52:36.427479: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:52:36.591306: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 146.9321 - loss: 146.9321 - val_ll_loss: 149.5876 - val_loss: 149.5876 - learning_rate: 1.0052e-05 - rho: 0.0455
    Epoch 48/60


    2026-02-24 18:52:38.605314: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:52:38.783267: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 148.8602 - loss: 148.8602 - val_ll_loss: 149.5604 - val_loss: 149.5604 - learning_rate: 9.0953e-06 - rho: 0.0449
    Epoch 49/60


    2026-02-24 18:52:40.870462: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:52:41.038605: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 148.4430 - loss: 148.4429 - val_ll_loss: 149.5433 - val_loss: 149.5434 - learning_rate: 8.2297e-06 - rho: 0.0442
    Epoch 50/60


    2026-02-24 18:52:43.232747: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:52:43.400392: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 146.4827 - loss: 146.4828 - val_ll_loss: 149.5234 - val_loss: 149.5234 - learning_rate: 7.4466e-06 - rho: 0.0437
    Epoch 51/60


    2026-02-24 18:52:45.630786: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:52:45.811273: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 145.0281 - loss: 145.0281 - val_ll_loss: 149.5018 - val_loss: 149.5019 - learning_rate: 6.7379e-06 - rho: 0.0431
    Epoch 52/60


    2026-02-24 18:52:47.825819: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:52:47.965601: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m137/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 11ms/step - ll_loss: 146.4451 - loss: 146.4451

    2026-02-24 18:52:50.163253: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:52:50.360325: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 146.4400 - loss: 146.4401 - val_ll_loss: 149.4969 - val_loss: 149.4969 - learning_rate: 6.0967e-06 - rho: 0.0425
    Epoch 53/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 146.9765 - loss: 146.9766 - val_ll_loss: 149.4866 - val_loss: 149.4866 - learning_rate: 5.5166e-06 - rho: 0.0420
    Epoch 54/60


    2026-02-24 18:52:52.638680: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:52:52.809039: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 147.2491 - loss: 147.2490 - val_ll_loss: 149.4695 - val_loss: 149.4694 - learning_rate: 4.9916e-06 - rho: 0.0415
    Epoch 55/60


    2026-02-24 18:52:55.364033: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:52:55.546559: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 14ms/step - ll_loss: 146.5115 - loss: 146.5115 - val_ll_loss: 149.4553 - val_loss: 149.4553 - learning_rate: 4.5166e-06 - rho: 0.0410
    Epoch 56/60


    2026-02-24 18:52:58.259327: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:52:58.443860: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 147.6965 - loss: 147.6964 - val_ll_loss: 149.4583 - val_loss: 149.4583 - learning_rate: 4.0868e-06 - rho: 0.0405


    2026-02-24 18:53:00.822155: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:53:01.008250: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    Epoch 57/60
    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 11ms/step - ll_loss: 149.4162 - loss: 149.4162

    2026-02-24 18:53:03.259947: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 149.0827 - loss: 149.0827 - val_ll_loss: 149.4392 - val_loss: 149.4391 - learning_rate: 3.6979e-06 - rho: 0.0400
    Epoch 58/60


    2026-02-24 18:53:03.464853: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 148.5786 - loss: 148.5786 - val_ll_loss: 149.4321 - val_loss: 149.4321 - learning_rate: 3.3460e-06 - rho: 0.0395
    Epoch 59/60


    2026-02-24 18:53:05.785205: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:53:05.928608: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 146.0850 - loss: 146.0851 - val_ll_loss: 149.4310 - val_loss: 149.4310 - learning_rate: 3.0276e-06 - rho: 0.0391
    Epoch 60/60


    2026-02-24 18:53:08.432877: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:53:08.614390: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 146.9400 - loss: 146.9400 - val_ll_loss: 149.4238 - val_loss: 149.4238 - learning_rate: 2.7394e-06 - rho: 0.0386


    2026-02-24 18:53:10.819463: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:53:10.971148: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624



    Getting free energy: 0it [00:00, ?it/s]



    Getting alpha:   0%|          | 0/10 [00:00<?, ?it/s]


    FE_val=150.073 | collapsed=False
        seed=53 … 

    2026-02-24 18:53:31 INFO osl-dynamics [inf_mod_base.py:1321:random_subset_initialization]: Random subset initialization
    2026-02-24 18:53:31 INFO osl-dynamics [inf_mod_base.py:1332:random_subset_initialization]: Using 4 out of 18 batches
    2026-02-24 18:53:31 INFO osl-dynamics [inf_mod_base.py:1337:random_subset_initialization]: Initialization 0


    Epoch 1/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m10s[0m 49ms/step - ll_loss: 223.3100 - loss: 223.3100 - learning_rate: 0.0010 - rho: 0.2853
    Epoch 2/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 35ms/step - ll_loss: 218.4425 - loss: 218.4425 - learning_rate: 9.0484e-04 - rho: 0.2403
    Epoch 3/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 29ms/step - ll_loss: 215.7031 - loss: 215.7031 - learning_rate: 8.1873e-04 - rho: 0.2094
    Epoch 4/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m5s[0m 2s/step - ll_loss: 222.1466 - loss: 222.6437 - learning_rate: 7.4082e-04 - rho: 0.1866
    Epoch 5/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 40ms/step - ll_loss: 216.0312 - loss: 216.0312 - learning_rate: 6.7032e-04 - rho: 0.1691


    2026-02-24 18:53:47 INFO osl-dynamics [inf_mod_base.py:1365:random_subset_initialization]: Using initialization 0


    Epoch 1/60
    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 11ms/step - ll_loss: 213.8240 - loss: 213.8241

    2026-02-24 18:53:58.062637: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m14s[0m 30ms/step - ll_loss: 213.2376 - loss: 213.2376 - val_ll_loss: 195.3943 - val_loss: 195.3943 - learning_rate: 0.0010 - rho: 0.2853
    Epoch 2/60


    2026-02-24 18:54:01.229680: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 199.4971 - loss: 199.4971 - val_ll_loss: 186.5929 - val_loss: 186.5929 - learning_rate: 9.0484e-04 - rho: 0.2403
    Epoch 3/60


    2026-02-24 18:54:03.756706: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:54:03.921741: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 191.3982 - loss: 191.3983 - val_ll_loss: 179.9109 - val_loss: 179.9109 - learning_rate: 8.1873e-04 - rho: 0.2094
    Epoch 4/60


    2026-02-24 18:54:06.213392: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:54:06.368385: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 178.9284 - loss: 178.9285 - val_ll_loss: 175.0467 - val_loss: 175.0468 - learning_rate: 7.4082e-04 - rho: 0.1866
    Epoch 5/60


    2026-02-24 18:54:08.452188: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:54:08.592638: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 178.5183 - loss: 178.5184 - val_ll_loss: 171.2380 - val_loss: 171.2380 - learning_rate: 6.7032e-04 - rho: 0.1691
    Epoch 6/60


    2026-02-24 18:54:10.955399: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:54:11.136907: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 14ms/step - ll_loss: 169.4233 - loss: 169.4233

    2026-02-24 18:54:13.703985: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:54:13.901362: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 14ms/step - ll_loss: 169.5018 - loss: 169.5018 - val_ll_loss: 168.0557 - val_loss: 168.0557 - learning_rate: 6.0653e-04 - rho: 0.1551
    Epoch 7/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 172.2957 - loss: 172.2957 - val_ll_loss: 165.5015 - val_loss: 165.5016 - learning_rate: 5.4881e-04 - rho: 0.1436
    Epoch 8/60


    2026-02-24 18:54:16.076301: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:54:16.234846: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 164.4564 - loss: 164.4563 - val_ll_loss: 163.4151 - val_loss: 163.4150 - learning_rate: 4.9659e-04 - rho: 0.1340
    Epoch 9/60


    2026-02-24 18:54:18.526069: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:54:18.664659: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 9ms/step - ll_loss: 161.5909 - loss: 161.5909 - val_ll_loss: 161.6936 - val_loss: 161.6935 - learning_rate: 4.4933e-04 - rho: 0.1258
    Epoch 10/60


    2026-02-24 18:54:20.521138: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:54:20.665647: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 159.7262 - loss: 159.7262 - val_ll_loss: 160.1591 - val_loss: 160.1591 - learning_rate: 4.0657e-04 - rho: 0.1187
    Epoch 11/60


    2026-02-24 18:54:22.717470: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:54:22.895436: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 167.1782 - loss: 167.1783 - val_ll_loss: 158.8702 - val_loss: 158.8701 - learning_rate: 3.6788e-04 - rho: 0.1125
    Epoch 12/60


    2026-02-24 18:54:25.330361: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:54:25.501065: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m137/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 14ms/step - ll_loss: 156.1702 - loss: 156.1702

    2026-02-24 18:54:28.154111: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 14ms/step - ll_loss: 156.2569 - loss: 156.2570 - val_ll_loss: 157.8044 - val_loss: 157.8044 - learning_rate: 3.3287e-04 - rho: 0.1071
    Epoch 13/60


    2026-02-24 18:54:28.367239: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 152.7054 - loss: 152.7053 - val_ll_loss: 156.9148 - val_loss: 156.9148 - learning_rate: 3.0119e-04 - rho: 0.1022
    Epoch 14/60


    2026-02-24 18:54:30.676826: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:54:30.840948: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 154.4054 - loss: 154.4054 - val_ll_loss: 156.1150 - val_loss: 156.1150 - learning_rate: 2.7253e-04 - rho: 0.0979
    Epoch 15/60


    2026-02-24 18:54:33.134249: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:54:33.297577: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 151.1788 - loss: 151.1787 - val_ll_loss: 155.3911 - val_loss: 155.3910 - learning_rate: 2.4660e-04 - rho: 0.0939
    Epoch 16/60


    2026-02-24 18:54:35.272270: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:54:35.396638: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 152.9483 - loss: 152.9484 - val_ll_loss: 154.8089 - val_loss: 154.8090 - learning_rate: 2.2313e-04 - rho: 0.0904
    Epoch 17/60


    2026-02-24 18:54:37.325432: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:54:37.459819: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 151.8439 - loss: 151.8438 - val_ll_loss: 154.2549 - val_loss: 154.2549 - learning_rate: 2.0190e-04 - rho: 0.0871
    Epoch 18/60


    2026-02-24 18:54:39.421454: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:54:39.605495: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 9ms/step - ll_loss: 149.9690 - loss: 149.9691 - val_ll_loss: 153.8025 - val_loss: 153.8025 - learning_rate: 1.8268e-04 - rho: 0.0841
    Epoch 19/60


    2026-02-24 18:54:41.418297: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:54:41.569637: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 153.1329 - loss: 153.1329 - val_ll_loss: 153.3724 - val_loss: 153.3723 - learning_rate: 1.6530e-04 - rho: 0.0814
    Epoch 20/60


    2026-02-24 18:54:43.428199: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:54:43.596439: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 150.6190 - loss: 150.6191 - val_ll_loss: 153.0042 - val_loss: 153.0041 - learning_rate: 1.4957e-04 - rho: 0.0789
    Epoch 21/60


    2026-02-24 18:54:45.582695: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:54:45.734065: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 150.1912 - loss: 150.1912 - val_ll_loss: 152.6729 - val_loss: 152.6729 - learning_rate: 1.3534e-04 - rho: 0.0765
    Epoch 22/60


    2026-02-24 18:54:47.554779: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:54:47.707155: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m135/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 10ms/step - ll_loss: 148.8064 - loss: 148.8063

    2026-02-24 18:54:49.670386: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:54:49.861645: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 148.9212 - loss: 148.9211 - val_ll_loss: 152.3827 - val_loss: 152.3828 - learning_rate: 1.2246e-04 - rho: 0.0743
    Epoch 23/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 147.0225 - loss: 147.0225 - val_ll_loss: 152.1050 - val_loss: 152.1050 - learning_rate: 1.1080e-04 - rho: 0.0723
    Epoch 24/60


    2026-02-24 18:54:51.857218: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:54:52.027432: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 13ms/step - ll_loss: 150.4934 - loss: 150.4933

    2026-02-24 18:54:54.497117: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 150.3169 - loss: 150.3168 - val_ll_loss: 151.8605 - val_loss: 151.8604 - learning_rate: 1.0026e-04 - rho: 0.0704
    Epoch 25/60


    2026-02-24 18:54:54.701548: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 147.5696 - loss: 147.5696 - val_ll_loss: 151.6279 - val_loss: 151.6279 - learning_rate: 9.0718e-05 - rho: 0.0686
    Epoch 26/60


    2026-02-24 18:54:56.855264: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:54:57.038003: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 147.5246 - loss: 147.5247 - val_ll_loss: 151.4215 - val_loss: 151.4215 - learning_rate: 8.2085e-05 - rho: 0.0669
    Epoch 27/60


    2026-02-24 18:54:59.257116: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:54:59.415828: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 11ms/step - ll_loss: 146.0701 - loss: 146.0701

    2026-02-24 18:55:01.570895: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:55:01.768372: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 146.3114 - loss: 146.3114 - val_ll_loss: 151.2471 - val_loss: 151.2470 - learning_rate: 7.4274e-05 - rho: 0.0653
    Epoch 28/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 148.9302 - loss: 148.9301 - val_ll_loss: 151.0878 - val_loss: 151.0879 - learning_rate: 6.7206e-05 - rho: 0.0638
    Epoch 29/60


    2026-02-24 18:55:04.005484: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:55:04.158033: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 150.1088 - loss: 150.1088 - val_ll_loss: 150.9359 - val_loss: 150.9360 - learning_rate: 6.0810e-05 - rho: 0.0624
    Epoch 30/60


    2026-02-24 18:55:06.392132: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:55:06.562471: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m136/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 12ms/step - ll_loss: 145.3844 - loss: 145.3844

    2026-02-24 18:55:08.795407: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 145.6772 - loss: 145.6772 - val_ll_loss: 150.8030 - val_loss: 150.8029 - learning_rate: 5.5023e-05 - rho: 0.0610
    Epoch 31/60


    2026-02-24 18:55:09.017322: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 145.2267 - loss: 145.2267 - val_ll_loss: 150.6771 - val_loss: 150.6771 - learning_rate: 4.9787e-05 - rho: 0.0597
    Epoch 32/60


    2026-02-24 18:55:11.256408: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:55:11.418037: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 13ms/step - ll_loss: 146.7279 - loss: 146.7279

    2026-02-24 18:55:13.681109: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 13ms/step - ll_loss: 146.7935 - loss: 146.7935 - val_ll_loss: 150.5628 - val_loss: 150.5628 - learning_rate: 4.5049e-05 - rho: 0.0585
    Epoch 33/60


    2026-02-24 18:55:13.908647: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 12ms/step - ll_loss: 146.2115 - loss: 146.2114

    2026-02-24 18:55:16.171435: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:55:16.365856: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 146.3155 - loss: 146.3155 - val_ll_loss: 150.4661 - val_loss: 150.4661 - learning_rate: 4.0762e-05 - rho: 0.0574
    Epoch 34/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 147.7545 - loss: 147.7545 - val_ll_loss: 150.3859 - val_loss: 150.3859 - learning_rate: 3.6883e-05 - rho: 0.0563
    Epoch 35/60


    2026-02-24 18:55:18.512287: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:55:18.642656: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 147.4876 - loss: 147.4877 - val_ll_loss: 150.2986 - val_loss: 150.2986 - learning_rate: 3.3373e-05 - rho: 0.0552
    Epoch 36/60


    2026-02-24 18:55:20.905820: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:55:21.083678: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 14ms/step - ll_loss: 144.3376 - loss: 144.3376 - val_ll_loss: 150.2219 - val_loss: 150.2220 - learning_rate: 3.0197e-05 - rho: 0.0542


    2026-02-24 18:55:23.681758: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:55:23.875293: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    Epoch 37/60
    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 13ms/step - ll_loss: 148.6271 - loss: 148.6272

    2026-02-24 18:55:26.316762: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 148.4261 - loss: 148.4261 - val_ll_loss: 150.1517 - val_loss: 150.1517 - learning_rate: 2.7324e-05 - rho: 0.0532
    Epoch 38/60


    2026-02-24 18:55:26.534168: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 13ms/step - ll_loss: 147.5739 - loss: 147.5739

    2026-02-24 18:55:29.007130: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:55:29.206568: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 147.4727 - loss: 147.4727 - val_ll_loss: 150.1076 - val_loss: 150.1075 - learning_rate: 2.4724e-05 - rho: 0.0523
    Epoch 39/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 147.0730 - loss: 147.0730 - val_ll_loss: 150.0403 - val_loss: 150.0403 - learning_rate: 2.2371e-05 - rho: 0.0514
    Epoch 40/60


    2026-02-24 18:55:31.632322: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:55:31.799171: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 147.6066 - loss: 147.6066 - val_ll_loss: 149.9814 - val_loss: 149.9814 - learning_rate: 2.0242e-05 - rho: 0.0506
    Epoch 41/60


    2026-02-24 18:55:33.949316: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:55:34.115208: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 149.3856 - loss: 149.3856 - val_ll_loss: 149.9452 - val_loss: 149.9452 - learning_rate: 1.8316e-05 - rho: 0.0498
    Epoch 42/60


    2026-02-24 18:55:36.420623: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:55:36.582554: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 147.8034 - loss: 147.8034 - val_ll_loss: 149.9071 - val_loss: 149.9071 - learning_rate: 1.6573e-05 - rho: 0.0490
    Epoch 43/60


    2026-02-24 18:55:39.023392: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:55:39.187723: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 147.6057 - loss: 147.6056 - val_ll_loss: 149.8628 - val_loss: 149.8628 - learning_rate: 1.4996e-05 - rho: 0.0482
    Epoch 44/60


    2026-02-24 18:55:41.326746: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:55:41.490684: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 148.2663 - loss: 148.2663 - val_ll_loss: 149.8372 - val_loss: 149.8372 - learning_rate: 1.3569e-05 - rho: 0.0475
    Epoch 45/60


    2026-02-24 18:55:43.704016: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:55:43.855575: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 146.2087 - loss: 146.2087 - val_ll_loss: 149.7977 - val_loss: 149.7977 - learning_rate: 1.2277e-05 - rho: 0.0468
    Epoch 46/60


    2026-02-24 18:55:45.802869: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:55:45.954201: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 148.0991 - loss: 148.0990 - val_ll_loss: 149.7641 - val_loss: 149.7641 - learning_rate: 1.1109e-05 - rho: 0.0461
    Epoch 47/60


    2026-02-24 18:55:48.019908: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:55:48.162858: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 147.1207 - loss: 147.1207 - val_ll_loss: 149.7521 - val_loss: 149.7521 - learning_rate: 1.0052e-05 - rho: 0.0455
    Epoch 48/60


    2026-02-24 18:55:50.232656: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:55:50.414377: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 144.9434 - loss: 144.9434 - val_ll_loss: 149.7284 - val_loss: 149.7285 - learning_rate: 9.0953e-06 - rho: 0.0449
    Epoch 49/60


    2026-02-24 18:55:52.447792: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:55:52.584180: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 145.7084 - loss: 145.7083 - val_ll_loss: 149.7023 - val_loss: 149.7023 - learning_rate: 8.2297e-06 - rho: 0.0442
    Epoch 50/60


    2026-02-24 18:55:54.679422: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:55:54.840553: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 142.7256 - loss: 142.7256 - val_ll_loss: 149.6837 - val_loss: 149.6837 - learning_rate: 7.4466e-06 - rho: 0.0437
    Epoch 51/60


    2026-02-24 18:55:56.734816: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:55:56.890089: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 145.3194 - loss: 145.3194 - val_ll_loss: 149.6766 - val_loss: 149.6766 - learning_rate: 6.7379e-06 - rho: 0.0431
    Epoch 52/60


    2026-02-24 18:55:59.152495: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:55:59.305999: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 146.5404 - loss: 146.5404 - val_ll_loss: 149.6564 - val_loss: 149.6564 - learning_rate: 6.0967e-06 - rho: 0.0425
    Epoch 53/60


    2026-02-24 18:56:01.554303: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:56:01.695179: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 144.6037 - loss: 144.6037 - val_ll_loss: 149.6362 - val_loss: 149.6362 - learning_rate: 5.5166e-06 - rho: 0.0420
    Epoch 54/60


    2026-02-24 18:56:03.780122: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:56:03.922879: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 144.3406 - loss: 144.3405 - val_ll_loss: 149.6169 - val_loss: 149.6169 - learning_rate: 4.9916e-06 - rho: 0.0415
    Epoch 55/60


    2026-02-24 18:56:05.961214: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:56:06.085663: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 147.3289 - loss: 147.3289 - val_ll_loss: 149.6176 - val_loss: 149.6176 - learning_rate: 4.5166e-06 - rho: 0.0410
    Epoch 56/60


    2026-02-24 18:56:08.318038: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:56:08.480690: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 145.9244 - loss: 145.9243 - val_ll_loss: 149.5982 - val_loss: 149.5982 - learning_rate: 4.0868e-06 - rho: 0.0405
    Epoch 57/60


    2026-02-24 18:56:10.553879: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:56:10.714342: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 147.2149 - loss: 147.2149 - val_ll_loss: 149.5913 - val_loss: 149.5913 - learning_rate: 3.6979e-06 - rho: 0.0400
    Epoch 58/60


    2026-02-24 18:56:12.838135: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:56:12.994318: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 143.8447 - loss: 143.8447 - val_ll_loss: 149.5883 - val_loss: 149.5883 - learning_rate: 3.3460e-06 - rho: 0.0395
    Epoch 59/60


    2026-02-24 18:56:14.943019: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:56:15.088622: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 145.4135 - loss: 145.4135 - val_ll_loss: 149.5824 - val_loss: 149.5824 - learning_rate: 3.0276e-06 - rho: 0.0391
    Epoch 60/60


    2026-02-24 18:56:17.022854: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:56:17.176244: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 147.0473 - loss: 147.0473 - val_ll_loss: 149.5773 - val_loss: 149.5774 - learning_rate: 2.7394e-06 - rho: 0.0386


    2026-02-24 18:56:19.171131: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:56:19.337449: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624



    Getting free energy: 0it [00:00, ?it/s]



    Getting alpha:   0%|          | 0/10 [00:00<?, ?it/s]


    FE_val=150.637 | collapsed=False
        seed=71 … 

    2026-02-24 18:56:38 INFO osl-dynamics [inf_mod_base.py:1321:random_subset_initialization]: Random subset initialization
    2026-02-24 18:56:38 INFO osl-dynamics [inf_mod_base.py:1332:random_subset_initialization]: Using 4 out of 18 batches
    2026-02-24 18:56:38 INFO osl-dynamics [inf_mod_base.py:1337:random_subset_initialization]: Initialization 0


    Epoch 1/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m8s[0m 49ms/step - ll_loss: 211.7751 - loss: 211.7751 - learning_rate: 0.0010 - rho: 0.2853
    Epoch 2/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 1s/step - ll_loss: 229.6370 - loss: 236.2085 - learning_rate: 9.0484e-04 - rho: 0.2403
    Epoch 3/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 40ms/step - ll_loss: 224.7290 - loss: 224.7290 - learning_rate: 8.1873e-04 - rho: 0.2094
    Epoch 4/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 31ms/step - ll_loss: 223.1979 - loss: 223.1979 - learning_rate: 7.4082e-04 - rho: 0.1866
    Epoch 5/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 27ms/step - ll_loss: 223.3871 - loss: 227.3663 - learning_rate: 6.7032e-04 - rho: 0.1691


    2026-02-24 18:56:50 INFO osl-dynamics [inf_mod_base.py:1365:random_subset_initialization]: Using initialization 0


    Epoch 1/60
    [1m137/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 12ms/step - ll_loss: 211.6997 - loss: 211.6997

    2026-02-24 18:57:01.203279: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m13s[0m 30ms/step - ll_loss: 211.4602 - loss: 211.4602 - val_ll_loss: 195.1019 - val_loss: 195.1018 - learning_rate: 0.0010 - rho: 0.2853
    Epoch 2/60


    2026-02-24 18:57:04.185477: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 15ms/step - ll_loss: 198.3096 - loss: 198.3096 - val_ll_loss: 185.9827 - val_loss: 185.9828 - learning_rate: 9.0484e-04 - rho: 0.2403
    Epoch 3/60


    2026-02-24 18:57:06.831783: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:57:06.997692: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 185.8729 - loss: 185.8729 - val_ll_loss: 179.0849 - val_loss: 179.0849 - learning_rate: 8.1873e-04 - rho: 0.2094
    Epoch 4/60


    2026-02-24 18:57:09.268345: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:57:09.455044: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 182.7071 - loss: 182.7070 - val_ll_loss: 174.1508 - val_loss: 174.1508 - learning_rate: 7.4082e-04 - rho: 0.1866
    Epoch 5/60


    2026-02-24 18:57:11.737327: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:57:11.891159: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 174.0934 - loss: 174.0933 - val_ll_loss: 170.2497 - val_loss: 170.2497 - learning_rate: 6.7032e-04 - rho: 0.1691
    Epoch 6/60


    2026-02-24 18:57:14.096632: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:57:14.267105: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 171.9970 - loss: 171.9970 - val_ll_loss: 167.2883 - val_loss: 167.2883 - learning_rate: 6.0653e-04 - rho: 0.1551
    Epoch 7/60


    2026-02-24 18:57:16.858980: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:57:17.016668: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 14ms/step - ll_loss: 166.6768 - loss: 166.6768

    2026-02-24 18:57:19.615408: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 14ms/step - ll_loss: 167.0029 - loss: 167.0029 - val_ll_loss: 165.0020 - val_loss: 165.0021 - learning_rate: 5.4881e-04 - rho: 0.1436
    Epoch 8/60


    2026-02-24 18:57:19.839959: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 170.6458 - loss: 170.6459 - val_ll_loss: 163.0053 - val_loss: 163.0054 - learning_rate: 4.9659e-04 - rho: 0.1340
    Epoch 9/60


    2026-02-24 18:57:22.097026: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:57:22.248743: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 164.1693 - loss: 164.1693 - val_ll_loss: 161.3733 - val_loss: 161.3733 - learning_rate: 4.4933e-04 - rho: 0.1258
    Epoch 10/60


    2026-02-24 18:57:24.381469: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:57:24.557645: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 162.7265 - loss: 162.7265 - val_ll_loss: 160.0159 - val_loss: 160.0158 - learning_rate: 4.0657e-04 - rho: 0.1187
    Epoch 11/60


    2026-02-24 18:57:26.801875: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:57:26.953063: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 161.7069 - loss: 161.7068 - val_ll_loss: 158.7840 - val_loss: 158.7839 - learning_rate: 3.6788e-04 - rho: 0.1125
    Epoch 12/60


    2026-02-24 18:57:29.188232: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:57:29.331039: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 161.2902 - loss: 161.2902 - val_ll_loss: 157.7615 - val_loss: 157.7616 - learning_rate: 3.3287e-04 - rho: 0.1071
    Epoch 13/60


    2026-02-24 18:57:31.550336: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:57:31.718832: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 160.6855 - loss: 160.6855 - val_ll_loss: 156.8647 - val_loss: 156.8647 - learning_rate: 3.0119e-04 - rho: 0.1022
    Epoch 14/60


    2026-02-24 18:57:33.864871: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:57:34.050108: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 154.5180 - loss: 154.5180 - val_ll_loss: 156.1022 - val_loss: 156.1022 - learning_rate: 2.7253e-04 - rho: 0.0979
    Epoch 15/60


    2026-02-24 18:57:36.277049: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:57:36.448700: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 156.5677 - loss: 156.5678 - val_ll_loss: 155.3966 - val_loss: 155.3966 - learning_rate: 2.4660e-04 - rho: 0.0939
    Epoch 16/60


    2026-02-24 18:57:38.652222: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:57:38.817842: I tensorflow/core/framework/local_rendezvous.cc:407] Local rendezvous is aborting with status: OUT_OF_RANGE: End of sequence
    	 [[{{node IteratorGetNext}}]]
    	 [[IteratorGetNext/_2]]
    2026-02-24 18:57:38.817922: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 157.9151 - loss: 157.9152 - val_ll_loss: 154.7546 - val_loss: 154.7546 - learning_rate: 2.2313e-04 - rho: 0.0904
    Epoch 17/60


    2026-02-24 18:57:40.805427: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:57:40.940778: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 158.4066 - loss: 158.4066 - val_ll_loss: 154.1985 - val_loss: 154.1985 - learning_rate: 2.0190e-04 - rho: 0.0871
    Epoch 18/60


    2026-02-24 18:57:43.018771: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:57:43.200040: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 158.4308 - loss: 158.4308 - val_ll_loss: 153.7070 - val_loss: 153.7071 - learning_rate: 1.8268e-04 - rho: 0.0841
    Epoch 19/60


    2026-02-24 18:57:45.489835: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:57:45.643871: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 157.2582 - loss: 157.2581 - val_ll_loss: 153.2621 - val_loss: 153.2621 - learning_rate: 1.6530e-04 - rho: 0.0814
    Epoch 20/60


    2026-02-24 18:57:47.840889: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:57:48.002471: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 156.0393 - loss: 156.0393 - val_ll_loss: 152.8543 - val_loss: 152.8543 - learning_rate: 1.4957e-04 - rho: 0.0789
    Epoch 21/60


    2026-02-24 18:57:50.012630: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:57:50.179907: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 153.1949 - loss: 153.1949 - val_ll_loss: 152.5056 - val_loss: 152.5056 - learning_rate: 1.3534e-04 - rho: 0.0765
    Epoch 22/60


    2026-02-24 18:57:52.439443: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:57:52.567948: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 10ms/step - ll_loss: 154.5740 - loss: 154.5740

    2026-02-24 18:57:54.500258: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 154.4192 - loss: 154.4192 - val_ll_loss: 152.1920 - val_loss: 152.1920 - learning_rate: 1.2246e-04 - rho: 0.0743
    Epoch 23/60


    2026-02-24 18:57:54.723945: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 152.5120 - loss: 152.5119 - val_ll_loss: 151.8896 - val_loss: 151.8896 - learning_rate: 1.1080e-04 - rho: 0.0723
    Epoch 24/60


    2026-02-24 18:57:56.902379: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:57:57.039132: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 154.3648 - loss: 154.3648 - val_ll_loss: 151.6490 - val_loss: 151.6490 - learning_rate: 1.0026e-04 - rho: 0.0704


    2026-02-24 18:57:58.983601: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:57:59.170706: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    Epoch 25/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 150.9224 - loss: 150.9224 - val_ll_loss: 151.3990 - val_loss: 151.3991 - learning_rate: 9.0718e-05 - rho: 0.0686
    Epoch 26/60


    2026-02-24 18:58:01.373517: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:01.502727: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 150.0057 - loss: 150.0057 - val_ll_loss: 151.2056 - val_loss: 151.2057 - learning_rate: 8.2085e-05 - rho: 0.0669
    Epoch 27/60


    2026-02-24 18:58:03.647152: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:03.822868: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 151.9608 - loss: 151.9608 - val_ll_loss: 150.9951 - val_loss: 150.9951 - learning_rate: 7.4274e-05 - rho: 0.0653
    Epoch 28/60


    2026-02-24 18:58:05.931129: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:06.090875: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 153.8934 - loss: 153.8934 - val_ll_loss: 150.8357 - val_loss: 150.8358 - learning_rate: 6.7206e-05 - rho: 0.0638
    Epoch 29/60


    2026-02-24 18:58:08.068934: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:08.205006: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 154.2835 - loss: 154.2834 - val_ll_loss: 150.6893 - val_loss: 150.6894 - learning_rate: 6.0810e-05 - rho: 0.0624
    Epoch 30/60


    2026-02-24 18:58:10.276514: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:10.437081: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 150.9996 - loss: 150.9996 - val_ll_loss: 150.5554 - val_loss: 150.5555 - learning_rate: 5.5023e-05 - rho: 0.0610
    Epoch 31/60


    2026-02-24 18:58:12.514726: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:12.673300: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 151.4374 - loss: 151.4374 - val_ll_loss: 150.4193 - val_loss: 150.4193 - learning_rate: 4.9787e-05 - rho: 0.0597
    Epoch 32/60


    2026-02-24 18:58:14.686315: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:14.835977: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 11ms/step - ll_loss: 149.0074 - loss: 149.0074

    2026-02-24 18:58:17.004372: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:17.206648: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 149.2111 - loss: 149.2111 - val_ll_loss: 150.2996 - val_loss: 150.2995 - learning_rate: 4.5049e-05 - rho: 0.0585
    Epoch 33/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 148.7470 - loss: 148.7470 - val_ll_loss: 150.1988 - val_loss: 150.1988 - learning_rate: 4.0762e-05 - rho: 0.0574
    Epoch 34/60


    2026-02-24 18:58:19.319489: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:19.507785: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 149.6917 - loss: 149.6917 - val_ll_loss: 150.1089 - val_loss: 150.1088 - learning_rate: 3.6883e-05 - rho: 0.0563
    Epoch 35/60


    2026-02-24 18:58:21.573023: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:21.742278: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 151.3898 - loss: 151.3898 - val_ll_loss: 150.0229 - val_loss: 150.0229 - learning_rate: 3.3373e-05 - rho: 0.0552
    Epoch 36/60


    2026-02-24 18:58:23.843791: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:23.995187: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 149.4345 - loss: 149.4345 - val_ll_loss: 149.9443 - val_loss: 149.9442 - learning_rate: 3.0197e-05 - rho: 0.0542
    Epoch 37/60


    2026-02-24 18:58:26.129245: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:26.275362: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 150.6658 - loss: 150.6659 - val_ll_loss: 149.8672 - val_loss: 149.8671 - learning_rate: 2.7324e-05 - rho: 0.0532


    2026-02-24 18:58:28.356569: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:28.513151: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    Epoch 38/60
    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 14ms/step - ll_loss: 150.2662 - loss: 150.2662

    2026-02-24 18:58:34.443812: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:34.641423: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 150.2552 - loss: 150.2552 - val_ll_loss: 149.8029 - val_loss: 149.8029 - learning_rate: 2.4724e-05 - rho: 0.0523
    Epoch 39/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 149.2334 - loss: 149.2334 - val_ll_loss: 149.7471 - val_loss: 149.7471 - learning_rate: 2.2371e-05 - rho: 0.0514
    Epoch 40/60


    2026-02-24 18:58:36.698183: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:36.843223: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 150.6277 - loss: 150.6277 - val_ll_loss: 149.6984 - val_loss: 149.6984 - learning_rate: 2.0242e-05 - rho: 0.0506
    Epoch 41/60


    2026-02-24 18:58:38.790928: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:38.925782: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 149.2869 - loss: 149.2869 - val_ll_loss: 149.6549 - val_loss: 149.6549 - learning_rate: 1.8316e-05 - rho: 0.0498
    Epoch 42/60


    2026-02-24 18:58:40.888960: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:41.046147: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 148.9450 - loss: 148.9449 - val_ll_loss: 149.6058 - val_loss: 149.6058 - learning_rate: 1.6573e-05 - rho: 0.0490
    Epoch 43/60


    2026-02-24 18:58:42.972326: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:43.116707: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 147.4781 - loss: 147.4781 - val_ll_loss: 149.5732 - val_loss: 149.5732 - learning_rate: 1.4996e-05 - rho: 0.0482
    Epoch 44/60


    2026-02-24 18:58:45.094865: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:45.245635: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 148.9183 - loss: 148.9184 - val_ll_loss: 149.5361 - val_loss: 149.5361 - learning_rate: 1.3569e-05 - rho: 0.0475
    Epoch 45/60


    2026-02-24 18:58:47.302591: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:47.459468: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 148.2261 - loss: 148.2262 - val_ll_loss: 149.5005 - val_loss: 149.5006 - learning_rate: 1.2277e-05 - rho: 0.0468
    Epoch 46/60


    2026-02-24 18:58:49.466453: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:49.620598: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 147.4888 - loss: 147.4888 - val_ll_loss: 149.4737 - val_loss: 149.4737 - learning_rate: 1.1109e-05 - rho: 0.0461
    Epoch 47/60


    2026-02-24 18:58:51.723845: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:51.899235: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 12ms/step - ll_loss: 151.3649 - loss: 151.3649

    2026-02-24 18:58:54.128006: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:54.314440: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 151.1864 - loss: 151.1864 - val_ll_loss: 149.4624 - val_loss: 149.4623 - learning_rate: 1.0052e-05 - rho: 0.0455
    Epoch 48/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 150.2590 - loss: 150.2589 - val_ll_loss: 149.4310 - val_loss: 149.4310 - learning_rate: 9.0953e-06 - rho: 0.0449
    Epoch 49/60


    2026-02-24 18:58:56.637012: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:56.803224: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 149.9644 - loss: 149.9645 - val_ll_loss: 149.3993 - val_loss: 149.3993 - learning_rate: 8.2297e-06 - rho: 0.0442
    Epoch 50/60


    2026-02-24 18:58:58.935391: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:58:59.084647: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 148.8594 - loss: 148.8593 - val_ll_loss: 149.3747 - val_loss: 149.3747 - learning_rate: 7.4466e-06 - rho: 0.0437
    Epoch 51/60


    2026-02-24 18:59:01.406385: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:59:01.577714: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 152.1659 - loss: 152.1661 - val_ll_loss: 149.3645 - val_loss: 149.3645 - learning_rate: 6.7379e-06 - rho: 0.0431
    Epoch 52/60


    2026-02-24 18:59:03.847136: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:59:04.003623: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 149.9341 - loss: 149.9342 - val_ll_loss: 149.3436 - val_loss: 149.3436 - learning_rate: 6.0967e-06 - rho: 0.0425
    Epoch 53/60


    2026-02-24 18:59:06.321369: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:59:06.484388: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 149.2595 - loss: 149.2596 - val_ll_loss: 149.3382 - val_loss: 149.3383 - learning_rate: 5.5166e-06 - rho: 0.0420
    Epoch 54/60


    2026-02-24 18:59:08.978301: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:59:09.163224: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 150.4602 - loss: 150.4603 - val_ll_loss: 149.3185 - val_loss: 149.3185 - learning_rate: 4.9916e-06 - rho: 0.0415
    Epoch 55/60


    2026-02-24 18:59:11.520250: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:59:11.690446: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 149.3727 - loss: 149.3728 - val_ll_loss: 149.3119 - val_loss: 149.3119 - learning_rate: 4.5166e-06 - rho: 0.0410
    Epoch 56/60


    2026-02-24 18:59:14.046977: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:59:14.230310: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 149.8671 - loss: 149.8671 - val_ll_loss: 149.3033 - val_loss: 149.3033 - learning_rate: 4.0868e-06 - rho: 0.0405
    Epoch 57/60


    2026-02-24 18:59:16.479282: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:59:16.647447: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 148.7127 - loss: 148.7128 - val_ll_loss: 149.2852 - val_loss: 149.2853 - learning_rate: 3.6979e-06 - rho: 0.0400
    Epoch 58/60


    2026-02-24 18:59:18.824473: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:59:19.010452: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 152.1374 - loss: 152.1373 - val_ll_loss: 149.2793 - val_loss: 149.2793 - learning_rate: 3.3460e-06 - rho: 0.0395
    Epoch 59/60


    2026-02-24 18:59:21.237956: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:59:21.405739: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 150.2646 - loss: 150.2646 - val_ll_loss: 149.2702 - val_loss: 149.2702 - learning_rate: 3.0276e-06 - rho: 0.0391
    Epoch 60/60


    2026-02-24 18:59:23.503006: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:59:23.638772: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 147.3001 - loss: 147.3002 - val_ll_loss: 149.2570 - val_loss: 149.2570 - learning_rate: 2.7394e-06 - rho: 0.0386


    2026-02-24 18:59:25.820497: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 18:59:25.964197: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624



    Getting free energy: 0it [00:00, ?it/s]



    Getting alpha:   0%|          | 0/10 [00:00<?, ?it/s]


    FE_val=149.643 | collapsed=False
        BEST seed=11 | collapsed=False | FE_val=147.287 | FOmax=0.789 | Hnorm=0.010 | n_active=4


    2026-02-24 18:59:45 INFO osl-dynamics [inf_mod_base.py:1321:random_subset_initialization]: Random subset initialization
    2026-02-24 18:59:46 INFO osl-dynamics [inf_mod_base.py:1332:random_subset_initialization]: Using 4 out of 18 batches
    2026-02-24 18:59:46 INFO osl-dynamics [inf_mod_base.py:1337:random_subset_initialization]: Initialization 0


    Epoch 1/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m8s[0m 52ms/step - ll_loss: 235.7474 - loss: 235.7475 - learning_rate: 0.0010 - rho: 0.2853
    Epoch 2/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m4s[0m 1s/step - ll_loss: 205.1958 - loss: 204.3059 - learning_rate: 9.0484e-04 - rho: 0.2403
    Epoch 3/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 43ms/step - ll_loss: 222.2298 - loss: 224.9042 - learning_rate: 8.1873e-04 - rho: 0.2094
    Epoch 4/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 37ms/step - ll_loss: 224.0560 - loss: 224.0560 - learning_rate: 7.4082e-04 - rho: 0.1866
    Epoch 5/5
    [1m4/4[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m0s[0m 26ms/step - ll_loss: 224.0381 - loss: 231.6168 - learning_rate: 6.7032e-04 - rho: 0.1691


    2026-02-24 18:59:58 INFO osl-dynamics [inf_mod_base.py:1365:random_subset_initialization]: Using initialization 0


    Epoch 1/60
    [1m140/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 10ms/step - ll_loss: 205.0571 - loss: 205.0571

    2026-02-24 19:00:09.153628: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m13s[0m 29ms/step - ll_loss: 205.3869 - loss: 205.3869 - val_ll_loss: 194.2643 - val_loss: 194.2643 - learning_rate: 0.0010 - rho: 0.2853
    Epoch 2/60


    2026-02-24 19:00:12.173835: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 197.9356 - loss: 197.9356 - val_ll_loss: 186.1028 - val_loss: 186.1028 - learning_rate: 9.0484e-04 - rho: 0.2403
    Epoch 3/60


    2026-02-24 19:00:14.442057: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:00:14.569382: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 193.5595 - loss: 193.5596 - val_ll_loss: 180.2028 - val_loss: 180.2028 - learning_rate: 8.1873e-04 - rho: 0.2094
    Epoch 4/60


    2026-02-24 19:00:16.670347: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:00:16.803428: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 181.5506 - loss: 181.5507 - val_ll_loss: 175.6778 - val_loss: 175.6777 - learning_rate: 7.4082e-04 - rho: 0.1866
    Epoch 5/60


    2026-02-24 19:00:18.846311: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:00:18.988939: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 174.8956 - loss: 174.8955 - val_ll_loss: 172.0868 - val_loss: 172.0868 - learning_rate: 6.7032e-04 - rho: 0.1691
    Epoch 6/60


    2026-02-24 19:00:21.149876: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:00:21.309011: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 176.7007 - loss: 176.7006 - val_ll_loss: 169.0918 - val_loss: 169.0919 - learning_rate: 6.0653e-04 - rho: 0.1551
    Epoch 7/60


    2026-02-24 19:00:23.387890: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:00:23.548676: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 11ms/step - ll_loss: 168.3105 - loss: 168.3106

    2026-02-24 19:00:25.798549: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:00:25.999004: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 168.5446 - loss: 168.5446 - val_ll_loss: 166.6353 - val_loss: 166.6353 - learning_rate: 5.4881e-04 - rho: 0.1436
    Epoch 8/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 169.4155 - loss: 169.4156 - val_ll_loss: 164.5493 - val_loss: 164.5493 - learning_rate: 4.9659e-04 - rho: 0.1340
    Epoch 9/60


    2026-02-24 19:00:28.151209: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:00:28.298579: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 167.2492 - loss: 167.2492 - val_ll_loss: 162.7728 - val_loss: 162.7728 - learning_rate: 4.4933e-04 - rho: 0.1258
    Epoch 10/60


    2026-02-24 19:00:30.441102: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:00:30.576341: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 159.1142 - loss: 159.1142 - val_ll_loss: 161.2933 - val_loss: 161.2933 - learning_rate: 4.0657e-04 - rho: 0.1187
    Epoch 11/60


    2026-02-24 19:00:32.725016: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:00:32.883983: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 163.1855 - loss: 163.1855 - val_ll_loss: 159.9703 - val_loss: 159.9702 - learning_rate: 3.6788e-04 - rho: 0.1125
    Epoch 12/60


    2026-02-24 19:00:35.016233: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:00:35.175541: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 160.7455 - loss: 160.7455 - val_ll_loss: 158.8741 - val_loss: 158.8741 - learning_rate: 3.3287e-04 - rho: 0.1071
    Epoch 13/60


    2026-02-24 19:00:37.316639: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:00:37.477668: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m139/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 11ms/step - ll_loss: 159.0426 - loss: 159.0427

    2026-02-24 19:00:39.640804: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:00:39.838131: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 159.0832 - loss: 159.0833 - val_ll_loss: 157.9509 - val_loss: 157.9509 - learning_rate: 3.0119e-04 - rho: 0.1022
    Epoch 14/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 157.6722 - loss: 157.6721 - val_ll_loss: 157.1249 - val_loss: 157.1249 - learning_rate: 2.7253e-04 - rho: 0.0979
    Epoch 15/60


    2026-02-24 19:00:41.978539: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:00:42.121336: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 158.9307 - loss: 158.9307 - val_ll_loss: 156.3525 - val_loss: 156.3525 - learning_rate: 2.4660e-04 - rho: 0.0939
    Epoch 16/60


    2026-02-24 19:00:44.342665: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:00:44.476034: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 161.2320 - loss: 161.2321 - val_ll_loss: 155.7223 - val_loss: 155.7223 - learning_rate: 2.2313e-04 - rho: 0.0904
    Epoch 17/60


    2026-02-24 19:00:46.577473: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:00:46.720379: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 157.3306 - loss: 157.3307 - val_ll_loss: 155.1543 - val_loss: 155.1542 - learning_rate: 2.0190e-04 - rho: 0.0871
    Epoch 18/60


    2026-02-24 19:00:48.750871: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:00:48.893814: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 153.6013 - loss: 153.6013 - val_ll_loss: 154.6854 - val_loss: 154.6853 - learning_rate: 1.8268e-04 - rho: 0.0841
    Epoch 19/60


    2026-02-24 19:00:51.146847: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:00:51.288619: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 154.7751 - loss: 154.7751 - val_ll_loss: 154.2437 - val_loss: 154.2437 - learning_rate: 1.6530e-04 - rho: 0.0814
    Epoch 20/60


    2026-02-24 19:00:53.732149: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:00:53.911203: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 153.8873 - loss: 153.8873 - val_ll_loss: 153.8356 - val_loss: 153.8356 - learning_rate: 1.4957e-04 - rho: 0.0789
    Epoch 21/60


    2026-02-24 19:00:56.364331: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:00:56.530966: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 14ms/step - ll_loss: 155.8973 - loss: 155.8973 - val_ll_loss: 153.4593 - val_loss: 153.4593 - learning_rate: 1.3534e-04 - rho: 0.0765
    Epoch 22/60


    2026-02-24 19:00:59.152072: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:00:59.323870: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 156.2908 - loss: 156.2908 - val_ll_loss: 153.1536 - val_loss: 153.1536 - learning_rate: 1.2246e-04 - rho: 0.0743


    2026-02-24 19:01:01.629232: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:01.819214: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    Epoch 23/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 153.2473 - loss: 153.2473 - val_ll_loss: 152.8586 - val_loss: 152.8586 - learning_rate: 1.1080e-04 - rho: 0.0723
    Epoch 24/60


    2026-02-24 19:01:04.268223: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:04.458537: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 150.6414 - loss: 150.6415 - val_ll_loss: 152.6207 - val_loss: 152.6207 - learning_rate: 1.0026e-04 - rho: 0.0704
    Epoch 25/60


    2026-02-24 19:01:06.712617: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:06.881024: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 153.7587 - loss: 153.7588 - val_ll_loss: 152.3814 - val_loss: 152.3813 - learning_rate: 9.0718e-05 - rho: 0.0686
    Epoch 26/60


    2026-02-24 19:01:09.235341: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:09.416628: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 12ms/step - ll_loss: 155.9883 - loss: 155.9883 - val_ll_loss: 152.1580 - val_loss: 152.1580 - learning_rate: 8.2085e-05 - rho: 0.0669
    Epoch 27/60


    2026-02-24 19:01:11.817882: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:11.956049: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m138/157[0m [32m━━━━━━━━━━━━━━━━━[0m[37m━━━[0m [1m0s[0m 13ms/step - ll_loss: 149.6069 - loss: 149.6069

    2026-02-24 19:01:14.371279: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 14ms/step - ll_loss: 149.8661 - loss: 149.8661 - val_ll_loss: 151.9798 - val_loss: 151.9798 - learning_rate: 7.4274e-05 - rho: 0.0653
    Epoch 28/60


    2026-02-24 19:01:14.626644: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 151.8096 - loss: 151.8097 - val_ll_loss: 151.8045 - val_loss: 151.8045 - learning_rate: 6.7206e-05 - rho: 0.0638
    Epoch 29/60


    2026-02-24 19:01:16.906368: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:17.080897: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 150.7321 - loss: 150.7321 - val_ll_loss: 151.6349 - val_loss: 151.6349 - learning_rate: 6.0810e-05 - rho: 0.0624
    Epoch 30/60


    2026-02-24 19:01:19.589130: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:19.759842: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m3s[0m 13ms/step - ll_loss: 153.0532 - loss: 153.0532 - val_ll_loss: 151.4972 - val_loss: 151.4973 - learning_rate: 5.5023e-05 - rho: 0.0610
    Epoch 31/60


    2026-02-24 19:01:22.166112: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:22.318145: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 148.9922 - loss: 148.9922 - val_ll_loss: 151.3806 - val_loss: 151.3806 - learning_rate: 4.9787e-05 - rho: 0.0597
    Epoch 32/60


    2026-02-24 19:01:24.540687: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:24.676896: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 152.1771 - loss: 152.1771 - val_ll_loss: 151.2567 - val_loss: 151.2567 - learning_rate: 4.5049e-05 - rho: 0.0585
    Epoch 33/60


    2026-02-24 19:01:26.800734: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:26.986575: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 152.6096 - loss: 152.6096 - val_ll_loss: 151.1502 - val_loss: 151.1503 - learning_rate: 4.0762e-05 - rho: 0.0574
    Epoch 34/60


    2026-02-24 19:01:29.181248: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:29.339597: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 151.2632 - loss: 151.2631 - val_ll_loss: 151.0587 - val_loss: 151.0587 - learning_rate: 3.6883e-05 - rho: 0.0563
    Epoch 35/60


    2026-02-24 19:01:31.558001: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:31.703206: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 151.2281 - loss: 151.2281 - val_ll_loss: 150.9635 - val_loss: 150.9636 - learning_rate: 3.3373e-05 - rho: 0.0552
    Epoch 36/60


    2026-02-24 19:01:33.790315: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:33.926369: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 150.9683 - loss: 150.9684 - val_ll_loss: 150.8934 - val_loss: 150.8935 - learning_rate: 3.0197e-05 - rho: 0.0542
    Epoch 37/60


    2026-02-24 19:01:36.186495: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:36.346380: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 150.3325 - loss: 150.3325 - val_ll_loss: 150.8232 - val_loss: 150.8232 - learning_rate: 2.7324e-05 - rho: 0.0532
    Epoch 38/60


    2026-02-24 19:01:38.573809: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:38.742735: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 149.7199 - loss: 149.7199 - val_ll_loss: 150.7628 - val_loss: 150.7628 - learning_rate: 2.4724e-05 - rho: 0.0523
    Epoch 39/60


    2026-02-24 19:01:41.086214: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:41.250474: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 152.5511 - loss: 152.5511 - val_ll_loss: 150.6965 - val_loss: 150.6966 - learning_rate: 2.2371e-05 - rho: 0.0514
    Epoch 40/60


    2026-02-24 19:01:43.370810: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:43.536067: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 150.7809 - loss: 150.7809 - val_ll_loss: 150.6558 - val_loss: 150.6558 - learning_rate: 2.0242e-05 - rho: 0.0506
    Epoch 41/60


    2026-02-24 19:01:45.706998: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:45.869033: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 149.0900 - loss: 149.0900 - val_ll_loss: 150.5944 - val_loss: 150.5944 - learning_rate: 1.8316e-05 - rho: 0.0498
    Epoch 42/60


    2026-02-24 19:01:48.086910: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:48.238078: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 149.6154 - loss: 149.6154 - val_ll_loss: 150.5619 - val_loss: 150.5619 - learning_rate: 1.6573e-05 - rho: 0.0490
    Epoch 43/60


    2026-02-24 19:01:50.404241: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:50.563925: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 150.5601 - loss: 150.5601 - val_ll_loss: 150.5196 - val_loss: 150.5196 - learning_rate: 1.4996e-05 - rho: 0.0482
    Epoch 44/60


    2026-02-24 19:01:52.707407: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:52.860753: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 150.8301 - loss: 150.8301 - val_ll_loss: 150.4763 - val_loss: 150.4763 - learning_rate: 1.3569e-05 - rho: 0.0475
    Epoch 45/60


    2026-02-24 19:01:54.938911: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:55.081452: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 149.0157 - loss: 149.0156 - val_ll_loss: 150.4418 - val_loss: 150.4418 - learning_rate: 1.2277e-05 - rho: 0.0468
    Epoch 46/60


    2026-02-24 19:01:57.240021: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:57.415398: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 152.3661 - loss: 152.3661 - val_ll_loss: 150.4251 - val_loss: 150.4251 - learning_rate: 1.1109e-05 - rho: 0.0461
    Epoch 47/60


    2026-02-24 19:01:59.420329: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:01:59.566507: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 149.2738 - loss: 149.2737 - val_ll_loss: 150.4020 - val_loss: 150.4020 - learning_rate: 1.0052e-05 - rho: 0.0455


    2026-02-24 19:02:01.568106: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:02:01.761661: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    Epoch 48/60
    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 150.7383 - loss: 150.7383 - val_ll_loss: 150.3723 - val_loss: 150.3723 - learning_rate: 9.0953e-06 - rho: 0.0449
    Epoch 49/60


    2026-02-24 19:02:04.018662: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:02:04.197955: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 148.6716 - loss: 148.6716 - val_ll_loss: 150.3417 - val_loss: 150.3417 - learning_rate: 8.2297e-06 - rho: 0.0442
    Epoch 50/60


    2026-02-24 19:02:06.365556: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:02:06.507394: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 147.3997 - loss: 147.3996 - val_ll_loss: 150.3377 - val_loss: 150.3377 - learning_rate: 7.4466e-06 - rho: 0.0437
    Epoch 51/60


    2026-02-24 19:02:08.479292: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:02:08.626555: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 149.6874 - loss: 149.6874 - val_ll_loss: 150.3105 - val_loss: 150.3105 - learning_rate: 6.7379e-06 - rho: 0.0431
    Epoch 52/60


    2026-02-24 19:02:10.637433: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:02:10.788349: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 148.3469 - loss: 148.3470 - val_ll_loss: 150.2988 - val_loss: 150.2988 - learning_rate: 6.0967e-06 - rho: 0.0425
    Epoch 53/60


    2026-02-24 19:02:12.938444: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:02:13.120085: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 147.1338 - loss: 147.1338 - val_ll_loss: 150.2769 - val_loss: 150.2769 - learning_rate: 5.5166e-06 - rho: 0.0420
    Epoch 54/60


    2026-02-24 19:02:15.273693: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:02:15.421249: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 148.4338 - loss: 148.4339 - val_ll_loss: 150.2726 - val_loss: 150.2726 - learning_rate: 4.9916e-06 - rho: 0.0415
    Epoch 55/60


    2026-02-24 19:02:17.461320: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:02:17.608598: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 148.4659 - loss: 148.4659 - val_ll_loss: 150.2495 - val_loss: 150.2495 - learning_rate: 4.5166e-06 - rho: 0.0410
    Epoch 56/60


    2026-02-24 19:02:19.773120: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:02:19.925478: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 148.6182 - loss: 148.6182 - val_ll_loss: 150.2429 - val_loss: 150.2429 - learning_rate: 4.0868e-06 - rho: 0.0405
    Epoch 57/60


    2026-02-24 19:02:22.110683: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:02:22.244362: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 150.8049 - loss: 150.8050 - val_ll_loss: 150.2382 - val_loss: 150.2382 - learning_rate: 3.6979e-06 - rho: 0.0400
    Epoch 58/60


    2026-02-24 19:02:24.291202: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:02:24.481006: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 10ms/step - ll_loss: 150.0029 - loss: 150.0029 - val_ll_loss: 150.2207 - val_loss: 150.2207 - learning_rate: 3.3460e-06 - rho: 0.0395
    Epoch 59/60


    2026-02-24 19:02:26.458875: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:02:26.620764: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 11ms/step - ll_loss: 148.7775 - loss: 148.7775 - val_ll_loss: 150.2149 - val_loss: 150.2148 - learning_rate: 3.0276e-06 - rho: 0.0391
    Epoch 60/60


    2026-02-24 19:02:28.739807: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:02:28.911914: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624


    [1m157/157[0m [32m━━━━━━━━━━━━━━━━━━━━[0m[37m[0m [1m2s[0m 12ms/step - ll_loss: 149.7034 - loss: 149.7034 - val_ll_loss: 150.2119 - val_loss: 150.2118 - learning_rate: 2.7394e-06 - rho: 0.0386


    2026-02-24 19:02:31.141525: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624
    2026-02-24 19:02:31.294289: I tensorflow/core/framework/local_rendezvous.cc:426] Local rendezvous recv item cancelled. Key hash: 15284740300980254624



    Getting free energy: 0it [00:00, ?it/s]



    Getting free energy: 0it [00:00, ?it/s]


    Finished full sweep.



```python
# =========================
# Cell 5 — Summaries (feasibility-conditioned elbow)
# =========================
import matplotlib.pyplot as plt

cv = pd.read_csv(CV_TSV, sep="\t")
print("cv rows:", len(cv))
display(cv.head())

feas = cv.groupby("K")["collapsed"].apply(lambda x: 1.0 - np.mean(x.astype(float))).rename("feasible_frac").reset_index()
fe_mean = cv.groupby("K")["fe_test"].mean().rename("fe_test_mean").reset_index()
summary = feas.merge(fe_mean, on="K", how="left").sort_values("K")
display(summary)

plt.figure(figsize=(6,4))
plt.plot(summary["K"], summary["feasible_frac"], marker="o")
plt.ylim(-0.05, 1.05)
plt.xlabel("K")
plt.ylabel("Fraction non-collapsed folds (selected model)")
plt.title("C2-K-sweep feasibility vs K")
plt.tight_layout()
plt.savefig(OUT_ROOT / "feasibility_vs_K.png", dpi=220)
plt.show()

plt.figure(figsize=(6,4))
plt.plot(summary["K"], summary["fe_test_mean"], marker="o")
plt.xlabel("K")
plt.ylabel("Mean test free energy (selected model)")
plt.title("C2-K-sweep mean test FE vs K")
plt.tight_layout()
plt.savefig(OUT_ROOT / "mean_testFE_vs_K.png", dpi=220)
plt.show()

```

    cv rows: 132



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fold</th>
      <th>test_subject</th>
      <th>val_subject</th>
      <th>K</th>
      <th>seed_selected</th>
      <th>collapsed</th>
      <th>fe_train</th>
      <th>fe_val</th>
      <th>fe_test</th>
      <th>fo_max</th>
      <th>...</th>
      <th>neff</th>
      <th>n_active</th>
      <th>n_seeds_tried</th>
      <th>init_take</th>
      <th>D_pca</th>
      <th>feature_mode</th>
      <th>seq_len</th>
      <th>step_size</th>
      <th>batch_size</th>
      <th>runwise_zscore</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>sub-01</td>
      <td>sub-08</td>
      <td>2</td>
      <td>23</td>
      <td>False</td>
      <td>156.723480</td>
      <td>153.863827</td>
      <td>161.751299</td>
      <td>0.900989</td>
      <td>...</td>
      <td>1.343603</td>
      <td>2</td>
      <td>5</td>
      <td>0.3</td>
      <td>80</td>
      <td>nolags</td>
      <td>10</td>
      <td>1</td>
      <td>16</td>
      <td>True</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>sub-01</td>
      <td>sub-08</td>
      <td>3</td>
      <td>37</td>
      <td>False</td>
      <td>153.527804</td>
      <td>149.303714</td>
      <td>160.173836</td>
      <td>0.834204</td>
      <td>...</td>
      <td>2.054163</td>
      <td>3</td>
      <td>5</td>
      <td>0.3</td>
      <td>80</td>
      <td>nolags</td>
      <td>10</td>
      <td>1</td>
      <td>16</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>sub-01</td>
      <td>sub-08</td>
      <td>4</td>
      <td>23</td>
      <td>False</td>
      <td>150.726093</td>
      <td>148.702290</td>
      <td>157.679390</td>
      <td>0.803246</td>
      <td>...</td>
      <td>1.819098</td>
      <td>3</td>
      <td>5</td>
      <td>0.3</td>
      <td>80</td>
      <td>nolags</td>
      <td>10</td>
      <td>1</td>
      <td>16</td>
      <td>True</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>sub-01</td>
      <td>sub-08</td>
      <td>5</td>
      <td>23</td>
      <td>False</td>
      <td>147.150016</td>
      <td>147.926248</td>
      <td>161.128718</td>
      <td>0.721066</td>
      <td>...</td>
      <td>2.338935</td>
      <td>3</td>
      <td>5</td>
      <td>0.3</td>
      <td>80</td>
      <td>nolags</td>
      <td>10</td>
      <td>1</td>
      <td>16</td>
      <td>True</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>sub-01</td>
      <td>sub-08</td>
      <td>6</td>
      <td>53</td>
      <td>False</td>
      <td>150.252019</td>
      <td>149.540434</td>
      <td>160.105517</td>
      <td>0.747091</td>
      <td>...</td>
      <td>2.182150</td>
      <td>4</td>
      <td>5</td>
      <td>0.2</td>
      <td>80</td>
      <td>nolags</td>
      <td>10</td>
      <td>1</td>
      <td>16</td>
      <td>True</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 22 columns</p>
</div>



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>K</th>
      <th>feasible_frac</th>
      <th>fe_test_mean</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2</td>
      <td>1.0</td>
      <td>152.114193</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3</td>
      <td>1.0</td>
      <td>150.465169</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4</td>
      <td>1.0</td>
      <td>151.024427</td>
    </tr>
    <tr>
      <th>3</th>
      <td>5</td>
      <td>1.0</td>
      <td>150.353642</td>
    </tr>
    <tr>
      <th>4</th>
      <td>6</td>
      <td>1.0</td>
      <td>150.413367</td>
    </tr>
    <tr>
      <th>5</th>
      <td>7</td>
      <td>1.0</td>
      <td>150.779313</td>
    </tr>
    <tr>
      <th>6</th>
      <td>8</td>
      <td>1.0</td>
      <td>150.095737</td>
    </tr>
    <tr>
      <th>7</th>
      <td>9</td>
      <td>1.0</td>
      <td>149.762349</td>
    </tr>
    <tr>
      <th>8</th>
      <td>10</td>
      <td>1.0</td>
      <td>149.806282</td>
    </tr>
    <tr>
      <th>9</th>
      <td>11</td>
      <td>1.0</td>
      <td>149.874885</td>
    </tr>
    <tr>
      <th>10</th>
      <td>12</td>
      <td>1.0</td>
      <td>149.326251</td>
    </tr>
  </tbody>
</table>
</div>



    
![png](output_6_3.png)
    



    
![png](output_6_4.png)
    



```python

```


```python
import numpy as np
import pandas as pd
import math
import json
import matplotlib.pyplot as plt
from scipy.stats import wilcoxon, ttest_rel

CV_TSV   = OUT_ROOT / "cv_results.tsv"
CAND_TSV = OUT_ROOT / "cv_candidates_long.tsv"

cv = pd.read_csv(CV_TSV, sep="\t")
cand = pd.read_csv(CAND_TSV, sep="\t")

# -----------------------------
# Summary by K (selected models)
# -----------------------------
summ = []
for K in sorted(cv["K"].unique()):
    d = cv.loc[cv["K"] == K].sort_values("fold")
    fe = d["fe_test"].astype(float).to_numpy()
    mean = float(np.mean(fe))
    std  = float(np.std(fe, ddof=1))
    sem  = std / math.sqrt(len(fe))
    feasible_frac = float(np.mean(~d["collapsed"].astype(bool)))
    summ.append(dict(
        K=int(K),
        n_folds=int(len(fe)),
        feasible_frac=feasible_frac,
        fe_test_mean=mean,
        fe_test_std=std,
        fe_test_sem=sem,
        fo_max_median=float(np.median(d["fo_max"])),
        n_active_median=float(np.median(d["n_active"])),
        neff_median=float(np.median(d["neff"])),
    ))
summary = pd.DataFrame(summ).sort_values("K")
summary.to_csv(OUT_ROOT / "summary_byK_selected.tsv", sep="\t", index=False)

# -----------------------------
# Candidate-level feasibility (all seeds)
# -----------------------------
cand["collapsed"] = cand["collapsed"].astype(bool)
cand_summ = cand.groupby("K").agg(
    cand_noncollapsed_frac=("collapsed", lambda x: float(np.mean(~x))),
    cand_collapsed_frac=("collapsed", lambda x: float(np.mean(x))),
    cand_mean_fo_max=("fo_max","mean"),
    cand_mean_entropy=("entropy_norm","mean"),
    cand_mean_n_active=("n_active","mean"),
).reset_index().sort_values("K")
cand_summ.to_csv(OUT_ROOT / "summary_byK_candidates.tsv", sep="\t", index=False)

# -----------------------------
# 1-SE rule (parsimony)
# -----------------------------
best_row = summary.loc[summary["fe_test_mean"].idxmin()]
K_best   = int(best_row["K"])
best_mu  = float(best_row["fe_test_mean"])
best_sem = float(best_row["fe_test_sem"])
threshold = best_mu + best_sem
K_1se = int(summary.loc[summary["fe_test_mean"] <= threshold, "K"].min())

# -----------------------------
# Paired tests vs K_best
# -----------------------------
best = cv.loc[cv["K"] == K_best].sort_values("fold").set_index("fold")["fe_test"].astype(float)

tests = []
for K in sorted(cv["K"].unique()):
    if int(K) == K_best:
        continue
    x = cv.loc[cv["K"] == K].sort_values("fold").set_index("fold")["fe_test"].astype(float)
    common = best.index.intersection(x.index)
    diff = (x.loc[common] - best.loc[common]).to_numpy()

    # Wilcoxon (non-parametric) + paired t-test
    try:
        p_w = float(wilcoxon(diff).pvalue)
    except Exception:
        p_w = np.nan
    p_t = float(ttest_rel(x.loc[common].to_numpy(), best.loc[common].to_numpy()).pvalue)

    tests.append(dict(
        K=int(K),
        mean_diff_vs_best=float(np.mean(diff)),
        wilcoxon_p=p_w,
        paired_t_p=p_t
    ))
tests_df = pd.DataFrame(tests).sort_values("K")
tests_df.to_csv(OUT_ROOT / "paired_tests_vs_bestK.tsv", sep="\t", index=False)

# -----------------------------
# Local minima in mean FE curve
# -----------------------------
locmin = []
s = summary.reset_index(drop=True)
for i in range(len(s)):
    left  = s.loc[i-1, "fe_test_mean"] if i > 0 else np.inf
    right = s.loc[i+1, "fe_test_mean"] if i < len(s)-1 else np.inf
    if s.loc[i, "fe_test_mean"] < left and s.loc[i, "fe_test_mean"] < right:
        locmin.append(int(s.loc[i, "K"]))

# -----------------------------
# Recommended shortlist
# -----------------------------
shortlist_primary = [5, 9, 12]              # my recommended stability shortlist
shortlist_optional = [K_1se] if K_1se not in shortlist_primary else []

recommendation = dict(
    K_best=K_best,
    best_mean_testFE=best_mu,
    best_sem_testFE=best_sem,
    oneSE_threshold=threshold,
    K_1se=K_1se,
    local_minima=locmin,
    shortlist_primary=shortlist_primary,
    shortlist_optional=shortlist_optional,
)
(OUT_ROOT / "K_selection_recommendation.json").write_text(json.dumps(recommendation, indent=2))

print("K_best:", K_best, "mean:", best_mu, "SEM:", best_sem)
print("1-SE threshold:", threshold, "=> K_1se:", K_1se)
print("Local minima:", locmin)
print("Recommended shortlist (primary):", shortlist_primary, "| optional:", shortlist_optional)

# -----------------------------
# Plots: mean±SEM + 1SE line
# -----------------------------
plt.figure(figsize=(6,4))
plt.errorbar(summary["K"], summary["fe_test_mean"], yerr=summary["fe_test_sem"], marker="o", capsize=3)
plt.axhline(best_mu, linestyle="--")
plt.axhline(threshold, linestyle=":")
plt.xlabel("K")
plt.ylabel("Mean test free energy (selected) ± SEM")
plt.title("C2 K-sweep: mean test FE with SEM + 1-SE threshold")
plt.tight_layout()
plt.savefig(OUT_ROOT / "mean_testFE_with_SEM.png", dpi=220)
plt.show()

plt.figure(figsize=(6,4))
plt.plot(summary["K"], summary["feasible_frac"], marker="o")
plt.ylim(-0.05, 1.05)
plt.xlabel("K")
plt.ylabel("Feasible fraction (selected model)")
plt.title("C2 K-sweep: feasibility vs K")
plt.tight_layout()
plt.savefig(OUT_ROOT / "feasibility_vs_K.png", dpi=220)
plt.show()
```

    K_best: 12 mean: 149.32625111224627 SEM: 2.398274149314499
    1-SE threshold: 151.72452526156076 => K_1se: 3
    Local minima: [3, 5, 9, 12]
    Recommended shortlist (primary): [5, 9, 12] | optional: [3]



    
![png](output_8_1.png)
    



    
![png](output_8_2.png)
    



```python

```
