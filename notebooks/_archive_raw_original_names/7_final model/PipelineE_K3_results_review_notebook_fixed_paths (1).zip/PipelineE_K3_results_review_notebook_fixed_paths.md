# PipelineE K=3 results review

This notebook is for **post-hoc review of an already-fitted PipelineE model**.

It does **not retrain the HMM**. It reads the saved outputs using the **actual save layout from the PipelineE full model script**:

**Saved at `OUT_ROOT`**
- `qc_summary.json`
- `subject_metrics.tsv`
- `run_metrics.tsv`
- `dwell_from_A.tsv`
- `topM_seeds.json`

**Saved at `OUT_ROOT / "final"`**
- `refit_results.json`
- `best_seed.json`
- `trans_prob.npy`
- `state_signature_ut_boldcorr.npy`
- `means_pca.npy`
- `covs_pca.npy`

Main goals:
1. Verify that the final K=3 solution passed QC.
2. Check whether one state dominates globally, per subject, and per run.
3. Quantify transition structure and dwell times.
4. Inspect whether the state signatures look strongly distinct or more like variations around one backbone pattern.
5. Produce figures you can reuse or adapt.



```python
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# --------------------------------------------------
# EDIT THIS PATH ONLY
# This should be PipelineE OUT_ROOT from the full model script:
# OUT_ROOT = Path("/mnt/c/EEGFMRI/hmm/R01_rerun/02_derivatives/fusion_prep/fusion_hmm_FINAL") / f"PipelineE_final_K{K_FINAL:02d}_{DATA_VARIANT}_{FEATURE_MODE}_minlen{MINLEN}"
# --------------------------------------------------
RESULT_ROOT = Path('/mnt/c/EEGFMRI/hmm/R01_rerun/02_derivatives/fusion_prep/fusion_hmm_FINAL/PipelineE_final_K03_intermediate_nolags_minlen15')
FINAL_DIR   = RESULT_ROOT / 'final'

OUT_FIG_DIR = RESULT_ROOT / 'review_figures'
OUT_FIG_DIR.mkdir(exist_ok=True, parents=True)

plt.rcParams['figure.dpi'] = 130
plt.rcParams['axes.spines.top'] = False
plt.rcParams['axes.spines.right'] = False

def require_file(label, *candidates):
    for p in candidates:
        p = Path(p)
        if p.exists():
            return p
    tried = "\n".join(str(Path(p)) for p in candidates)
    raise FileNotFoundError(f"Could not find {label}. Tried:\n{tried}")

print('RESULT_ROOT:', RESULT_ROOT)
print('FINAL_DIR   :', FINAL_DIR)

```

    RESULT_ROOT: /mnt/c/EEGFMRI/hmm/R01_rerun/02_derivatives/fusion_prep/fusion_hmm_FINAL/PipelineE_final_K03_intermediate_nolags_minlen15
    FINAL_DIR   : /mnt/c/EEGFMRI/hmm/R01_rerun/02_derivatives/fusion_prep/fusion_hmm_FINAL/PipelineE_final_K03_intermediate_nolags_minlen15/final



```python
# ------------------------------
# Resolve and load saved PipelineE outputs
# ------------------------------
QC_PATH         = require_file('qc_summary.json', RESULT_ROOT / 'qc_summary.json')
REFIT_PATH      = require_file('refit_results.json', FINAL_DIR / 'refit_results.json', RESULT_ROOT / 'refit_results.json')
SUBJECT_PATH    = require_file('subject_metrics.tsv', RESULT_ROOT / 'subject_metrics.tsv')
RUN_PATH        = require_file('run_metrics.tsv', RESULT_ROOT / 'run_metrics.tsv')
DWELL_PATH      = require_file('dwell_from_A.tsv', RESULT_ROOT / 'dwell_from_A.tsv')
A_PATH          = require_file('trans_prob.npy', FINAL_DIR / 'trans_prob.npy', RESULT_ROOT / 'trans_prob.npy')
SIG_PATH        = require_file('state_signature_ut_boldcorr.npy', FINAL_DIR / 'state_signature_ut_boldcorr.npy', RESULT_ROOT / 'state_signature_ut_boldcorr.npy')
MEANS_PATH      = require_file('means_pca.npy', FINAL_DIR / 'means_pca.npy', RESULT_ROOT / 'means_pca.npy')
COVS_PATH       = require_file('covs_pca.npy', FINAL_DIR / 'covs_pca.npy', RESULT_ROOT / 'covs_pca.npy')

with open(QC_PATH, 'r', encoding='utf-8') as f:
    qc = json.load(f)

with open(REFIT_PATH, 'r', encoding='utf-8') as f:
    refit = json.load(f)

subject_metrics = pd.read_csv(SUBJECT_PATH, sep='\t')
run_metrics     = pd.read_csv(RUN_PATH, sep='\t')
dwell_from_A    = pd.read_csv(DWELL_PATH, sep='\t')
A               = np.load(A_PATH)
state_sig       = np.load(SIG_PATH)
means_pca       = np.load(MEANS_PATH)
covs_pca        = np.load(COVS_PATH)

print('Resolved files:')
print('  qc_summary.json               ->', QC_PATH)
print('  refit_results.json           ->', REFIT_PATH)
print('  subject_metrics.tsv          ->', SUBJECT_PATH)
print('  run_metrics.tsv              ->', RUN_PATH)
print('  dwell_from_A.tsv             ->', DWELL_PATH)
print('  trans_prob.npy               ->', A_PATH)
print('  state_signature_ut_boldcorr  ->', SIG_PATH)
print('  means_pca.npy                ->', MEANS_PATH)
print('  covs_pca.npy                 ->', COVS_PATH)
print()
print('qc_summary keys:', list(qc.keys()))
print('refit candidates:', len(refit))
print('subject_metrics shape:', subject_metrics.shape)
print('run_metrics shape    :', run_metrics.shape)
print('dwell_from_A shape   :', dwell_from_A.shape)
print('A shape              :', A.shape)
print('state_sig shape      :', state_sig.shape)
print('means_pca shape      :', means_pca.shape)
print('covs_pca shape       :', covs_pca.shape)

```

    Resolved files:
      qc_summary.json               -> /mnt/c/EEGFMRI/hmm/R01_rerun/02_derivatives/fusion_prep/fusion_hmm_FINAL/PipelineE_final_K03_intermediate_nolags_minlen15/qc_summary.json
      refit_results.json           -> /mnt/c/EEGFMRI/hmm/R01_rerun/02_derivatives/fusion_prep/fusion_hmm_FINAL/PipelineE_final_K03_intermediate_nolags_minlen15/final/refit_results.json
      subject_metrics.tsv          -> /mnt/c/EEGFMRI/hmm/R01_rerun/02_derivatives/fusion_prep/fusion_hmm_FINAL/PipelineE_final_K03_intermediate_nolags_minlen15/subject_metrics.tsv
      run_metrics.tsv              -> /mnt/c/EEGFMRI/hmm/R01_rerun/02_derivatives/fusion_prep/fusion_hmm_FINAL/PipelineE_final_K03_intermediate_nolags_minlen15/run_metrics.tsv
      dwell_from_A.tsv             -> /mnt/c/EEGFMRI/hmm/R01_rerun/02_derivatives/fusion_prep/fusion_hmm_FINAL/PipelineE_final_K03_intermediate_nolags_minlen15/dwell_from_A.tsv
      trans_prob.npy               -> /mnt/c/EEGFMRI/hmm/R01_rerun/02_derivatives/fusion_prep/fusion_hmm_FINAL/PipelineE_final_K03_intermediate_nolags_minlen15/final/trans_prob.npy
      state_signature_ut_boldcorr  -> /mnt/c/EEGFMRI/hmm/R01_rerun/02_derivatives/fusion_prep/fusion_hmm_FINAL/PipelineE_final_K03_intermediate_nolags_minlen15/final/state_signature_ut_boldcorr.npy
      means_pca.npy                -> /mnt/c/EEGFMRI/hmm/R01_rerun/02_derivatives/fusion_prep/fusion_hmm_FINAL/PipelineE_final_K03_intermediate_nolags_minlen15/final/means_pca.npy
      covs_pca.npy                 -> /mnt/c/EEGFMRI/hmm/R01_rerun/02_derivatives/fusion_prep/fusion_hmm_FINAL/PipelineE_final_K03_intermediate_nolags_minlen15/final/covs_pca.npy
    
    qc_summary keys: ['n_runs', 'collapsed_run_count', 'collapsed_run_rate', 'run_state_presence', 'seed_identifiability_median_mean_state_corr', 'seed_identifiability_min_mean_state_corr', 'final_seed', 'final_seed_fe', 'final_seed_fo_max', 'final_seed_n_active', 'final_seed_neff']
    refit candidates: 3
    subject_metrics shape: (12, 10)
    run_metrics shape    : (15, 11)
    dwell_from_A shape   : (3, 3)
    A shape              : (3, 3)
    state_sig shape      : (3, 19900)
    means_pca shape      : (3, 80)
    covs_pca shape       : (3, 80, 80)



```python
# ------------------------------
# Helpers
# ------------------------------
STATE_COLS = ['FO_s01', 'FO_s02', 'FO_s03']
STATE_NAMES = ['S1', 'S2', 'S3']


def stationary_distribution(A):
    eigvals, eigvecs = np.linalg.eig(A.T)
    idx = np.argmin(np.abs(eigvals - 1.0))
    pi = np.real(eigvecs[:, idx])
    pi = pi / pi.sum()
    return pi


def dwell_from_transition_matrix(A, eps=1e-12):
    A = np.asarray(A, dtype=float)
    Akk = np.clip(np.diag(A), 0.0, 1.0 - eps)
    return 1.0 / (1.0 - Akk)


def entropy_of_fo(fo, eps=1e-12):
    fo = np.asarray(fo, dtype=float)
    fo = np.clip(fo, eps, None)
    fo = fo / fo.sum()
    H = -(fo * np.log(fo)).sum()
    neff = np.exp(H)
    return H, neff


def dominant_state_labels(df, cols=STATE_COLS):
    idx = df[cols].to_numpy().argmax(axis=1)
    return pd.Series(idx + 1, index=df.index)


def pairwise_row_corr(X):
    X = np.asarray(X, dtype=float)
    n = X.shape[0]
    out = np.eye(n, dtype=float)
    for i in range(n):
        for j in range(i + 1, n):
            c = np.corrcoef(X[i], X[j])[0, 1]
            out[i, j] = c
            out[j, i] = c
    return out
```

## 1) QC and final-seed recap

This section mirrors the logic of your PipelineE summary:
- collapsed run rate
n- state presence rate across runs
- final selected seed after Top-M refit
- free energy, `FO_max`, and `n_eff`


```python
qc_df = pd.DataFrame([qc]).T
qc_df.columns = ['value']
qc_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>n_runs</th>
      <td>15</td>
    </tr>
    <tr>
      <th>collapsed_run_count</th>
      <td>0</td>
    </tr>
    <tr>
      <th>collapsed_run_rate</th>
      <td>0.0</td>
    </tr>
    <tr>
      <th>run_state_presence</th>
      <td>{'state_01_presence_rate': 1.0, 'state_02_pres...</td>
    </tr>
    <tr>
      <th>seed_identifiability_median_mean_state_corr</th>
      <td>0.833809</td>
    </tr>
    <tr>
      <th>seed_identifiability_min_mean_state_corr</th>
      <td>0.738055</td>
    </tr>
    <tr>
      <th>final_seed</th>
      <td>23</td>
    </tr>
    <tr>
      <th>final_seed_fe</th>
      <td>133.245187</td>
    </tr>
    <tr>
      <th>final_seed_fo_max</th>
      <td>0.807597</td>
    </tr>
    <tr>
      <th>final_seed_n_active</th>
      <td>3</td>
    </tr>
    <tr>
      <th>final_seed_neff</th>
      <td>1.86382</td>
    </tr>
  </tbody>
</table>
</div>




```python
refit_df = pd.DataFrame(refit).sort_values('fe').reset_index(drop=True)
refit_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>seed</th>
      <th>rank</th>
      <th>fe</th>
      <th>fo</th>
      <th>fo_max</th>
      <th>entropy_norm</th>
      <th>n_active</th>
      <th>fo_entropy</th>
      <th>neff</th>
      <th>collapsed</th>
      <th>total_T</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>23</td>
      <td>3</td>
      <td>133.245187</td>
      <td>[0.08982254564762115, 0.8075973391532898, 0.10...</td>
      <td>0.807597</td>
      <td>0.004386</td>
      <td>3</td>
      <td>0.566741</td>
      <td>1.863820</td>
      <td>False</td>
      <td>3190</td>
    </tr>
    <tr>
      <th>1</th>
      <td>61</td>
      <td>2</td>
      <td>134.303580</td>
      <td>[0.08332958072423935, 0.02476176619529724, 0.8...</td>
      <td>0.891909</td>
      <td>0.000453</td>
      <td>3</td>
      <td>0.364712</td>
      <td>1.492835</td>
      <td>False</td>
      <td>3190</td>
    </tr>
    <tr>
      <th>2</th>
      <td>27</td>
      <td>4</td>
      <td>135.313792</td>
      <td>[0.8782431483268738, 0.10138065367937088, 0.02...</td>
      <td>0.878243</td>
      <td>0.000313</td>
      <td>3</td>
      <td>0.387219</td>
      <td>1.530208</td>
      <td>False</td>
      <td>3190</td>
    </tr>
  </tbody>
</table>
</div>



## 2) Subject-level and run-level occupancy

Key question:

> Is the dominant state only a group average effect, or is it dominant for nearly every subject and run?

We answer that here.


```python
subject_metrics = subject_metrics.copy()
run_metrics = run_metrics.copy()

subject_metrics['dominant_state'] = dominant_state_labels(subject_metrics)
run_metrics['dominant_state'] = dominant_state_labels(run_metrics)

subject_metrics
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>subject</th>
      <th>n_runs</th>
      <th>total_T</th>
      <th>FO_max</th>
      <th>n_active</th>
      <th>neff</th>
      <th>fo_entropy</th>
      <th>FO_s01</th>
      <th>FO_s02</th>
      <th>FO_s03</th>
      <th>dominant_state</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>sub-01</td>
      <td>1</td>
      <td>260</td>
      <td>0.891134</td>
      <td>3</td>
      <td>1.506815</td>
      <td>0.373196</td>
      <td>0.076948</td>
      <td>0.891134</td>
      <td>3.191727e-02</td>
      <td>2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>sub-02</td>
      <td>1</td>
      <td>270</td>
      <td>0.856293</td>
      <td>3</td>
      <td>1.623787</td>
      <td>0.441249</td>
      <td>0.114077</td>
      <td>0.856293</td>
      <td>2.962957e-02</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>sub-03</td>
      <td>1</td>
      <td>210</td>
      <td>0.642941</td>
      <td>3</td>
      <td>2.321444</td>
      <td>0.766594</td>
      <td>0.080428</td>
      <td>0.642941</td>
      <td>2.766317e-01</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>sub-08</td>
      <td>2</td>
      <td>370</td>
      <td>0.756264</td>
      <td>3</td>
      <td>2.051578</td>
      <td>0.654106</td>
      <td>0.095651</td>
      <td>0.756264</td>
      <td>1.480849e-01</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>sub-09</td>
      <td>1</td>
      <td>220</td>
      <td>0.791904</td>
      <td>3</td>
      <td>1.917281</td>
      <td>0.592482</td>
      <td>0.126206</td>
      <td>0.791904</td>
      <td>8.188962e-02</td>
      <td>2</td>
    </tr>
    <tr>
      <th>5</th>
      <td>sub-13</td>
      <td>2</td>
      <td>450</td>
      <td>0.782143</td>
      <td>3</td>
      <td>1.913891</td>
      <td>0.590871</td>
      <td>0.056749</td>
      <td>0.782143</td>
      <td>1.611083e-01</td>
      <td>2</td>
    </tr>
    <tr>
      <th>6</th>
      <td>sub-14</td>
      <td>1</td>
      <td>250</td>
      <td>0.822529</td>
      <td>3</td>
      <td>1.788581</td>
      <td>0.529234</td>
      <td>0.060522</td>
      <td>0.822529</td>
      <td>1.169485e-01</td>
      <td>2</td>
    </tr>
    <tr>
      <th>7</th>
      <td>sub-16</td>
      <td>1</td>
      <td>200</td>
      <td>0.942428</td>
      <td>2</td>
      <td>1.246369</td>
      <td>0.200466</td>
      <td>0.057572</td>
      <td>0.942428</td>
      <td>1.482843e-15</td>
      <td>2</td>
    </tr>
    <tr>
      <th>8</th>
      <td>sub-17</td>
      <td>2</td>
      <td>450</td>
      <td>0.823702</td>
      <td>3</td>
      <td>1.798066</td>
      <td>0.534048</td>
      <td>0.098514</td>
      <td>0.823702</td>
      <td>7.778334e-02</td>
      <td>2</td>
    </tr>
    <tr>
      <th>9</th>
      <td>sub-18</td>
      <td>1</td>
      <td>170</td>
      <td>0.881812</td>
      <td>3</td>
      <td>1.560429</td>
      <td>0.405021</td>
      <td>0.063016</td>
      <td>0.881812</td>
      <td>5.517235e-02</td>
      <td>2</td>
    </tr>
    <tr>
      <th>10</th>
      <td>sub-20</td>
      <td>1</td>
      <td>270</td>
      <td>0.755957</td>
      <td>3</td>
      <td>2.055895</td>
      <td>0.656020</td>
      <td>0.144441</td>
      <td>0.755957</td>
      <td>9.960210e-02</td>
      <td>2</td>
    </tr>
    <tr>
      <th>11</th>
      <td>sub-21</td>
      <td>1</td>
      <td>70</td>
      <td>0.764614</td>
      <td>3</td>
      <td>2.026447</td>
      <td>0.642888</td>
      <td>0.135072</td>
      <td>0.764614</td>
      <td>1.003142e-01</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
subject_summary = {
    'n_subjects': int(len(subject_metrics)),
    'n_runs': int(len(run_metrics)),
    'dominant_state_subject_counts': subject_metrics['dominant_state'].value_counts().sort_index().to_dict(),
    'dominant_state_run_counts': run_metrics['dominant_state'].value_counts().sort_index().to_dict(),
    'subject_FO_s01_median': float(subject_metrics['FO_s01'].median()),
    'subject_FO_s02_median': float(subject_metrics['FO_s02'].median()),
    'subject_FO_s03_median': float(subject_metrics['FO_s03'].median()),
    'subject_FO_max_median': float(subject_metrics['FO_max'].median()),
    'subject_neff_median': float(subject_metrics['neff'].median()),
}
subject_summary
```




    {'n_subjects': 12,
     'n_runs': 15,
     'dominant_state_subject_counts': {2: 12},
     'dominant_state_run_counts': {2: 15},
     'subject_FO_s01_median': 0.0880394642417495,
     'subject_FO_s02_median': 0.8072167038917542,
     'subject_FO_s03_median': 0.09074585884809491,
     'subject_FO_max_median': 0.8072167038917542,
     'subject_neff_median': 1.8559782499936661}




```python
# Rank subjects by how dominant S2 is
subject_ranked = subject_metrics.sort_values('FO_s02', ascending=False).reset_index(drop=True)
subject_ranked[['subject', 'n_runs', 'total_T', 'FO_s01', 'FO_s02', 'FO_s03', 'FO_max', 'n_active', 'neff']]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>subject</th>
      <th>n_runs</th>
      <th>total_T</th>
      <th>FO_s01</th>
      <th>FO_s02</th>
      <th>FO_s03</th>
      <th>FO_max</th>
      <th>n_active</th>
      <th>neff</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>sub-16</td>
      <td>1</td>
      <td>200</td>
      <td>0.057572</td>
      <td>0.942428</td>
      <td>1.482843e-15</td>
      <td>0.942428</td>
      <td>2</td>
      <td>1.246369</td>
    </tr>
    <tr>
      <th>1</th>
      <td>sub-01</td>
      <td>1</td>
      <td>260</td>
      <td>0.076948</td>
      <td>0.891134</td>
      <td>3.191727e-02</td>
      <td>0.891134</td>
      <td>3</td>
      <td>1.506815</td>
    </tr>
    <tr>
      <th>2</th>
      <td>sub-18</td>
      <td>1</td>
      <td>170</td>
      <td>0.063016</td>
      <td>0.881812</td>
      <td>5.517235e-02</td>
      <td>0.881812</td>
      <td>3</td>
      <td>1.560429</td>
    </tr>
    <tr>
      <th>3</th>
      <td>sub-02</td>
      <td>1</td>
      <td>270</td>
      <td>0.114077</td>
      <td>0.856293</td>
      <td>2.962957e-02</td>
      <td>0.856293</td>
      <td>3</td>
      <td>1.623787</td>
    </tr>
    <tr>
      <th>4</th>
      <td>sub-17</td>
      <td>2</td>
      <td>450</td>
      <td>0.098514</td>
      <td>0.823702</td>
      <td>7.778334e-02</td>
      <td>0.823702</td>
      <td>3</td>
      <td>1.798066</td>
    </tr>
    <tr>
      <th>5</th>
      <td>sub-14</td>
      <td>1</td>
      <td>250</td>
      <td>0.060522</td>
      <td>0.822529</td>
      <td>1.169485e-01</td>
      <td>0.822529</td>
      <td>3</td>
      <td>1.788581</td>
    </tr>
    <tr>
      <th>6</th>
      <td>sub-09</td>
      <td>1</td>
      <td>220</td>
      <td>0.126206</td>
      <td>0.791904</td>
      <td>8.188962e-02</td>
      <td>0.791904</td>
      <td>3</td>
      <td>1.917281</td>
    </tr>
    <tr>
      <th>7</th>
      <td>sub-13</td>
      <td>2</td>
      <td>450</td>
      <td>0.056749</td>
      <td>0.782143</td>
      <td>1.611083e-01</td>
      <td>0.782143</td>
      <td>3</td>
      <td>1.913891</td>
    </tr>
    <tr>
      <th>8</th>
      <td>sub-21</td>
      <td>1</td>
      <td>70</td>
      <td>0.135072</td>
      <td>0.764614</td>
      <td>1.003142e-01</td>
      <td>0.764614</td>
      <td>3</td>
      <td>2.026447</td>
    </tr>
    <tr>
      <th>9</th>
      <td>sub-08</td>
      <td>2</td>
      <td>370</td>
      <td>0.095651</td>
      <td>0.756264</td>
      <td>1.480849e-01</td>
      <td>0.756264</td>
      <td>3</td>
      <td>2.051578</td>
    </tr>
    <tr>
      <th>10</th>
      <td>sub-20</td>
      <td>1</td>
      <td>270</td>
      <td>0.144441</td>
      <td>0.755957</td>
      <td>9.960210e-02</td>
      <td>0.755957</td>
      <td>3</td>
      <td>2.055895</td>
    </tr>
    <tr>
      <th>11</th>
      <td>sub-03</td>
      <td>1</td>
      <td>210</td>
      <td>0.080428</td>
      <td>0.642941</td>
      <td>2.766317e-01</td>
      <td>0.642941</td>
      <td>3</td>
      <td>2.321444</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Show multi-run subjects to check within-subject consistency across sessions
multi_run = run_metrics.groupby('subject').filter(lambda x: len(x) > 1).copy()
multi_run.sort_values(['subject', 'run'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>subject</th>
      <th>run</th>
      <th>total_T</th>
      <th>FO_max</th>
      <th>n_active</th>
      <th>neff</th>
      <th>entropy_mean_norm</th>
      <th>fo_entropy</th>
      <th>FO_s01</th>
      <th>FO_s02</th>
      <th>FO_s03</th>
      <th>dominant_state</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3</th>
      <td>sub-08</td>
      <td>sub-08_ses-01</td>
      <td>190</td>
      <td>0.750755</td>
      <td>3</td>
      <td>2.070619</td>
      <td>0.005258</td>
      <td>0.662515</td>
      <td>0.096458</td>
      <td>0.750755</td>
      <td>0.152787</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>sub-08</td>
      <td>sub-08_ses-02</td>
      <td>180</td>
      <td>0.762079</td>
      <td>3</td>
      <td>2.031236</td>
      <td>0.004411</td>
      <td>0.645036</td>
      <td>0.094800</td>
      <td>0.762079</td>
      <td>0.143121</td>
      <td>2</td>
    </tr>
    <tr>
      <th>6</th>
      <td>sub-13</td>
      <td>sub-13_ses-01</td>
      <td>240</td>
      <td>0.895271</td>
      <td>3</td>
      <td>1.500771</td>
      <td>0.001710</td>
      <td>0.369538</td>
      <td>0.042256</td>
      <td>0.895271</td>
      <td>0.062473</td>
      <td>2</td>
    </tr>
    <tr>
      <th>7</th>
      <td>sub-13</td>
      <td>sub-13_ses-02</td>
      <td>210</td>
      <td>0.652853</td>
      <td>3</td>
      <td>2.281028</td>
      <td>0.007395</td>
      <td>0.750607</td>
      <td>0.073313</td>
      <td>0.652853</td>
      <td>0.273834</td>
      <td>2</td>
    </tr>
    <tr>
      <th>10</th>
      <td>sub-17</td>
      <td>sub-17_ses-01</td>
      <td>210</td>
      <td>0.844198</td>
      <td>3</td>
      <td>1.714313</td>
      <td>0.006389</td>
      <td>0.490630</td>
      <td>0.089131</td>
      <td>0.844198</td>
      <td>0.066671</td>
      <td>2</td>
    </tr>
    <tr>
      <th>11</th>
      <td>sub-17</td>
      <td>sub-17_ses-02</td>
      <td>240</td>
      <td>0.805769</td>
      <td>3</td>
      <td>1.870076</td>
      <td>0.003789</td>
      <td>0.569791</td>
      <td>0.106725</td>
      <td>0.805769</td>
      <td>0.087506</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Within-subject run-to-run spread for subjects with multiple runs
rows = []
for subject, df in run_metrics.groupby('subject'):
    if len(df) > 1:
        row = {'subject': subject, 'n_runs': len(df)}
        for col in STATE_COLS:
            row[f'{col}_range'] = float(df[col].max() - df[col].min())
        rows.append(row)

run_spread = pd.DataFrame(rows)
run_spread
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>subject</th>
      <th>n_runs</th>
      <th>FO_s01_range</th>
      <th>FO_s02_range</th>
      <th>FO_s03_range</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>sub-08</td>
      <td>2</td>
      <td>0.001658</td>
      <td>0.011324</td>
      <td>0.009666</td>
    </tr>
    <tr>
      <th>1</th>
      <td>sub-13</td>
      <td>2</td>
      <td>0.031058</td>
      <td>0.242418</td>
      <td>0.211361</td>
    </tr>
    <tr>
      <th>2</th>
      <td>sub-17</td>
      <td>2</td>
      <td>0.017594</td>
      <td>0.038429</td>
      <td>0.020835</td>
    </tr>
  </tbody>
</table>
</div>



## 3) Transition matrix and dwell interpretation

This section asks:
- Which state is the stickiest?
- Which state behaves like a hub or attractor?
- Does the stationary distribution implied by `A` agree with the empirical FO profile?


```python
A_df = pd.DataFrame(A, index=STATE_NAMES, columns=STATE_NAMES)
A_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>S1</th>
      <th>S2</th>
      <th>S3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>S1</th>
      <td>0.183623</td>
      <td>0.748920</td>
      <td>0.067458</td>
    </tr>
    <tr>
      <th>S2</th>
      <td>0.076938</td>
      <td>0.839828</td>
      <td>0.083234</td>
    </tr>
    <tr>
      <th>S3</th>
      <td>0.101943</td>
      <td>0.664135</td>
      <td>0.233922</td>
    </tr>
  </tbody>
</table>
</div>




```python
pi = stationary_distribution(A)
outgoing_excl_self = 1.0 - np.diag(A)
expected_dwell_tr = dwell_from_transition_matrix(A)

transition_summary = pd.DataFrame({
    'state': STATE_NAMES,
    'stationary_prob_from_A': pi,
    'A_kk': np.diag(A),
    'leave_prob_1_minus_Akk': outgoing_excl_self,
    'expected_dwell_TR': expected_dwell_tr,
})
transition_summary['expected_dwell_sec_if_TR_2p1'] = transition_summary['expected_dwell_TR'] * 2.1
transition_summary
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>state</th>
      <th>stationary_prob_from_A</th>
      <th>A_kk</th>
      <th>leave_prob_1_minus_Akk</th>
      <th>expected_dwell_TR</th>
      <th>expected_dwell_sec_if_TR_2p1</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>S1</td>
      <td>0.088823</td>
      <td>0.183623</td>
      <td>0.816377</td>
      <td>1.224924</td>
      <td>2.572340</td>
    </tr>
    <tr>
      <th>1</th>
      <td>S2</td>
      <td>0.814824</td>
      <td>0.839828</td>
      <td>0.160172</td>
      <td>6.243287</td>
      <td>13.110902</td>
    </tr>
    <tr>
      <th>2</th>
      <td>S3</td>
      <td>0.096352</td>
      <td>0.233922</td>
      <td>0.766078</td>
      <td>1.305351</td>
      <td>2.741236</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Compare stationary distribution from A to the final seed's FO distribution from refit_results.json
best_refit = refit_df.iloc[0].copy()
fo_final = np.array(best_refit['fo'], dtype=float)
compare_fo = pd.DataFrame({
    'state': STATE_NAMES,
    'FO_final_seed': fo_final,
    'stationary_from_A': pi,
    'difference': fo_final - pi,
})
compare_fo
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>state</th>
      <th>FO_final_seed</th>
      <th>stationary_from_A</th>
      <th>difference</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>S1</td>
      <td>0.089823</td>
      <td>0.088823</td>
      <td>0.000999</td>
    </tr>
    <tr>
      <th>1</th>
      <td>S2</td>
      <td>0.807597</td>
      <td>0.814824</td>
      <td>-0.007227</td>
    </tr>
    <tr>
      <th>2</th>
      <td>S3</td>
      <td>0.102580</td>
      <td>0.096352</td>
      <td>0.006228</td>
    </tr>
  </tbody>
</table>
</div>



## 4) State-signature similarity

Because the saved `state_signature_ut_boldcorr.npy` stores upper-triangle BOLD-correlation signatures,
we can ask whether the 3 states are strongly different topographically, or whether they look like
related variants of one broader pattern.


```python
sig_corr = pairwise_row_corr(state_sig)
sig_corr_df = pd.DataFrame(sig_corr, index=STATE_NAMES, columns=STATE_NAMES)
sig_corr_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>S1</th>
      <th>S2</th>
      <th>S3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>S1</th>
      <td>1.000000</td>
      <td>0.927677</td>
      <td>0.742891</td>
    </tr>
    <tr>
      <th>S2</th>
      <td>0.927677</td>
      <td>1.000000</td>
      <td>0.813785</td>
    </tr>
    <tr>
      <th>S3</th>
      <td>0.742891</td>
      <td>0.813785</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Optional: mean norms and covariance traces in PCA space
rows = []
for k in range(3):
    rows.append({
        'state': STATE_NAMES[k],
        'mean_norm_pca': float(np.linalg.norm(means_pca[k])),
        'cov_trace_pca': float(np.trace(covs_pca[k])),
    })
state_scale_df = pd.DataFrame(rows)
state_scale_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>state</th>
      <th>mean_norm_pca</th>
      <th>cov_trace_pca</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>S1</td>
      <td>2.524436</td>
      <td>200.995667</td>
    </tr>
    <tr>
      <th>1</th>
      <td>S2</td>
      <td>0.830525</td>
      <td>174.215698</td>
    </tr>
    <tr>
      <th>2</th>
      <td>S3</td>
      <td>1.401761</td>
      <td>87.858826</td>
    </tr>
  </tbody>
</table>
</div>



## 5) Plots


```python
# Subject-level stacked occupancy plot
fig, ax = plt.subplots(figsize=(10, 5))
plot_df = subject_metrics.sort_values('FO_s02', ascending=False).reset_index(drop=True)
x = np.arange(len(plot_df))
ax.bar(x, plot_df['FO_s01'], label='S1')
ax.bar(x, plot_df['FO_s02'], bottom=plot_df['FO_s01'], label='S2')
ax.bar(x, plot_df['FO_s03'], bottom=plot_df['FO_s01'] + plot_df['FO_s02'], label='S3')
ax.set_xticks(x)
ax.set_xticklabels(plot_df['subject'], rotation=45, ha='right')
ax.set_ylabel('Fractional occupancy')
ax.set_title('Subject-level fractional occupancy (sorted by S2)')
ax.legend()
fig.tight_layout()
fig.savefig(OUT_FIG_DIR / 'subject_fractional_occupancy_stacked.png', bbox_inches='tight')
plt.show()
```


    
![png](output_21_0.png)
    



```python
# Run-level occupancy plot
fig, ax = plt.subplots(figsize=(11, 5))
plot_df = run_metrics.sort_values('FO_s02', ascending=False).reset_index(drop=True)
x = np.arange(len(plot_df))
ax.bar(x, plot_df['FO_s01'], label='S1')
ax.bar(x, plot_df['FO_s02'], bottom=plot_df['FO_s01'], label='S2')
ax.bar(x, plot_df['FO_s03'], bottom=plot_df['FO_s01'] + plot_df['FO_s02'], label='S3')
ax.set_xticks(x)
ax.set_xticklabels(plot_df['run'], rotation=60, ha='right')
ax.set_ylabel('Fractional occupancy')
ax.set_title('Run-level fractional occupancy (sorted by S2)')
ax.legend()
fig.tight_layout()
fig.savefig(OUT_FIG_DIR / 'run_fractional_occupancy_stacked.png', bbox_inches='tight')
plt.show()
```


    
![png](output_22_0.png)
    



```python
# Transition matrix heatmap
fig, ax = plt.subplots(figsize=(5, 4))
im = ax.imshow(A, aspect='auto')
ax.set_xticks(np.arange(3))
ax.set_xticklabels(STATE_NAMES)
ax.set_yticks(np.arange(3))
ax.set_yticklabels(STATE_NAMES)
ax.set_title('Transition matrix A')
for i in range(3):
    for j in range(3):
        ax.text(j, i, f'{A[i, j]:.3f}', ha='center', va='center')
fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
fig.tight_layout()
fig.savefig(OUT_FIG_DIR / 'transition_matrix_A.png', bbox_inches='tight')
plt.show()
```


    
![png](output_23_0.png)
    



```python
# Dwell times from A
fig, ax = plt.subplots(figsize=(6, 4))
ax.bar(dwell_from_A['state'], dwell_from_A['dwell_A_sec'])
ax.set_ylabel('Seconds')
ax.set_title('Expected dwell time from A')
fig.tight_layout()
fig.savefig(OUT_FIG_DIR / 'dwell_time_seconds.png', bbox_inches='tight')
plt.show()
```


    
![png](output_24_0.png)
    



```python
# Signature correlation heatmap
fig, ax = plt.subplots(figsize=(5, 4))
im = ax.imshow(sig_corr, vmin=-1, vmax=1, aspect='auto')
ax.set_xticks(np.arange(3))
ax.set_xticklabels(STATE_NAMES)
ax.set_yticks(np.arange(3))
ax.set_yticklabels(STATE_NAMES)
ax.set_title('Pairwise correlation of state signatures')
for i in range(3):
    for j in range(3):
        ax.text(j, i, f'{sig_corr[i, j]:.3f}', ha='center', va='center')
fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
fig.tight_layout()
fig.savefig(OUT_FIG_DIR / 'state_signature_correlation.png', bbox_inches='tight')
plt.show()
```


    
![png](output_25_0.png)
    


## 6) One-cell plain-language interpretation

This final cell prints a compact interpretation that you can adapt into Results text.


```python
subj_dom_counts = subject_metrics['dominant_state'].value_counts().sort_index().to_dict()
run_dom_counts = run_metrics['dominant_state'].value_counts().sort_index().to_dict()

msg = f'''
PipelineE K=3 review
--------------------
1. QC passed: {qc['collapsed_run_count']} / {qc['n_runs']} collapsed runs.
2. Final seed = {qc['final_seed']} with FE = {qc['final_seed_fe']:.3f}, FO_max = {qc['final_seed_fo_max']:.3f}, n_active = {qc['final_seed_n_active']}, n_eff = {qc['final_seed_neff']:.3f}.
3. Dominant state across subjects: {subj_dom_counts}
4. Dominant state across runs    : {run_dom_counts}
5. Stationary distribution from A: {np.round(pi, 4)}
6. Expected dwell (TR)           : {np.round(expected_dwell_tr, 3)}
7. Expected dwell (sec, TR=2.1)  : {np.round(expected_dwell_tr * 2.1, 3)}
8. Pairwise signature correlations:
{pd.DataFrame(sig_corr, index=STATE_NAMES, columns=STATE_NAMES).round(3).to_string()}

Interpretation:
- S2 is the dominant state globally.
- S2 is also the dominant state for every subject and every run in these saved outputs.
- S2 is much stickier than S1 and S3.
- S1 and S3 look more like short-lived satellite states that tend to transition into S2.
- If the signature correlations remain high, the states may differ more in persistence / occupancy than in completely different BOLD-correlation topographies.
'''
print(msg)
```

    
    PipelineE K=3 review
    --------------------
    1. QC passed: 0 / 15 collapsed runs.
    2. Final seed = 23 with FE = 133.245, FO_max = 0.808, n_active = 3, n_eff = 1.864.
    3. Dominant state across subjects: {2: 12}
    4. Dominant state across runs    : {2: 15}
    5. Stationary distribution from A: [0.0888 0.8148 0.0964]
    6. Expected dwell (TR)           : [1.225 6.243 1.305]
    7. Expected dwell (sec, TR=2.1)  : [ 2.572 13.111  2.741]
    8. Pairwise signature correlations:
           S1     S2     S3
    S1  1.000  0.928  0.743
    S2  0.928  1.000  0.814
    S3  0.743  0.814  1.000
    
    Interpretation:
    - S2 is the dominant state globally.
    - S2 is also the dominant state for every subject and every run in these saved outputs.
    - S2 is much stickier than S1 and S3.
    - S1 and S3 look more like short-lived satellite states that tend to transition into S2.
    - If the signature correlations remain high, the states may differ more in persistence / occupancy than in completely different BOLD-correlation topographies.
    

